import React from "react";

// Default to simply returning the trans string - should never occur
const I18nContext = React.createContext({
    trans: transString => transString,
    ngettext: transString => transString
});

export {
    I18nContext
};