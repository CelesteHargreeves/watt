import React from "react";

const FeatureFlagsContext = React.createContext({});

export {
    FeatureFlagsContext
};