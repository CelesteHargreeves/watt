import React, {
    useState
} from "react";
import ParagraphCommentsDrawer from "../ParagraphCommentsDrawer/ParagraphCommentsDrawer";
import Icon from "../../../shared-components/Icon";
import classNames from "classnames";
import PropTypes from "prop-types";
import {
    count
} from "../../../helpers";

const ParagraphCommentsCount = ({
    partId,
    storyId,
    partTitle,
    paragraphId,
    paragraphBody,
    storyAuthor,
    commentCount: initialCount
}) => {
    const [showDrawer, setShowDrawer] = useState(false);
    const [commentCount, setCommentCount] = useState(initialCount);

    const pushCommentViewEvent = action => {
        window.te.push("event", "comments", null, null, action, {
            page: "comment",
            storyid: parseInt(storyId),
            partid: parseInt(partId),
            paragraph_id: paragraphId
        });
    };

    const handleMarkerClick = () => {
        setShowDrawer(true);
        pushCommentViewEvent("view");
    };
    const handleCloseDrawer = () => {
        setShowDrawer(false);
        pushCommentViewEvent("close");
    };

    const handleUpdateCount = difference => {
        setCommentCount(count => count + difference);
    };

    return ( <
        >
        <
        button onClick = {
            handleMarkerClick
        }
        className = {
            classNames("btn-no-background comment-marker", {
                "hide-marker": !commentCount
            })
        } >
        <
        span className = "num-comment" > {
            commentCount ? count(commentCount) : "+"
        } <
        /span> <
        Icon iconName = "fa-comment-count"
        height = "28"
        color = "wp-neutral-2" / >
        <
        /button> {
            showDrawer && ( <
                ParagraphCommentsDrawer partId = {
                    partId
                }
                storyId = {
                    storyId
                }
                partTitle = {
                    partTitle
                }
                paragraphId = {
                    paragraphId
                }
                paragraphBody = {
                    paragraphBody
                }
                storyAuthor = {
                    storyAuthor
                }
                onCloseDrawer = {
                    handleCloseDrawer
                }
                onUpdateCount = {
                    handleUpdateCount
                }
                />
            )
        } <
        />
    );
};

ParagraphCommentsCount.propTypes = {
    partId: PropTypes.number.isRequired,
    storyId: PropTypes.string.isRequired,
    partTitle: PropTypes.string.isRequired,
    paragraphId: PropTypes.string.isRequired,
    paragraphBody: PropTypes.string.isRequired,
    storyAuthor: PropTypes.string.isRequired,
    commentCount: PropTypes.number.isRequired
};

export default ParagraphCommentsCount;