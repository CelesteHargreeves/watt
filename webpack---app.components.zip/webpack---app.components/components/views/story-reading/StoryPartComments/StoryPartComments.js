import React from "react";
import PropTypes from "prop-types";
import CommentsList from "../../comments/CommentsList";
import {
    CommentsLocation,
    INIT_COMMENTS_STORY_PART
} from "../../comments/CommentsConstants";

const StoryPartComments = props => {
    const sentimentEventData = {
        page: "comment",
        storyid: parseInt(props.group ? .id),
        partid: parseInt(props.id),
        entity_type: "comment",
        sentiment_type: "like"
    };

    return ( <
        div id = "story-part-comments" >
        <
        CommentsList partId = {
            props.id
        }
        location = {
            CommentsLocation.STORY_PART
        }
        initialLimit = {
            INIT_COMMENTS_STORY_PART
        }
        storyAuthor = {
            props.group ? .user.username
        }
        sentimentEventData = {
            sentimentEventData
        }
        /> <
        /div>
    );
};

StoryPartComments.propTypes = {
    id: PropTypes.number.isRequired,
    group: PropTypes.object
};

export default StoryPartComments;