import React, {
    useEffect,
    useRef,
    useState
} from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import Icon from "../../../shared-components/Icon";
import CommentsList from "../../comments/CommentsList";
import {
    useTrans
} from "../../../hooks";
import classNames from "classnames";
import {
    CommentsLocation
} from "../../comments/CommentsConstants";

const STORY_READING_ID = "story-reading";

const ParagraphCommentsDrawer = ({
    partId,
    storyId,
    partTitle,
    paragraphId,
    paragraphBody,
    storyAuthor,
    onCloseDrawer,
    onUpdateCount
}) => {
    const {
        trans
    } = useTrans();
    const scrollableRef = useRef();
    const [isFullyOpen, setIsFullyOpen] = useState(false);

    const sentimentEventData = {
        page: "comment",
        storyid: parseInt(storyId),
        partid: parseInt(partId),
        paragraph_id: paragraphId,
        entity_type: "comment",
        sentiment_type: "like"
    };

    const initializeDrawer = () => {
        setIsFullyOpen(true);
        document.body.classList.add("modal-open");
        return () => document.body.classList.remove("modal-open");
    };

    useEffect(initializeDrawer, []);

    const handleCloseDrawer = () => {
        setIsFullyOpen(false);
        setTimeout(onCloseDrawer, 300);
    };

    const renderDrawer = () => ( <
        div className = "paragraph-comments-drawer" >
        <
        div role = "presentation"
        className = {
            classNames("modal-backdrop fade", { in: isFullyOpen
            })
        }
        onClick = {
            handleCloseDrawer
        }
        /> <
        div ref = {
            scrollableRef
        }
        className = {
            classNames("drawer-content", {
                open: isFullyOpen
            })
        } >
        <
        header className = "drawer-header" >
        <
        h1 className = "drawer-title" > {
            partTitle
        } < /h1> <
        button className = "close-btn"
        onClick = {
            handleCloseDrawer
        }
        aria - label = {
            trans("Close")
        } >
        <
        Icon iconName = "fa-remove"
        height = "14"
        color = "wp-neutral-1" / >
        <
        /button> <
        /header> <
        div className = "drawer-body" >
        <
        div className = "paragraph-content" >
        <
        pre dangerouslySetInnerHTML = {
            {
                __html: paragraphBody
            }
        }
        /> <
        /div> <
        CommentsList partId = {
            partId
        }
        paragraphId = {
            paragraphId
        }
        storyAuthor = {
            storyAuthor
        }
        scrollableRef = {
            scrollableRef
        }
        location = {
            CommentsLocation.PARAGRAPH
        }
        sentimentEventData = {
            sentimentEventData
        }
        onUpdateCount = {
            onUpdateCount
        }
        /> <
        /div> <
        /div> <
        /div>
    );

    return ReactDOM.createPortal(
        renderDrawer(),
        document.getElementById(STORY_READING_ID)
    );
};

ParagraphCommentsDrawer.propTypes = {
    partId: PropTypes.number.isRequired,
    storyId: PropTypes.string.isRequired,
    partTitle: PropTypes.string.isRequired,
    paragraphId: PropTypes.string.isRequired,
    paragraphBody: PropTypes.string.isRequired,
    storyAuthor: PropTypes.string.isRequired,
    onCloseDrawer: PropTypes.func.isRequired,
    onUpdateCount: PropTypes.func.isRequired
};

export default ParagraphCommentsDrawer;