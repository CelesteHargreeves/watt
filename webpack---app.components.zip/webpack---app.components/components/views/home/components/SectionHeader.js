import React from "react";
import PropTypes from "prop-types";

import PromotedIndicator from "./PromotedIndicator";
import {
    ExpandPromptButton
} from "./ExpandPromptButton";
/**
 * Render a header for home modules
 */
const SectionHeader = ({
    expandPrompt,
    heading,
    subheading,
    isPromoted,
    sectionType
}) => {
    const isPaid = sectionType === "paid" || sectionType === "paidMultiRow";

    return ( <
        div className = "module-header" >
        <
        div className = "left-section" >
        <
        div className = "heading" >
        <
        h3 > {
            heading
        } < /h3> <
        /div> <
        div className = "subheading" >
        <
        h4 > {
            subheading
        } < /h4> <
        /div> <
        /div> {
            expandPrompt && ( <
                ExpandPromptButton expandPrompt = {
                    expandPrompt
                }
                isPaid = {
                    isPaid
                }
                />
            )
        } {
            isPromoted === true && < PromotedIndicator / >
        } <
        /div>
    );
};

SectionHeader.propTypes = {
    expandPrompt: PropTypes.object,
    heading: PropTypes.string.isRequired,
    subheading: PropTypes.string,
    isPromoted: PropTypes.bool,
    sectionType: PropTypes.string
};

export default SectionHeader;