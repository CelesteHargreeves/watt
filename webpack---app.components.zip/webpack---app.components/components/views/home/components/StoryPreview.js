import React from "react";

import PropTypes from "prop-types";
import {
    connect
} from "react-redux";

import {
    getCoverSrc,
    injectTrans,
    simpleShorten
} from "../../../helpers";
import {
    Icon
} from "../../../shared-components";
import {
    toggleModal
} from "./../../../shared-components/modals/actions";
import {
    getReadingLists,
    updateCollection,
    removeStoriesFromCollection,
    getCollectionsForStoryIds
} from "../actions";
import StoryIconBar from "../../../shared-components/StoryIconBar";
import {
    openPopover,
    closePopover
} from "../../../shared-components/popover/reducers";
import LibraryPopover from "./LibraryPopover";
import {
    focusableElementsString
} from "../../../hooks/useTrapKeyboardNavigation";

const readBtnIconProps = [{
        className: "open-book",
        name: "bookOpenBeta",
        size: "16",
        color: "ds-neutral-00-solid"
    },
    {
        className: "paid-story",
        name: "paidStory",
        size: "20",
        color: "ds-neutral-00-solid",
        strokeWidth: "0",
        fill: true
    }
];

export class StoryPreviewUI extends React.Component {
    static propTypes = {
        story: PropTypes.object,
        readingLists: PropTypes.array,
        getReadingLists: PropTypes.func,
        readingListsLoading: PropTypes.bool,
        updateCollection: PropTypes.func,
        removeStoriesFromCollection: PropTypes.func,
        getCollectionsForStoryIds: PropTypes.func,
        storiesCollections: PropTypes.object,
        toggleModal: PropTypes.func,
        openPopover: PropTypes.func,
        closePopover: PropTypes.func,
        trans: PropTypes.func.isRequired,
        ngettext: PropTypes.func.isRequired
    };

    state = {
        completed: this.props.story.completed,
        isMature: this.props.story.mature,
        numParts: this.props.story.numParts,
        isLibraryPopoverOpen: false,
        firstTabFocus: null,
        lastTabFocus: null,
        focusableElements: []
    };

    _isMounted = false;
    libraryButtonRef = React.createRef();
    modalRef = React.createRef();
    beforeModalRef = React.createRef();

    defaultCover = getCoverSrc(this.props.story.cover, 268);

    handleKeyPress = e => {
        // Check for TAB key press
        if (
            e.key === "Tab" &&
            this.state.firstTabFocus &&
            this.state.lastTabFocus
        ) {
            // SHIFT + TAB: previous element
            if (e.shiftKey) {
                if (document.activeElement === this.state.firstTabFocus) {
                    e.preventDefault();
                    this.state.lastTabFocus.focus();
                }
                // TAB: next element
            } else {
                if (document.activeElement === this.state.lastTabFocus) {
                    e.preventDefault();
                    this.state.firstTabFocus.focus();
                }
            }
        }
        // handling ESC key press
        if (e.key === "Escape") {
            // close the library popover if it's open
            if (this.state.isLibraryPopoverOpen) {
                this.props.closePopover();
                this.setState({
                    isLibraryPopoverOpen: false
                });
            } else {
                this.beforeModalRef && this.beforeModalRef.current.focus();
                this.props.toggleModal();
            }
        }
    };

    componentDidMount() {
        this._isMounted = true;
        document.body.style.overflow = "hidden";
        this.beforeModalRef.current = document.activeElement;

        window.addEventListener("keydown", this.handleKeyPress);
        // Second Chance™
        // Make a second attempt at getting the reading lists
        // if the first attempt from Home failed.
        if (!this.props.readingLists && !this.props.readingListsLoading) {
            this.props.getReadingLists();
        }

        this.props.getCollectionsForStoryIds(this.props.story.id);
    }

    componentDidUpdate(_, prevState) {
        let prevFocusableElements = prevState.focusableElements ?
            prevState.focusableElements :
            [];

        let currFocusableElements = this.modalRef.current ?
            this.modalRef.current.querySelectorAll(focusableElementsString) :
            null;
        currFocusableElements = currFocusableElements ?
            Array.prototype.slice.call(currFocusableElements) :
            [];

        const isSame =
            prevFocusableElements.length === currFocusableElements.length &&
            currFocusableElements.every(
                (node, index) => node === prevFocusableElements[index]
            );

        // only update state if list of FocusableElements has changed
        if (!isSame && currFocusableElements.length !== 0) {
            this.setState({
                firstTabFocus: currFocusableElements[0],
                lastTabFocus: currFocusableElements[currFocusableElements.length - 1],
                focusableElements: currFocusableElements
            });
            currFocusableElements[0].focus();
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
        document.body.style.overflow = "auto";
        window.removeEventListener("keydown", this.handleKeyPress);
    }

    onRead = () => {
        const storyReadLink = this.props.story.firstPartId ?
            `/${this.props.story.firstPartId}` :
            `/story/${this.props.story.id}`;
        app.router.navigate(storyReadLink, {
            trigger: true
        });
        this.props.toggleModal();
    };

    onMoreDetails = () => {
        const storyDetailsLink = `/story/${this.props.story.id}`;
        app.router.navigate(storyDetailsLink, {
            trigger: true
        });
        this.props.toggleModal();
    };

    handleLibraryClick = e => {
        e.preventDefault();
        this.setState({
            isLibraryPopoverOpen: true
        });

        const component = () => ( <
            LibraryPopover readingLists = {
                this.props.readingLists
            }
            storyId = {
                this.props.story.id
            }
            updateCollection = {
                this.props.updateCollection
            }
            removeStoriesFromCollection = {
                this.props.removeStoriesFromCollection
            }
            storiesCollections = {
                this.props.storiesCollections[this.props.story.id]
            }
            getReadingLists = {
                this.props.getReadingLists
            }
            getCollectionsForStoryIds = {
                this.props.getCollectionsForStoryIds
            }
            />
        );

        this.props.openPopover({
            component,
            triggerRef: this.libraryButtonRef,
            passthroughProps: {
                modifiers: [{
                    name: "preventOverflow",
                    options: {
                        boundary: this.modalRef.current
                    }
                }],
                showArrow: "true"
            },
            contentClass: "react-popover-content--above-modal" // fix to allow popover to live above modal.
        });
    };

    handleCloseClick = () => {
        this.props.toggleModal();
        this.beforeModalRef && this.beforeModalRef.current.focus();
    };

    render() {
        const {
            trans
        } = this.props;
        return ( <
            div className = "story-preview-wrapper"
            ref = {
                this.modalRef
            } >
            <
            div className = "cover" >
            <
            img srcSet = {
                `${getCoverSrc(
              this.props.story.cover,
              288
            )} 1x, ${getCoverSrc(
              this.props.story.cover,
              416
            )} 1.5x, ${getCoverSrc(this.props.story.cover, 512)} 2x`
            }
            src = {
                this.defaultCover
            }
            alt = {
                `${this.props.story.title} cover`
            }
            /> <
            /div> <
            button className = "close"
            onClick = {
                this.handleCloseClick
            } >
            <
            Icon name = "close"
            size = "24" / >
            <
            /button> <
            div className = "story-info" >
            <
            div className = "meta-header" >
            <
            div className = "title-wrapper" > {
                this.props.story.isPaid && ( <
                    Icon name = "paidStory"
                    className = "paid-stories-badge"
                    size = "24"
                    color = "ds-neutral-100"
                    strokeWidth = "0"
                    fill title = "Paid Stories Badge" /
                    >
                )
            } <
            div className = "title" > {
                this.props.story.title
            } < /div> <
            /div> <
            StoryIconBar numParts = {
                this.state.numParts
            }
            isMature = {
                this.state.isMature
            }
            isCompleted = {
                this.state.completed
            }
            /> <
            /div> {
                // TODO: Replace this with StoryActions
            } <
            div className = "buttons-wrapper" >
            <
            button className = "read btn-primary"
            onClick = {
                this.onRead
            } >
            <
            Icon { ...readBtnIconProps[+this.props.story.isPaid]
            }
            /> <
            span className = "read-btn-text" > {
                this.props.story.isPaid ?
                trans("Free preview") :
                    trans("Start reading")
            } <
            /span> <
            /button> {
                this.props.readingLists && ( <
                    button className = "btn-primary add-to-library-btn"
                    title = {
                        trans("Add story to...")
                    }
                    aria - label = {
                        trans("Add story to...")
                    }
                    ref = {
                        this.libraryButtonRef
                    }
                    onClick = {
                        this.handleLibraryClick
                    } >
                    <
                    Icon name = "add"
                    size = "24"
                    color = "wp-neutral-1"
                    strokeWidth = "2.5" /
                    >
                    <
                    /button>
                )
            } <
            /div> <
            div className = "description" > {
                simpleShorten(this.props.story.description, 400, false)
            } <
            /div> <
            div className = "more-details-wrapper" >
            <
            button className = "more-details"
            onClick = {
                this.onMoreDetails
            } > {
                trans("More details")
            } <
            Icon name = "chevRight"
            size = "24" / >
            <
            /button> <
            /div> <
            /div> <
            /div>
        );
    }
}

const mapDispatchToProps = {
    getReadingLists,
    updateCollection,
    removeStoriesFromCollection,
    getCollectionsForStoryIds,
    toggleModal,
    openPopover,
    closePopover
};

const mapStateToProps = state => {
    const {
        readingLists,
        readingListsLoading,
        removeStoriesFromCollection,
        storiesCollections
    } = state.homeSections;
    return {
        readingLists,
        readingListsLoading,
        removeStoriesFromCollection,
        storiesCollections
    };
};

export default injectTrans(
    connect(
        mapStateToProps,
        mapDispatchToProps
    )(StoryPreviewUI)
);