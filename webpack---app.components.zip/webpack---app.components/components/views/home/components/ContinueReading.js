import React, {
    useState,
    useEffect,
    useCallback
} from "react";
import propTypes from "prop-types";
import {
    useTrans
} from "../../../hooks";
import _ from "lodash";
import {
    getCoverSrc,
    getCoverSrcSet
} from "../../../helpers";

export default function ContinueReading({
    visible
}) {
    const {
        trans
    } = useTrans();
    const [recentStory, setRecentStory] = useState(null);
    const [readingPosition, setReadingPosition] = useState(0);
    const [formattedPartURL, setformattedPartURL] = useState("");
    const [coverSizes, setCoverSizes] = useState("");
    const [defaultCover, setDefaultCover] = useState("");
    let slideAmount = visible ? "0px" : "150px";

    const getFormattedPartURL = useCallback(story => {
        const partId = _.get(story, "readingPosition.partId", null);
        const storyParts = _.get(story, "parts", null);
        const part = _.find(storyParts, {
            id: parseInt(partId)
        });
        const partURL = _.get(part, "url", null);
        const formattedPartURL = partURL ?
            wattpad.utils.formatStoryUrl(partURL) :
            null;
        return formattedPartURL;
    }, []);

    const mobileStoryWidth = 40;
    const desktopStoryWidth = 60;

    useEffect(
        () => {
            const username = wattpad.user.username || "";
            const recentReadsEndpoint = `/v4/users/${username}/recent_reads`;
            Promise.resolve(
                    $.get({
                        url: recentReadsEndpoint,
                        cache: false
                    })
                )
                .then(result => {
                    const recentStory = result.stories[0];
                    const coverSizes = getCoverSrcSet(recentStory.cover);
                    const defaultCover = getCoverSrc(recentStory.cover, mobileStoryWidth);
                    const readingPosition =
                        recentStory && recentStory.parts && recentStory.readingPosition ?
                        wattpad.utils.calcPercentRead(
                            recentStory.parts,
                            recentStory.readingPosition
                        ) :
                        0;
                    setRecentStory(recentStory);
                    setReadingPosition(readingPosition);
                    setformattedPartURL(getFormattedPartURL(recentStory));
                    setCoverSizes(coverSizes);
                    setDefaultCover(defaultCover);
                })
                .catch(() => {
                    setRecentStory(null);
                    setReadingPosition(0);
                    setformattedPartURL("");
                    setCoverSizes("");
                    setDefaultCover("");
                });
        }, [getFormattedPartURL]
    );

    const goToRecentStoryPart = () => {
        if (formattedPartURL) {
            app.router.navigate(formattedPartURL, {
                trigger: true
            });
        }
    };

    return (!!recentStory &&
        !!formattedPartURL && ( <
            div className = "continue-reading-wrapper" >
            <
            button className = "continue-reading"
            label = {
                trans("Continue reading %s", recentStory.title)
            }
            onClick = {
                goToRecentStoryPart
            }
            style = {
                {
                    transform: `translate(0, ${slideAmount})`
                }
            } >
            <
            div className = "info" >
            <
            div className = "story-info" >
            <
            div className = "cover" >
            <
            img srcSet = {
                coverSizes
            }
            sizes = {
                `(max-width: 575px) ${mobileStoryWidth}px, ${desktopStoryWidth}px`
            }
            src = {
                defaultCover
            }
            alt = {
                recentStory.title + ` cover`
            }
            /> <
            /div> <
            div className = "story-details" >
            <
            div className = "header" > {
                trans("Continue Reading")
            } < /div> <
            div className = "story-title" > {
                recentStory.title
            } < /div> <
            /div> <
            /div> <
            div className = "read" > {
                trans("READ")
            } < /div> <
            /div> <
            div className = "percentage-read" >
            <
            div className = "percentage-position"
            style = {
                {
                    width: `${readingPosition}%`
                }
            }
            /> <
            /div> <
            /button> <
            /div>
        )
    );
}

ContinueReading.propTypes = {
    visible: propTypes.bool
};