import React from "react";
import PropTypes from "prop-types";

import {
    useTrans
} from "../../../hooks";

function ExpandPromptButton({
    expandPrompt,
    isPaid
}) {
    const {
        trans
    } = useTrans();
    var {
        weblink = "", prompt = ""
    } = expandPrompt || {};
    if (isPaid) {
        weblink = "/catalog/paidstories";
        prompt = trans("See all");
    }

    if (!weblink || !prompt) {
        return null;
    }

    return ( <
        a href = {
            weblink
        }
        className = "on-navigate btn-secondary" > {
            prompt
        } <
        /a>
    );
}

ExpandPromptButton.propTypes = {
    expandPrompt: PropTypes.object,
    isPaid: PropTypes.bool
};

export {
    ExpandPromptButton
};