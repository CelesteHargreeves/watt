import PropTypes from "prop-types";
import React from "react";
import {
    useTrans
} from "../../hooks";
import ThirdPartyAuth from "./ThirdPartyAuth";

const ThirdPartySignup = ({
    focus,
    nextUrl = "/home",
    toggleForm,
    toggleFormView
}) => {
    const {
        trans
    } = useTrans();
    const policy_agreement = trans("By continuing, you agree to Wattpad's <a href='/terms'>Terms of Service</a> and <a href='/privacy'>Privacy Policy</a>."); // prettier-ignore
    return ( <
        >
        <
        ThirdPartyAuth source = "signup"
        nextUrl = {
            nextUrl
        }
        focus = {
            focus
        }
        /> <
        div className = "hr-with-text" >
        <
        div className = "horizontal-line" / >
        <
        span className = "or" > OR < /span> <
        div className = "horizontal-line" / >
        <
        /div> <
        button className = "btn-block btn-primary submit-btn"
        onClick = {
            toggleFormView
        } >
        {
            trans("Sign up with Email")
        } <
        /button>

        <
        p > {
            trans("If you already have an account, ")
        } <
        button className = "login"
        onClick = {
            toggleForm
        } > {
            trans("Log in.")
        } <
        /button> <
        /p>

        <
        span className = "policy-agreement"
        dangerouslySetInnerHTML = {
            {
                __html: policy_agreement
            }
        }
        /> <
        />
    );
};

ThirdPartySignup.propTypes = {
    focus: PropTypes.bool,
    nextUrl: PropTypes.string,
    toggleForm: PropTypes.func.isRequired,
    toggleFormView: PropTypes.func.isRequired
};

export default ThirdPartySignup;