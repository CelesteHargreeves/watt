import React, {
    useState
} from "react";
import PropTypes from "prop-types";
import {
    useTrans
} from "../../hooks";
import PasswordFields from "../../shared-components/PasswordFields";
import {
    Button,
    ButtonVariant
} from "@wattpad/web-ui-library";

export const ResetPassword = ({
    authToken,
    isFromPushNotification,
    username,
    name
}) => {
    const {
        trans
    } = useTrans();
    const [isFormValid, setIsFormValid] = useState(false);
    const [resetConfirmed, setResetConfirmed] = useState(false);

    const onValidPassword = valid => {
        setIsFormValid(valid);
    };

    const onReset = async event => {
        event.preventDefault();

        await $.ajax({
                type: "POST",
                url: `apiv2/updateuserpassword`,
                data: $(".reset-password").serialize()
            })
            .done(() => {
                if (isFromPushNotification) {
                    setResetConfirmed(true);
                } else {
                    const redirectUrl = "/login?nexturl=home";
                    window.location.replace(redirectUrl).reload();
                }
            })
            .fail(err => {
                //if the reset link has expired
                if (err.responseJSON ? .code === 467) {
                    const redirectUrl =
                        "/forgot?nextUrl=settings?msg=" +
                        encodeURIComponent(err.responseJSON.message);
                    window.location.replace(redirectUrl).reload();
                }
                const message =
                    trans("Something went wrong, your changes were not saved. ") +
                    (err.responseJSON.message || "");
                wattpad.utils.showToast(message, {
                    type: "dismissable"
                });
            });
    };

    return ( <
        div className = "panel-body" > {!resetConfirmed ? ( <
                >
                <
                small dangerouslySetInnerHTML = {
                    {
                        /* prettier-ignore */
                        __html: trans('Visit <a href="https://support.wattpad.com/hc/en-us/articles/211235843-Resetting-or-changing-your-password">Wattpad Support</a> for more information')
                    }
                }
                /> <
                hr / >
                <
                form className = "reset-password" >
                <
                input name = "at"
                value = {
                    authToken
                }
                type = "hidden" / > {
                    isFromPushNotification && ( <
                        input name = "isFromPushNotification"
                        value = "true"
                        type = "hidden" / >
                    )
                } <
                PasswordFields validatePassword = {
                    onValidPassword
                }
                username = {
                    username
                }
                name = {
                    name
                }
                />

                <
                div className = "row" >
                <
                div className = "btn-container col-sm-7 col-lg-6" >
                <
                Button fullWidth disabled = {!isFormValid
                }
                variant = {
                    ButtonVariant.PRIMARY
                }
                aria - label = "Reset password"
                onClick = {
                    onReset
                } >
                {
                    trans("Reset password")
                } <
                /Button> <
                /div> <
                div className = "btn-container col-sm-5 col-lg-6" >
                <
                a className = "cancel-btn on-login on-navigate"
                rel = "nofollow"
                href = "/login"
                data - form = "login" >
                {
                    trans("Cancel")
                } <
                /a> <
                /div> <
                /div> <
                /form> <
                />
            ) : ( <
                div className = "form-group" >
                <
                h3 > {
                    trans("Password successfully reset")
                } < /h3> <
                p > {
                    trans(
                        "To continue, you need to log out of the Wattpad app on your mobile device and log in with your new password."
                    )
                } <
                /p> <
                /div>
            )
        } <
        /div>
    );
};

ResetPassword.propTypes = {
    authToken: PropTypes.string,
    isFromPushNotification: PropTypes.bool,
    username: PropTypes.string,
    name: PropTypes.string
};