import PropTypes from "prop-types";
import React, {
    useState
} from "react";
import EmailSignup from "./EmailSignup";
import classNames from "classnames";
import {
    useTrans
} from "../../hooks";
import ThirdPartySignup from "./ThirdPartySignup";

const SignupForm = ({
    focus = true,
    formType,
    nextUrl = "/home",
    subtitle,
    title,
    toggleForm
}) => {
    const {
        trans
    } = useTrans();
    const [isEmailFormView, setIsEmailFormView] = useState(false);

    const toggleFormView = () => setIsEmailFormView(!isEmailFormView);

    return ( <
        div id = "authentication"
        className = {
            classNames("signup-form", {
                sidebar: formType === "sidebar"
            })
        } >
        {
            formType !== "sidebar" && ( <
                h1 className = "title" > {
                    title ? title : trans("Join Wattpad")
                } < /h1>
            )
        }

        {
            subtitle ? ( <
                h2 className = "subtitle"
                dangerouslySetInnerHTML = {
                    {
                        __html: subtitle
                    }
                }
                />
            ) : ( <
                p className = "subtitle" > {
                    trans(
                        "Be part of a global community of readers and writers, all connected through the power of story."
                    )
                } <
                /p>
            )
        }

        <
        div className = "panel-body" > {
            isEmailFormView ? ( <
                EmailSignup formType = {
                    formType
                }
                nextUrl = {
                    nextUrl
                }
                toggleFormView = {
                    toggleFormView
                }
                />
            ) : ( <
                ThirdPartySignup focus = {
                    focus
                }
                nextUrl = {
                    nextUrl
                }
                toggleForm = {
                    toggleForm
                }
                toggleFormView = {
                    toggleFormView
                }
                />
            )
        } <
        /div> <
        /div>
    );
};

SignupForm.propTypes = {
    focus: PropTypes.bool,
    formType: PropTypes.string,
    nextUrl: PropTypes.string,
    subtitle: PropTypes.string,
    title: PropTypes.string,
    toggleForm: PropTypes.func.isRequired
};

export default SignupForm;