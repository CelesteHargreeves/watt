import PropTypes from "prop-types";
import React, {
    useState
} from "react";
import {
    useTrans
} from "../../hooks";
import EmailLogin from "./EmailLogin";
import ThirdPartyLogin from "./ThirdPartyLogin";

const LoginForm = ({
    focus = true,
    msg,
    nextUrl = "/home",
    notice,
    toggleForm
}) => {
    const {
        trans
    } = useTrans();
    const [isEmailFormView, setIsEmailFormView] = useState(false);

    const toggleFormView = () => setIsEmailFormView(!isEmailFormView);

    return ( <
        div id = "authentication-panel"
        className = "login-form" >
        <
        p className = "title" > {
            trans("Log in to Wattpad")
        } < /p> <
        div className = "panel-body" > {
            isEmailFormView ? ( <
                EmailLogin msg = {
                    msg
                }
                nextUrl = {
                    nextUrl
                }
                notice = {
                    notice
                }
                toggleFormView = {
                    toggleFormView
                }
                />
            ) : ( <
                ThirdPartyLogin focus = {
                    focus
                }
                msg = {
                    msg
                }
                nextUrl = {
                    nextUrl
                }
                notice = {
                    notice
                }
                toggleForm = {
                    toggleForm
                }
                toggleFormView = {
                    toggleFormView
                }
                />
            )
        } <
        /div> <
        footer className = "signup-link" >
        <
        span > {
            trans("Don't have an account? ")
        } <
        button className = "signup-link__btn"
        onClick = {
            toggleForm
        } > {
            trans("Sign up")
        } <
        /button> <
        /span> <
        /footer> <
        /div>
    );
};

LoginForm.propTypes = {
    focus: PropTypes.bool,
    msg: PropTypes.string,
    nextUrl: PropTypes.string,
    notice: PropTypes.string,
    toggleForm: PropTypes.func
};

export default LoginForm;