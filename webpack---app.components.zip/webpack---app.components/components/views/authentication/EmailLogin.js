import PropTypes from "prop-types";
import React from "react";
import {
    FormField,
    Icon
} from "../../shared-components";
import {
    useTrans
} from "../../hooks";

// Composed components

const EmailLogin = ({
    msg,
    nextUrl = "/home",
    notice,
    toggleFormView
}) => {
    const actionURL = `/login?nextUrl=${nextUrl}`;
    const {
        trans
    } = useTrans();
    return ( <
        >
        <
        form id = "login-form"
        action = {
            actionURL
        }
        method = "POST" >
        <
        div className = "input-group-vertical" >
        <
        FormField name = "username"
        label = {
            trans("Username or Email")
        }
        form = "login"
        inputType = "text"
        showLabel = {
            true
        }
        autofocus /
        >
        <
        FormField name = "password"
        label = {
            trans("Password")
        }
        form = "login"
        inputType = "password"
        showVisibilityToggle = {
            true
        }
        showLabel = {
            true
        }
        /> <
        /div> <
        input type = "submit"
        className = "btn btn-lg btn-primary btn-block enable submit-btn"
        value = {
            trans("Log in")
        }
        /> <
        /form> <
        div className = "password-forgot" >
        <
        a href = {
            `/forgot?nextUrl=${nextUrl}`
        } > {
            trans("Forgot password?")
        } < /a> <
        /div> {
            msg && ( <
                div className = "alert alert-danger"
                role = "alert" >
                <
                Icon iconName = "fa-info"
                height = "16"
                color = "wp-lighterror" / > {
                    msg
                } <
                /div>
            )
        } {
            notice && ( <
                div className = "alert alert-info"
                role = "alert" >
                <
                Icon iconName = "fa-info"
                height = "16"
                color = "wp-neutral-2" / > {
                    notice
                } <
                /div>
            )
        } <
        div className = "back-link-container" >
        <
        button className = "back-link"
        onClick = {
            toggleFormView
        } >
        <
        span className = "fa fa-left fa-wp-neutral-1 back-icon" / > {
            trans("Back to all login options")
        } <
        /button> <
        /div> <
        />
    );
};

EmailLogin.propTypes = {
    msg: PropTypes.string,
    nextUrl: PropTypes.string,
    notice: PropTypes.string,
    toggleFormView: PropTypes.func
};

export default EmailLogin;