import React, {
    useEffect
} from "react";
import PropTypes from "prop-types";
import ConnectImage from "../../shared-components/ConnectImage";

export function GoogleAuth({
    googleCta,
    nextUrl
}) {
    useEffect(() => {
        if ($("#google-root").length === 0) {
            $.getScript("https://apis.google.com/js/api.js", function() {
                // Loads the client library and the auth2 library together; saves one network request
                window.gapi.load("client:auth2");
            });

            $("body").append("<div id='google-root'></div>");
        }
    }, []);

    const onGoogleAuth = () => {
        window.gapi.auth2.authorize({
                client_id: wattpad.googleClientId,
                scope: "profile openid email https://www.googleapis.com/auth/user.birthday.read" // The things we want to retrieve from Google login.
            },
            function(response) {
                if (response.access_token) {
                    var data = {
                            token: response.access_token,
                            type: "google",
                            redirect: true
                        },
                        dataStr = encodeURIComponent(JSON.stringify(data));
                    window.location.href =
                        "/oauth-auth?nextUrl=" +
                        wattpad.utils.getNextUrl(nextUrl, window.location.href) +
                        "&data=" +
                        dataStr;
                }
            }
        );
    };

    return ( <
        button onClick = {
            onGoogleAuth
        }
        className = "btn btn-google btn-block" >
        <
        ConnectImage name = "/shared/google_login_color.png"
        title = "Google Login"
        width = "24"
        className = "google-login-logo"
        aria - hidden = "true" /
        >
        <
        span >
        <
        span className = "auth-btn" > {
            googleCta
        } < /span> <
        /span> <
        /button>
    );
}
GoogleAuth.propTypes = {
    googleCta: PropTypes.string.isRequired,
    nextUrl: PropTypes.string
};