import PropTypes from "prop-types";
import React from "react";
import {
    Icon
} from "../../shared-components";
import {
    useTrans
} from "../../hooks";
import ThirdPartyAuth from "./ThirdPartyAuth";

const ThirdPartyLogin = ({
    focus,
    msg,
    nextUrl = "/home",
    notice,
    toggleFormView
}) => {
    const {
        trans
    } = useTrans();

    return ( <
        >
        <
        ThirdPartyAuth source = "login"
        nextUrl = {
            nextUrl
        }
        focus = {
            focus
        }
        /> <
        div className = "hr-with-text" >
        <
        div className = "horizontal-line" / >
        <
        span className = "or" > OR < /span> <
        div className = "horizontal-line" / >
        <
        /div> <
        button className = "btn-block btn-primary"
        onClick = {
            toggleFormView
        } > {
            trans("Log in")
        } <
        /button>

        <
        div className = "password-forgot" >
        <
        a href = {
            `/forgot?nextUrl=${nextUrl}`
        } > {
            trans("Forgot password?")
        } < /a> <
        /div> {
            msg && ( <
                div className = "alert alert-danger"
                role = "alert" >
                <
                Icon iconName = "fa-info"
                height = "16"
                color = "wp-lighterror" / > {
                    msg
                } <
                /div>
            )
        } {
            notice && ( <
                div className = "alert alert-info"
                role = "alert" >
                <
                Icon iconName = "fa-info"
                height = "16"
                color = "wp-neutral-2" / > {
                    notice
                } <
                /div>
            )
        } <
        />
    );
};

ThirdPartyLogin.propTypes = {
    focus: PropTypes.bool,
    msg: PropTypes.string,
    nextUrl: PropTypes.string,
    notice: PropTypes.string,
    toggleFormView: PropTypes.func
};

export default ThirdPartyLogin;