import PropTypes from "prop-types";
import React, {
    useState,
    useRef,
    useMemo
} from "react";
import ReactTooltip from "react-tooltip";
import BirthdayFields from "./BirthdayFields";
import {
    withValidation,
    FormField,
    Icon
} from "../../shared-components";
import {
    useTrans
} from "../../hooks";
import PasswordFields from "../../shared-components/PasswordFields";
import {
    Button,
    ButtonVariant
} from "@wattpad/web-ui-library";

const EmailSignup = ({
    formType,
    nextUrl = "/home",
    toggleFormView
}) => {
    const {
        trans
    } = useTrans();

    const [isUsernameValid, setIsUsernameValid] = useState(false);
    const [isEmailValid, setIsEmailValid] = useState(false);
    const [isPasswordValid, setIsPasswordValid] = useState(false);
    const [isBirthdayValid, setIsBirthdayValid] = useState(false);
    const [usernameValue, setUsernameValue] = useState();

    const usernameInput = useRef();
    const emailInput = useRef();
    const passwordInput = useRef();
    const birthdayInput = useRef();

    const ValidatedFormField = useMemo(() => withValidation(FormField), []);

    // In order for the model to work properly in React needs to be hold as a reference
    const validationModel = useRef(
        window.app ? .models && new window.app.models.Authsignup()
    );

    const validateSignupForm = (isValid, key) => {
        if (key.toLowerCase().includes("username")) {
            setIsUsernameValid(isValid);
        } else if (key.toLowerCase().includes("email")) {
            setIsEmailValid(isValid);
        } else if (key.toLowerCase().includes("password")) {
            setIsPasswordValid(isValid);
        } else if (key.toLowerCase().includes("birthday")) {
            setIsBirthdayValid(isValid);
        }
    };

    const actionURL = `/signup?nextUrl=${nextUrl}`;
    const signupFrom = `new_landing_signup`;
    const policy_agreement = trans("By continuing, you agree to Wattpad's <a href='/terms'>Terms of Service</a> and <a href='/privacy'>Privacy Policy</a>."); // prettier-ignore
    const isValidated =
        isPasswordValid && isEmailValid && isUsernameValid && isBirthdayValid;

    return ( <
        >
        <
        form id = "signupForm"
        action = {
            actionURL
        }
        method = "POST"
        onSubmit = {
            e => {
                if (!isPasswordValid) {
                    e.preventDefault();
                    passwordInput.current.focus();
                }
                if (!isEmailValid) {
                    e.preventDefault();
                    emailInput.current.focus();
                }
                if (!isUsernameValid) {
                    e.preventDefault();
                    usernameInput.current.focus();
                }
                if (!isBirthdayValid) {
                    e.preventDefault();
                    birthdayInput.current.focus();
                }
            }
        } >
        <
        input type = "hidden"
        name = "signup-from"
        value = {
            signupFrom
        }
        /> <
        input type = "hidden"
        name = "form-type"
        value = {
            formType || ""
        }
        /> <
        div className = "input-group-vertical" >
        <
        ValidatedFormField name = "username"
        label = {
            trans("Username")
        }
        form = "signup"
        inputType = "text"
        title = {
            trans("Enter username")
        }
        inputRef = {
            usernameInput
        }
        autofocus validationModel = {
            validationModel.current
        }
        showLabel = {
            true
        }
        onValid = {
            key => validateSignupForm(true, key)
        }
        onInvalid = {
            key => validateSignupForm(false, key)
        }
        onBlur = {
            () =>
            wattpad ? .testGroups.NEW_PW_POLICY_EMAIL_SIGNUP &&
            setUsernameValue(usernameInput.current.value)
        }
        /> <
        ValidatedFormField name = "email"
        label = {
            trans("E-mail")
        }
        form = "signup"
        inputType = "text"
        title = {
            trans("Enter E-mail")
        }
        validationModel = {
            validationModel.current
        }
        inputRef = {
            emailInput
        }
        showLabel = {
            true
        }
        onValid = {
            key => validateSignupForm(true, key)
        }
        onInvalid = {
            key => validateSignupForm(false, key)
        }
        /> <
        PasswordFields username = {
            usernameValue
        }
        validatePassword = {
            setIsPasswordValid
        }
        /> <
        div className = "birthday-info" >
        <
        span className = "birthday-title" > {
            trans("Birthday")
        } < /span> <
        div aria - label = "why we ask for your birthday"
        data - tip = {
            trans(
                "We ask for your date of birth so you can have the right Wattpad experience for your age."
            )
        } >
        <
        Icon iconName = "fa-info"
        height = "16"
        color = "wp-neutral-1"
        className = "tooltip-icon" /
        >
        <
        /div> <
        ReactTooltip className = "tool-tip"
        effect = "solid" / >
        <
        /div> <
        div className = "birthday-fields" >
        <
        BirthdayFields inputRef = {
            birthdayInput
        }
        validationModel = {
            validationModel.current
        }
        onValid = {
            () => validateSignupForm(true, "birthday")
        }
        onInvalid = {
            () => validateSignupForm(false, "birthday")
        }
        /> <
        /div> <
        /div> <
        Button fullWidth disabled = {!isValidated
        }
        variant = {
            ButtonVariant.PRIMARY
        }
        aria - label = "Sign up with email" >
        {
            trans("Sign up with email")
        } <
        /Button> <
        /form> <
        span className = "policy-agreement"
        dangerouslySetInnerHTML = {
            {
                __html: policy_agreement
            }
        }
        /> <
        div className = "back-link-container" >
        <
        button className = "back-link"
        onClick = {
            toggleFormView
        } >
        <
        span className = "fa fa-left fa-wp-neutral-1 back-icon" / > {
            trans("Back to all signup options")
        } <
        /button> <
        /div> <
        />
    );
};

EmailSignup.propTypes = {
    formType: PropTypes.string,
    nextUrl: PropTypes.string,
    toggleFormView: PropTypes.func.isRequired
};

export default EmailSignup;