import React from "react";
import PropTypes from "prop-types";
import {
    Icon
} from "../../shared-components";
import {
    useTrans
} from "../../hooks";

import {
    GoogleAuth
} from "./GoogleAuth";

function ThirdPartyAuth({
    source,
    nextUrl,
    focus = true
}) {
    const {
        trans
    } = useTrans();
    const fbCta =
        source === "signup" ?
        trans("Sign up with Facebook") :
        trans("Log in with Facebook");

    const googleCta =
        source === "signup" ?
        trans("Sign up with Google") :
        trans("Log in with Google");
    return ( <
        div className = "signin-buttons" > {
            /* TODO: autoFocus is used as a hack currently to avoid accessibility issues with modals. 
                  Remove it once we have a guild-wide solution for keyboard and screen reader trapping. */
        } <
        button className = "btn btn-facebook btn-block"
        autoFocus = {
            focus
        } >
        <
        Icon iconName = "fa-facebook-official"
        height = "24"
        color = "wp-neutral-5" /
        >
        <
        span >
        <
        span className = "auth-btn" > {
            fbCta
        } < /span> <
        /span> <
        /button>

        <
        GoogleAuth googleCta = {
            googleCta
        }
        nextUrl = {
            nextUrl
        }
        /> <
        /div>
    );
}
ThirdPartyAuth.propTypes = {
    source: PropTypes.string,
    nextUrl: PropTypes.string,
    focus: PropTypes.bool
};
export default ThirdPartyAuth;