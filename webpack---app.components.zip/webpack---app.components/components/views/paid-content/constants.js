import {
    ASSET_SERVER
} from "../../constants";

// We use only one currency right now, so hardcode the ID to avoid
// having to make a call to `/virtual-currencies/`.
export const CURRENCY_ID = "wp1";

// Minimum time the wallet animation needs to complete
export const DEDUCTING_ANIMATION_DELAY = 2000;
export const SUBTRACTING_ANIMATION_DELAY = 2200;
export const COIN_TRANSITION_DELAY = 400;

// Action types
export const SET_WALLET_BALANCE = "set_wallet_balance";
export const BUYING_CONTENT = "buying_content";
export const BOUGHT_CONTENT = "bought_content";

export const WALLET_ANIMATION_STEP = "animation_step";

export const WALLET_STATES = {
    DEFAULT: "default",
    COIN: "coin",
    DEDUCTING: "deducting",
    SUBTRACTING: "subtracting"
};

// NOTE: copy temporary for now, translate once it's final
export const ONBOARDING_SLIDES = trans => [{
        title: trans("Introducing Paid Stories"),
        content: trans(
            "Thank writers for creating the stories you love by monetarily supporting them."
        ),
        imageUrl: "paid-content/lifting-hand.png"
    },
    {
        title: trans("Continue exploring free stories"),
        content: trans(
            "Millions of stories on Wattpad will always be free to read. Promise."
        ),
        imageUrl: "paid-content/free-stories.png"
    },
    {
        title: trans("Be the first to support writers"),
        content: trans(
            "Unlocking Paid Stories with Coins supports your favorite writers"
        ),
        imageUrl: "paid-content/currency.png",
        learnMoreLink: "https://www.wattpad.com/paidstories/"
    },
    {
        title: trans("Premium subscribers get bonus Coins"),
        content: trans(
            "Only Wattpad Premium subscribers are rewarded with bonus Coins with every Wattpad Coin pack purchase"
        ),
        imageUrl: "paid-content/treasure-chest.png",
        learnMoreLink: "https://premium.wattpad.com/",
        showToPremiumOnly: true
    }
];

// TODO: fetch this from backend instead of hardcoding once backend is
// ready to serve SKUs.
export const HARDCODED_NONPREMIUM_COIN_PACKS = {
    Wattpad_Coins_9: {
        value: 9,
        premium_value: 15,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_1_240x240.png`,
        price: "0.99"
    },
    Wattpad_Coin_74: {
        value: 74,
        premium_value: 99,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_2_240x240.png`,
        featured: true,
        price: "3.99"
    },
    Wattpad_Coin_244: {
        value: 244,
        premium_value: 325,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_3_240x240.png`,
        price: "8.99"
    },
    Wattpad_Coin_400: {
        value: 400,
        premium_value: 533,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_4_240x240.png`,
        price: "13.99"
    }
};

export const HARDCODED_PREMIUM_COIN_PACKS = {
    Premium_BonusCoins_15Pack: {
        value: 15,
        non_premium_value: 9,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_1_240x240.png`,
        price: "0.99"
    },
    Premium_BonusCoins_99Pack: {
        value: 99,
        non_premium_value: 74,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_2_240x240.png`,
        featured: true,
        price: "3.99"
    },
    Premium_BonusCoins_325Pack: {
        value: 325,
        non_premium_value: 244,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_3_240x240.png`,
        price: "8.99"
    },
    Premium_BonusCoins_533Pack: {
        value: 533,
        non_premium_value: 400,
        illustration_url: `${ASSET_SERVER}/image/money_coin_package_4_240x240.png`,
        price: "13.99"
    }
};