import React, {
    useEffect
} from "react";
import PropTypes from "prop-types";
import classnames from "classnames";

import {
    ConnectImage
} from "../../shared-components";
import {
    toggleModal
} from "../../shared-components/modals/actions";
import {
    useTrans
} from "../../hooks";

const BuyCoinsModal = ({
    isDesktop,
    appLink,
    trackCoinsEvents,
    thankForInterest = false
}) => {
    useEffect(
        () => {
            trackCoinsEvents(null, "view");

            return () => {
                trackCoinsEvents(null, "dismiss");
            };
        }, [trackCoinsEvents]
    );

    const {
        trans
    } = useTrans();
    const learnMoreLink = "https://www.wattpad.com/paidstories/";

    return ( <
        React.Fragment >
        <
        div className = "coins-cta background" >
        <
        h3 > {
            thankForInterest ?
            trans(
                "Thank you for your interest! You can purchase Coins on the app."
            ) :
                trans("Unlock Paid Stories with Coins")
        } <
        /h3> <
        p > { /* prettier-ignore */
            trans("Once you purchase Coins, you can unlock stories, and support writers, anywhere you use Wattpad - both on the app and on web!")
        } <
        /p> <
        /div> <
        div className = "how-to-buy" > {
            isDesktop ? ( <
                HowToBuyDesktop trans = {
                    trans
                }
                learnMoreLink = {
                    learnMoreLink
                }
                />
            ) : ( <
                HowToBuyMobile trans = {
                    trans
                }
                appLink = {
                    appLink
                }
                onApplinkClick = {
                    () => trackCoinsEvents("purchase_cta", "click")
                }
                />
            )
        } <
        /div> <
        /React.Fragment>
    );
};

BuyCoinsModal.propTypes = {
    isDesktop: PropTypes.bool.isRequired,
    appLink: PropTypes.string,
    trackCoinsEvents: PropTypes.func.isRequired,
    thankForInterest: PropTypes.bool
};

const HowToBuyMobile = ({
    appLink,
    trans,
    onApplinkClick
}) => ( <
    React.Fragment >
    <
    div >
    <
    CtaStep num = {
        1
    } > { /* prettier-ignore */
        trans("Open the Wattpad app on your mobile device and tap on the profile icon to go to your personal profile.")
    } <
    /CtaStep> <
    CtaStep num = {
        2
    } > { /* prettier-ignore */
        trans("Tap on the plus icon beside your Coin wallet to view the Coin Shop.")
    } <
    /CtaStep> <
    CtaStep num = {
        3
    } > { /* prettier-ignore */
        trans("Choose and purchase a Coin bundle to unlock your favorite stories.")
    } <
    /CtaStep> <
    /div> <
    a href = {
        appLink
    }
    onClick = {
        onApplinkClick
    }
    className = "btn btn-orange" > {
        trans("Go to the app")
    } <
    /a> <
    /React.Fragment>
);

HowToBuyMobile.propTypes = {
    appLink: PropTypes.string,
    trans: PropTypes.func.isRequired,
    onApplinkClick: PropTypes.func.isRequired
};

const HowToBuyDesktop = ({
    trans,
    learnMoreLink
}) => ( <
    React.Fragment >
    <
    div className = "row" >
    <
    CtaStep num = {
        1
    }
    isDesktop > { /* prettier-ignore */
        trans("Open the Wattpad app on your mobile device and tap on the profile icon to go to your personal profile.")
    } <
    /CtaStep> <
    CtaStep num = {
        2
    }
    isDesktop > { /* prettier-ignore */
        trans("Tap on the plus icon beside your Coin wallet to view the Coin Shop.")
    } <
    /CtaStep> <
    CtaStep num = {
        3
    }
    isDesktop > { /* prettier-ignore */
        trans("Choose and purchase a Coin bundle to unlock your favorite stories.")
    } <
    /CtaStep> <
    /div> <
    div className = "row instructions-images" >
    <
    StepImage step = "1" / >
    <
    StepImage step = "2" / >
    <
    StepImage step = "3" / >
    <
    /div> <
    div className = "learn-more" >
    <
    a href = {
        learnMoreLink
    }
    target = "_blank"
    rel = "noopener noreferrer" > { /* prettier-ignore */
        trans('Learn how your support is empowering writers')
    } <
    /a> <
    /div> <
    /React.Fragment>
);

HowToBuyDesktop.propTypes = {
    trans: PropTypes.func.isRequired,
    learnMoreLink: PropTypes.string.isRequired
};

const CtaStep = ({
    num,
    isDesktop,
    children
}) => ( <
    div className = {
        classnames("cta-step", {
            "col-sm-4": isDesktop
        })
    } >
    <
    div className = "step-circle" >
    <
    div > {
        num
    } < /div> <
    /div> <
    p className = "step-instruction" > {
        children
    } < /p> <
    /div>
);

CtaStep.propTypes = {
    num: PropTypes.number.isRequired,
    children: PropTypes.node.isRequired,
    isDesktop: PropTypes.bool
};

const StepImage = ({
    step
}) => ( <
    div className = "col-sm-4" >
    <
    ConnectImage name = {
        `paid-content/buy-coins-step-${step}.png`
    }
    /> <
    /div>
);

StepImage.propTypes = {
    step: PropTypes.string.isRequired
};

// The modal is triggered by Backbone code that can't use JSX or
// Redux, so export a wrapper that will display the modal
export const showBuyCoinsModal = props => {
    const {
        isDesktop
    } = props;

    window.store.dispatch(
        toggleModal({
            className: classnames("buy-coins", {
                desktop: isDesktop,
                mobile: !isDesktop
            }),
            component: () => < BuyCoinsModal { ...props
            }
            /> / / eslint - disable - line react / display - name
        })
    );
};