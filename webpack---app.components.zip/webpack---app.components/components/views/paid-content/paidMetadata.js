const namespace = "PAID_CONTENT_METADATA";

const SET_PAID_CONTENT_METADATA = `${namespace}/SET`;
const CLEAR_PAID_CONTENT_METADATA = `${namespace}/CLEAR`;

export function fetchPaidContentMetadata(storyId, partIds) {
    return function(dispatch, getState) {
        // To prevent extra fetches, cache the metadata here. The cache is
        // cleared on purchase, which is almost always why the metadata
        // would change.  If the user purchases on another platform, they
        // will have to refresh to clear the cache manually.
        const {
            paidMetadata
        } = getState();
        if (paidMetadata.stories[storyId] !== undefined) {
            return Promise.resolve();
        }

        const commaSeparatedParts = partIds.join(",");
        return Promise.resolve(
            $.get(`/v5/story/${storyId}/paid-content/metadata`, {
                parts: commaSeparatedParts
            })
        ).then(metadata => {
            dispatch({
                type: SET_PAID_CONTENT_METADATA,
                storyId,
                metadata
            });
        });
    };
}

export function cacheBustPaidContentMetadata(storyId, partIds) {
    return {
        type: CLEAR_PAID_CONTENT_METADATA,
        storyId,
        partIds
    };
}

export default function paidMetadata(
    state = {
        parts: {},
        stories: {}
    },
    action
) {
    switch (action.type) {
        case SET_PAID_CONTENT_METADATA:
            {
                const {
                    metadata,
                    storyId
                } = action;

                const {
                    story,
                    parts: newParts
                } = metadata;
                // Convert from parts list, to partId => part metadata map
                const newPartsMap = newParts.reduce((acc, part) => {
                    acc[part.id] = part;
                    return acc;
                }, {});

                const {
                    stories,
                    parts
                } = state;
                return {
                    ...state,
                    stories: { ...stories,
                        [storyId]: story
                    },
                    parts: { ...parts,
                        ...newPartsMap
                    }
                };
            }
        case CLEAR_PAID_CONTENT_METADATA:
            {
                const {
                    storyId,
                    partIds
                } = action;
                const stories = _.omit(state.stories, storyId);
                const parts = _.omit(state.parts, partIds);
                return { ...state,
                    stories,
                    parts
                };
            }
        default:
            return state;
    }
}