import React, {
    useState,
    useEffect,
    useMemo
} from "react";
import PropTypes from "prop-types";
import Advertisement from "./../../shared-components/Advertisement";
import Badges from "./../../shared-components/Badges";
import ReportStoryCard from "../../shared-components/ReportStoryCard";
import StoryRanksCard from "../../shared-components/StoryRanksCard";
import TableOfContents from "../../shared-components/TableOfContents";
import StoryParts from "../../shared-components/StoryParts";
import StoryPartsCard from "../../shared-components/StoryPartsCard";
import Description from "./../../shared-components/Description";
import StoryActions from "./../../shared-components/StoryActions";
import StoryHeader from "./../../shared-components/StoryHeader";
import StoryList from "../../shared-components/StoryList";
import StoryStats from "./../../shared-components/StoryStats";
import AdminPanel from "../../shared-components/AdminPanel";
import TagCarousel from "../tags/TagCarousel";
// import TagGrid from "../tags/TagGrid";
import {
    TagCloud as TagGrid
} from "@wattpad/web-ui-library";
import StoryError500 from "../../shared-components/StoryError500";

import {
    useFeatureFlags,
    useTrans
} from "../../hooks";
import {
    getReadTime,
    formatReadTime,
    fromNow,
    sanitizeHTML
} from "../../helpers";
import {
    STORY_COPYRIGHT_LICENSES
} from "../../../components/views/works-item-details/story-details/constants";
var Swatch = require("../../../assets/swatch");
import {
    useSelector,
    useDispatch
} from "react-redux";
import {
    getCollectionsForStoryIds,
    getReadingLists
} from "../home/actions";
import AuthForm from "../authentication/AuthForm";

const StoryDetails = ({
    currentUserRoles,
    username, // TODO: evaluate moving away from this and solely using isLoggedIn
    userLang,
    isLoggedIn,
    languages,
    onLanguageChange,
    onCategoryChange,
    categories,
    onFileSelected,
    onCoverRemove,
    isDesktop,
    storyData: {
        id,
        title,
        description,
        createDate,
        cover,
        user = {}, // author
        isPaywalled,
        isPaidPreview,
        length,
        numParts,
        storyTags,
        readCount,
        completed,
        draft,
        deleted,
        rating,
        voteCount,
        firstPartId,
        serverError,
        language,
        lastPublishedPart,
        parts,
        storyReportUrl,
        storyTranslateUrl,
        tagRankings,
        recommendedStories = [],
        sources,
        writerPreviewHasBannedCover,
        copyright,
        canDisplayAdvertisement,
        shouldDelayAds,
        shouldShowAds,
        firstStoryPart,
        storyCategories,
        url
    } = {},
    signupModel
}) => {
    const featureFlags = useFeatureFlags();

    const storyTagsWithColor = useMemo(
        () => ({
            ...storyTags,
            tags: storyTags &&
                storyTags.tags.map(tag => ({
                    ...tag,
                    bgColor: `${Swatch["ds-neutral-40"]}`,
                    color: `${Swatch["ds-neutral-80"]}`
                }))
        }), [storyTags]
    );

    const dispatch = useDispatch();
    const readingLists = useSelector(state => state.homeSections.readingLists);
    const storiesCollections = useSelector(
        state => state.homeSections.storiesCollections
    );

    const [storyPartsVisible, setStoryPartsVisible] = useState(false);
    const [readingPosition, setReadingPosition] = useState({});
    const [isFirstPageLoad, setFirstPageLoad] = useState(true);

    const copyrightLicenses = STORY_COPYRIGHT_LICENSES();
    const copyrightId = copyright ? copyright + "" : "1";
    let license =
        copyrightLicenses &&
        copyrightLicenses.find(license => license.value.toString() === copyrightId);

    const handleStoryPartsCardClick = () => {
        setStoryPartsVisible(!storyPartsVisible);
    };

    useEffect(
        () => {
            if (isFirstPageLoad) {
                // Redirect to canonical url - we're trying to switch to using canonical url everywhere
                if (
                    url + window.location.search + window.location.hash !==
                    window.location.href
                ) {
                    if (typeof wattpad !== "undefined" && title) {
                        history.replaceState({},
                            title,
                            wattpad.utils.formatStoryUrl(url) +
                            window.location.search +
                            window.location.hash
                        );
                    }
                }
                // Page view event
                window.te.push("event", "app", "page", null, "view", {
                    page: "story_details"
                });
                // Story view event
                window.te.push("event", "story", null, null, "view", {
                    storyid: id,
                    page: "story_details",
                    type: "primary",
                    source: "story_details",
                    algo_source: sources || ""
                });

                setFirstPageLoad(false);

                if (username) {
                    dispatch(getReadingLists());
                    dispatch(getCollectionsForStoryIds(id));
                }
            }
        }, [id, sources, isFirstPageLoad, username, dispatch, url, title]
    );

    useEffect(
        () => {
            if (username) {
                $.get("/apiv2/syncreadingposition", {
                    story_id: firstPartId
                }).then(data => {
                    setReadingPosition(data || {});
                });
            }
        }, [username, firstPartId]
    );

    const {
        trans
    } = useTrans();

    const size = "16";
    const viewBox = "16";
    const statsItems = [{
            icon: "views",
            label: trans("Reads"),
            size: size,
            viewBox: viewBox,
            value: readCount
        },
        {
            icon: "votesBeta",
            label: trans("Votes"),
            size: size,
            viewBox: viewBox,
            value: voteCount
        },
        {
            icon: "partsBeta",
            label: trans("Parts"),
            size: size,
            viewBox: viewBox,
            value: numParts
        }
    ];

    const lastUpdated = lastPublishedPart ?
        fromNow(lastPublishedPart.createDate, {
            fuzzyTime: true
        }) :
        null;

    // readTime is a best guess that currently only supports english stories.
    // Gate off displaying this StatsItem for other languages.
    if (language === 1) {
        const readTime = formatReadTime(getReadTime(length));
        statsItems.push({
            icon: "readTime",
            label: trans("Time"),
            size: size,
            viewBox: viewBox,
            hoursVal: readTime.hours,
            minutesVal: readTime.minutes
        });
    }

    const signupSubtitle = trans(
        "Get notified when %s is updated",
        "<strong>" + sanitizeHTML(title) + "</strong>"
    );

    return ( <
        div className = "story-details-page" > {
            serverError ? ( <
                StoryError500 / >
            ) : ( <
                >
                <
                StoryHeader title = {
                    title
                }
                cover = {
                    cover
                }
                user = {
                    user
                }
                draft = {
                    draft
                }
                isLoggedInUser = {!!username
                }
                isPaid = {
                    isPaywalled
                }
                isPaidPreview = {
                    isPaidPreview
                }
                numParts = {
                    numParts
                }
                readCount = {
                    readCount
                }
                storyLength = {
                    length
                }
                voteCount = {
                    voteCount
                }
                firstPartId = {
                    firstPartId
                }
                storyId = {
                    id
                }
                sources = {
                    sources
                }
                statsItems = {
                    statsItems
                }
                readingLists = {
                    readingLists
                }
                storiesCollections = {
                    storiesCollections
                }
                writerPreviewHasBannedCover = {
                    writerPreviewHasBannedCover
                }
                /> <
                div className = "story-info-container" >
                <
                div className = "left-container" > {
                    deleted && ( <
                        p className = "story-status story-status--important xxs-container-padding" > {
                            trans("Deleted")
                        } <
                        /p>
                    )
                } {
                    draft &&
                        !deleted && ( <
                            p className = "story-status xxs-container-padding" > {
                                trans("Draft")
                            } <
                            /p>
                        )
                } <
                StoryStats statsItems = {
                    statsItems
                }
                className = {
                    "shown-xxs"
                }
                showTooltip /
                > {
                    featureFlags.NEW_ADMIN_PANEL &&
                    (currentUserRoles.isSysAdmin ||
                        currentUserRoles.isAmbassador) && ( <
                        AdminPanel currentUserRoles = {
                            currentUserRoles
                        }
                        user = {
                            user
                        }
                        storyId = {
                            id
                        }
                        storyTranslateUrl = {
                            storyTranslateUrl
                        }
                        languages = {
                            languages
                        }
                        categories = {
                            categories
                        }
                        storyCategories = {
                            storyCategories
                        }
                        onLanguageChange = {
                            onLanguageChange
                        }
                        onCategoryChange = {
                            onCategoryChange
                        }
                        storyLanguage = {
                            language
                        }
                        onFileSelected = {
                            onFileSelected
                        }
                        onCoverRemove = {
                            onCoverRemove
                        }
                        />
                    )
                } <
                Badges isCompleted = {
                    completed
                }
                isMature = {
                    rating === 4
                }
                user = {
                    user
                }
                publishDate = {
                    createDate
                }
                /> {
                    !isDesktop &&
                        canDisplayAdvertisement && ( <
                            Advertisement placement = "storylanding_bottom_mweb"
                            shouldDelayAds = {
                                shouldDelayAds
                            }
                            shouldShowAds = {
                                shouldShowAds
                            }
                            />
                        )
                } <
                Description description = {
                    description
                }
                license = {
                    license
                }
                /> {
                    storyTags && ( <
                        TagGrid tagGridTags = {
                            storyTagsWithColor
                        }
                        onTagClicked = {
                            name => {
                                app.router.navigate(`/stories/${name}`, {
                                    trigger: true
                                });
                            }
                        }
                        className = {
                            "hidden-xxs"
                        }
                        />
                    )
                } {
                    storyTags && ( <
                        TagCarousel relatedTags = {
                            storyTagsWithColor
                        }
                        onTagClicked = {
                            name => {
                                app.router.navigate(`/stories/${name}`, {
                                    trigger: true
                                });
                            }
                        }
                        className = {
                            "shown-xxs"
                        }
                        />
                    )
                } <
                TableOfContents className = {
                    "hidden-xxs"
                }
                lastUpdated = {
                    lastUpdated
                } >
                <
                StoryParts storyId = {
                    id
                }
                sources = {
                    sources
                }
                parts = {
                    parts
                }
                isPaywalled = {
                    isPaywalled
                }
                readingPosition = {
                    readingPosition
                }
                /> <
                /TableOfContents> <
                /div> <
                div className = "xxs-container-padding right-container" > {!isLoggedIn && ( <
                        div className = "signup-modal card hidden-xxs" >
                        <
                        AuthForm formType = "sidebar"
                        subtitle = {
                            signupSubtitle
                        }
                        nextUrl = {
                            (firstStoryPart && firstStoryPart.url) || null
                        }
                        model = {
                            signupModel
                        }
                        focus = {
                            false
                        }
                        /> <
                        /div>
                    )
                } {
                    isDesktop &&
                        canDisplayAdvertisement && ( <
                            Advertisement placement = "storylanding_top"
                            shouldDelayAds = {
                                shouldDelayAds
                            }
                            shouldShowAds = {
                                shouldShowAds
                            }
                            />
                        )
                } <
                StoryRanksCard storyRankings = {
                    tagRankings
                }
                storyId = {
                    id
                }
                /> <
                StoryPartsCard numParts = {
                    numParts
                }
                lastUpdated = {
                    lastUpdated
                }
                className = {
                    "shown-xxs"
                }
                storyPartsVisible = {
                    storyPartsVisible
                }
                handleClick = {
                    handleStoryPartsCardClick
                }
                /> {
                    (storyPartsVisible || typeof window === "undefined") && ( <
                        StoryParts parts = {
                            parts
                        }
                        isPaywalled = {
                            isPaywalled
                        }
                        className = {
                            "shown-xxs"
                        }
                        readingPosition = {
                            readingPosition
                        }
                        />
                    )
                } <
                ReportStoryCard storyId = {
                    id
                }
                storyTitle = {
                    title
                }
                authorUsername = {
                    user.username
                }
                storyReportUrl = {
                    storyReportUrl
                }
                /> {
                    Array.isArray(recommendedStories) &&
                        recommendedStories.length > 0 && ( <
                            StoryList stories = {
                                recommendedStories
                            }
                            userLang = {
                                userLang
                            }
                            page = {
                                "story_details"
                            }
                            />
                        )
                } <
                /div> <
                /div> <
                />
            )
        } <
        div className = "action-bar--sticky shown-xxs" >
        <
        StoryActions isPaid = {
            isPaywalled
        }
        isPaidPreview = {
            isPaidPreview
        }
        firstPartId = {
            firstPartId
        }
        storyId = {
            id
        }
        isLoggedInUser = {!!username
        }
        readingLists = {
            readingLists
        }
        storiesCollections = {
            storiesCollections
        }
        sources = {
            sources
        }
        isMobile = {
            true
        }
        draft = {
            draft
        }
        /> <
        /div> <
        /div>
    );
};

StoryDetails.defaultProps = {
    onLanguageChange: () => {},
    onCategoryChange: () => {},
    onFileSelected: () => {},
    onCoverRemove: () => {},
    currentUserRoles: {
        isAdmin: false,
        isAmbassador: false
    }
};

StoryDetails.propTypes = {
    storyData: PropTypes.shape({
        id: PropTypes.number,
        title: PropTypes.string,
        description: PropTypes.string,
        createDate: PropTypes.string,
        user: PropTypes.shape({
            username: PropTypes.string,
            avatar: PropTypes.string,
            totalReads: PropTypes.number,
            age: PropTypes.number,
            country: PropTypes.string
        }),
        cover: PropTypes.string,
        completed: PropTypes.bool,
        draft: PropTypes.bool,
        deleted: PropTypes.bool,
        isPaywalled: PropTypes.bool,
        isPaidPreview: PropTypes.bool,
        length: PropTypes.number,
        numParts: PropTypes.number,
        storyTags: PropTypes.object,
        readCount: PropTypes.number,
        rating: PropTypes.number,
        voteCount: PropTypes.number,
        firstPartId: PropTypes.number,
        serverError: PropTypes.bool,
        storyReportUrl: PropTypes.string,
        storyTranslateUrl: PropTypes.string,
        tagRankings: PropTypes.array,
        sources: PropTypes.array,
        copyright: PropTypes.number,
        canDisplayAdvertisement: PropTypes.bool,
        shouldDelayAds: PropTypes.bool,
        shouldShowAds: PropTypes.bool,
        firstStoryPart: PropTypes.shape({
            url: PropTypes.string
        }),
        recommendedStories: PropTypes.array,
        url: PropTypes.string
    }),
    currentUserRoles: PropTypes.shape({
        isSysAdmin: PropTypes.bool,
        isAmbassador: PropTypes.bool
    }),
    username: PropTypes.string,
    userLang: PropTypes.number,
    isLoggedIn: PropTypes.bool,
    signupModel: PropTypes.object,
    languages: PropTypes.array,
    categories: PropTypes.array,
    storyCategories: PropTypes.array,
    onLanguageChange: PropTypes.func,
    onCategoryChange: PropTypes.func,
    onFileSelected: PropTypes.func,
    onCoverRemove: PropTypes.func,
    isDesktop: PropTypes.bool
};

export default StoryDetails;