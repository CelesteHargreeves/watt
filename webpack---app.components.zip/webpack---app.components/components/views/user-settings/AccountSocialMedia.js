import PropTypes from "prop-types";
import React from "react";

import {
    Icon
} from "../../shared-components";
import FormField from "./FormField";

export default class AccountSocialMedia extends React.Component {
    getFacebook = () => {
        const {
            facebook
        } = this.props;
        let facebookUrl, facebookNode;

        if (facebook) {
            facebookUrl = "https://www.facebook.com/" + facebook;
            facebookNode = ( <
                div >
                <
                a className = "info"
                href = {
                    facebookUrl
                }
                target = "_new" > {
                    facebookUrl
                } <
                /a> { /* eslint-disable-next-line wp-lint-rules/valid-href */ } <
                a href = "/apiv2/linksocialmedia?action=unlinkfb"
                id = "unlink_fb_btn"
                role = "button"
                tabIndex = "0" >
                <
                img src = "/image/v2/unlink.png"
                width = "16"
                height = "16"
                alt = "unlink.png" /
                >
                <
                /a> <
                /div>
            );
        } else {
            facebookNode = ( <
                div >
                <
                button className = "btn-no-style" >
                <
                img className = "btn-facebook-link"
                alt = "Facebook"
                border = "0"
                width = "89"
                height = "21"
                src = "/image/connect_light_medium_short.gif" /
                >
                <
                /button> <
                span id = "facebook-tooltip"
                className = "help" >
                <
                Icon iconName = "fa-info"
                height = "16"
                color = "wp-neutral-2" / >
                <
                /span> <
                /div>
            );
        }

        return facebookNode;
    };

    render() {
        return ( <
            div >
            <
            FormField label = {
                "Facebook"
            }
            icon = { <
                img
                className = "label-icon"
                src = "/image/icon22_fb.png?"
                alt = "icon22_fb.png"
                border = "0"
                align = "absmiddle" /
                >
            } >
            {
                this.getFacebook()
            } <
            /FormField> <
            /div>
        );
    }
}

AccountSocialMedia.propTypes = {
    facebook: PropTypes.string.isRequired
};