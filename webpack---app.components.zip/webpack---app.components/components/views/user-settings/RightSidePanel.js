import classNames from "classnames";
import PropTypes from "prop-types";
import React from "react";

import {
    isClient,
    injectTrans
} from "../../helpers";

class RightSidePanel extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            editBgStarted: false,
            editAvatarStarted: false
        };
    }

    uploadBackground = () => {
        this.setState({
            editBgStarted: true
        });
    };

    uploadAvatar = () => {
        this.setState({
            editAvatarStarted: true
        });
    };

    updateAvatar = (event, del = false) => {
        if (del) {
            // TODO add delete functionality
        } else {
            const file = event.target.files[0];
            if (file) {
                this.props.saveAvatarChanges(file);
            }
        }
    };

    updateBackground = (event, del = false) => {
        if (del) {
            // TODO add delete functionality
        } else {
            const file = event.target.files[0];
            if (file) {
                this.props.saveBackgroundChanges(file);
            }
        }
    };

    render() {
        const {
            trans,
            avatar,
            backgroundUrl,
            username
        } = this.props;
        const {
            editAvatarStarted,
            editBgStarted
        } = this.state;

        const avatarUploadClasses = classNames("image-upload", {
            show: editAvatarStarted
        });

        const bgUploadClasses = classNames("image-upload", {
            show: editBgStarted
        });

        const avatarUploadButton = classNames("btn btn-small btn-white", {
            hide: editAvatarStarted
        });

        const bgUploadButton = classNames("btn btn-small btn-white", {
            hide: editBgStarted
        });

        // Added `invisible` bootstrap class to hide the delete buttons
        // This is so that the styles of the other components won't be broken
        // while the DELETE functionality is implemented
        const avatarDeleteButton = classNames("btn btn-small btn-white hidden", {
            hide: editAvatarStarted
        });

        const bgDeleteButton = classNames("btn btn-small btn-white hidden", {
            hide: editBgStarted
        });

        return ( <
            div id = "right-side-panel"
            className = "col-xs-12" >
            <
            h5 className = "container_head" > {
                trans("Customize")
            } < /h5> <
            div id = "avatar" > {
                trans("Profile Picture")
            } <
            img src = {
                avatar ? avatar : "/image/pixel.gif"
            }
            alt = {
                username
            }
            align = "bottom"
            className = "picframe"
            border = "0"
            width = "256"
            height = "256" /
            >
            <
            button id = "changeAvatar"
            className = {
                avatarUploadButton
            }
            onClick = {
                this.uploadAvatar
            } >
            {
                trans("Change")
            } <
            /button> <
            form className = {
                avatarUploadClasses
            }
            method = "post"
            encType = "multipart/form-data" >
            <
            input type = "file"
            name = "avatar"
            onChange = {
                this.updateAvatar
            }
            /> <
            small > {
                trans(
                    "Upload a jpg or gif, 512x512 recommended.Do not upload any restricted material, see terms of service"
                )
            } <
            /small> <
            /form> {
                avatar && ( <
                    button id = "deleteAvatar"
                    className = {
                        avatarDeleteButton
                    }
                    onClick = {
                        e => this.updateAvatar(e, true)
                    } >
                    {
                        trans("Remove")
                    } <
                    /button>
                )
            } <
            /div> <
            div id = "background" > {
                trans("Background")
            } <
            img src = {
                backgroundUrl ? backgroundUrl : "/image/pixel.gif"
            }
            alt = {
                username
            }
            align = "bottom"
            className = "picframe"
            border = "0"
            width = "256" /
            >
            <
            button id = "changeBackground"
            className = {
                bgUploadButton
            }
            onClick = {
                this.uploadBackground
            } >
            {
                trans("Change")
            } <
            /button> <
            form className = {
                bgUploadClasses
            }
            method = "post"
            encType = "multipart/form-data" >
            <
            input type = "file"
            name = "backgroundUrl"
            onChange = {
                this.updateBackground
            }
            /> <
            small > {
                trans(
                    "Upload a jpg or gif, up to 1MB. Do not upload any restricted material, see terms ofservice"
                )
            } <
            /small> <
            /form> {
                backgroundUrl && ( <
                    button id = "deleteBackground"
                    className = {
                        bgDeleteButton
                    }
                    onClick = {
                        e => this.updateBackground(e, true)
                    } >
                    {
                        trans("Remove")
                    } <
                    /button>
                )
            } <
            /div>

            <
            div className = "close-account" >
            <
            a className = "btn btn-md btn-orange on-navigate"
            href = "/user_close" > {
                trans("Close Account")
            } <
            /a> <
            /div> <
            /div>
        );
    }
}

RightSidePanel.propTypes = {
    trans: PropTypes.func.isRequired,
    avatar: PropTypes.string.isRequired,
    backgroundUrl: PropTypes.string.isRequired,
    username: PropTypes.string.isRequired,
    saveAvatarChanges: PropTypes.func,
    saveBackgroundChanges: PropTypes.func
};

if (isClient()) {
    _.extend(RightSidePanel.propTypes, {
        saveAvatarChanges: PropTypes.func.isRequired,
        saveBackgroundChanges: PropTypes.func.isRequired
    });
}

export default injectTrans(RightSidePanel);