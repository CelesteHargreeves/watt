import moment from "moment";
import PropTypes from "prop-types";
import React from "react";

import {
    Icon
} from "../../shared-components";
import {
    isClient,
    sanitizeHTML,
    injectTrans
} from "../../helpers";
import AccountSocialMedia from "./AccountSocialMedia";
import FormField from "./FormField";

const mapLanguagetoPremiumLinks = {
    1: "https://www.wattpad.com/premium", //English
    2: "https://www.wattpad.com/premium/fr/", //French
    5: "https://www.wattpad.com/premium/es/", //Spanish
    6: "https://www.wattpad.com/premium/pt/", //Portuguese
    20: "https://www.wattpad.com/premium/id/" //Indonesian
};

const mapLanguagetoBetaLinks = {
    1: "https://support.wattpad.com/hc/en-us/articles/201708720-Becoming-a-Beta-tester", //English
    2: "https://support.wattpad.com/hc/fr/articles/201708720-Devenir-un-b%C3%AAta-testeur", //French
    3: "https://support.wattpad.com/hc/it/articles/201708720-Come-diventare-un-Beta-tester-per-Wattpad", // Italian
    4: "https://support.wattpad.com/hc/de/articles/201708720-Ein-Beta-Tester-werden", //German
    5: "https://support.wattpad.com/hc/es/articles/201708720-Convi%C3%A9rtete-en-un-usuario-Beta", //Spanish
    6: "https://support.wattpad.com/hc/pt/articles/201708720-Como-se-tornar-um-testador-Beta", //Portuguese
    18: "https://support.wattpad.com/hc/fil/articles/201708720-Pagiging-Beta-tester", //Filipino
    20: "https://support.wattpad.com/hc/id/articles/201708720-Menjadi-Beta-tester", //Indonesian
    23: "https://support.wattpad.com/hc/tr/articles/201708720-Beta-Kullan%C4%B1c%C4%B1s%C4%B1-Olma" //Turkish
};

class AccountSettings extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            wordCount: this.props.description.length,
            showName: this.props.show_name === 1,
            appearOffline: this.props.appear_offline === 1,
            betaEnabled: this.props.beta_enabled,
            email: this.props.email
        };
    }

    onCheckboxChange = (input, value) => {
        let changes = {};
        changes[input] = value;
        this.setState(changes);
    };

    handleSubmit = event => {
        event.preventDefault();
        const {
            showName,
            appearOffline,
            betaEnabled
        } = this.state;
        const userData = [{
                name: "show_name",
                value: showName ? "1" : "0"
            },
            {
                name: "appear_offline",
                value: appearOffline ? "1" : "0"
            },
            {
                name: "beta_enabled",
                value: betaEnabled
            }
        ];
        this.props.onSubmit(event, userData);
    };

    updateWordCount = event => {
        this.setState({
            wordCount: event.target.value.length
        });
    };

    onUpdateEmail = newEmail => {
        this.setState({
            email: newEmail
        });
    };

    openSettingsModal = (event, type) => {
        event.preventDefault();
        if (type == "email") {
            this.props.openEditModal(type, this.onUpdateEmail, this.state.email);
        } else {
            this.props.openEditModal(type);
        }
    };

    getGenderDropdown() {
        const {
            gender,
            trans
        } = this.props;
        let defaultValue;

        switch (gender) {
            case "She":
                defaultValue = "F";
                break;
            case "He":
                defaultValue = "M";
                break;
            case "Zie":
                defaultValue = "O";
                break;
            case "Unknown":
                defaultValue = "";
                break;
            default:
                defaultValue = "";
        }

        return ( <
            select name = "gender"
            id = "gender"
            defaultValue = {
                defaultValue
            } >
            <
            option value = {
                "M"
            } > {
                trans("He/Him")
            } < /option> <
            option value = {
                "F"
            } > {
                trans("She/Her")
            } < /option> <
            option value = {
                "O"
            } > {
                trans("They/Them")
            } < /option> <
            option value = {
                ""
            }
            /> <
            /select>
        );
    }

    getLanguageDropdown() {
        const {
            language,
            app
        } = this.props;
        return ( <
            select name = "language"
            id = "language"
            size = "1"
            defaultValue = {
                language
            } > {
                app.languages.map(function(lang) {
                    return ( <
                        option key = {
                            lang.id
                        }
                        value = {
                            lang.id
                        } > {
                            lang.name ? lang.name : lang.get("name")
                        } <
                        /option>
                    );
                })
            } <
            /select>
        );
    }

    render() {
        const {
            trans,
            username,
            has_password,
            name,
            language,
            app,
            verified_email,
            location,
            bubok,
            smashwords,
            website,
            lulu,
            description,
            isPremium,
            facebook
        } = this.props;

        const {
            wordCount,
            showName,
            appearOffline,
            betaEnabled,
            email
        } = this.state;
        let {
            birthdate
        } = this.props;
        birthdate = moment(birthdate).format("YYYY-MM-DD");
        const premiumLink = mapLanguagetoPremiumLinks[app.language] ?
            mapLanguagetoPremiumLinks[app.language] :
            mapLanguagetoPremiumLinks[1];
        const betaLink = mapLanguagetoBetaLinks[app.language] ?
            mapLanguagetoBetaLinks[app.language] :
            mapLanguagetoBetaLinks[1];
        return ( <
            div id = "account" >
            <
            h2 className = "subheading" > {
                trans("Change your account information and privacy settings")
            } <
            /h2>

            <
            form id = "account_form"
            name = "account_form"
            onSubmit = {
                this.handleSubmit
            } >
            <
            div className = "row account-wrapper" >
            <
            FormField label = {
                trans("Username")
            } > {
                username
            } <
            button className = "info"
            id = "changeUsername"
            onClick = {
                event => this.openSettingsModal(event, "username")
            } >
            {
                trans("change")
            } <
            /button> <
            /FormField> <
            FormField label = {
                trans("Password")
            } > {
                has_password && ( <
                    span > {
                        sanitizeHTML("********")
                    } <
                    button className = "info"
                    id = "changePassword"
                    onClick = {
                        event => this.openSettingsModal(event, "password")
                    } >
                    {
                        trans("change")
                    } <
                    /button> <
                    /span>
                )
            } {
                !has_password && ( <
                    button className = "info"
                    id = "addPassword"
                    onClick = {
                        event =>
                        this.openSettingsModal(event, "addPassword")
                    } >
                    {
                        trans("create password")
                    } <
                    /button>
                )
            } <
            /FormField>

            <
            FormField label = {
                trans("Email")
            } > {
                email
            } <
            button className = "info"
            id = "changeEmail"
            onClick = {
                event => this.openSettingsModal(event, "email")
            } >
            {
                trans("change")
            } <
            /button> {
                !verified_email && ( <
                    div > {
                        trans("Not Verified")
                    } <
                    a className = "info"
                    href = {
                        `user_activation?action=send&username=${username}`
                    } >
                    {
                        trans("Send Activation Code")
                    } <
                    /a> <
                    /div>
                )
            } <
            /FormField> <
            FormField label = {
                trans("Name")
            }
            value = {
                name
            }
            name = {
                "name"
            }
            type = {
                "text"
            }
            /> <
            FormField label = {
                trans("Show name")
            }
            value = {
                showName
            }
            name = {
                "showName"
            }
            type = {
                "checkbox"
            }
            onCheckboxChange = {
                this.onCheckboxChange
            }
            /> <
            FormField label = {
                trans("Date of Birth")
            } >
            <
            div className = "birthdate-wrapper" >
            <
            input id = "birthdate"
            type = "date"
            name = "birthdate"
            max = {
                moment().format("YYYY-MM-DD")
            }
            defaultValue = {
                birthdate
            }
            /> <
            /div> <
            /FormField> <
            FormField label = {
                trans("Pronouns")
            } > {
                this.getGenderDropdown()
            } <
            /FormField> <
            FormField label = {
                trans("Location")
            }
            value = {
                location
            }
            name = {
                "location"
            }
            type = {
                "text"
            }
            /> <
            FormField label = {
                trans("Story Language")
            } > {
                this.getLanguageDropdown()
            } <
            /FormField> <
            FormField label = {
                trans("Appear Offline")
            }
            value = {
                appearOffline
            }
            name = {
                "appearOffline"
            }
            type = {
                "checkbox"
            }
            onCheckboxChange = {
                this.onCheckboxChange
            }
            /> <
            FormField label = {
                trans("Premium Subscription")
            } >
            <
            span className = "premium-status" > {
                isPremium ? trans("Active") : trans("Inactive")
            } <
            /span> <
            a className = "info"
            href = {
                premiumLink
            }
            target = "_blank"
            rel = "noopener noreferrer" >
            {
                trans("Learn more")
            } <
            /a> <
            /FormField> <
            FormField label = {
                trans("Join Beta Program")
            }
            name = {
                "betaEnabled"
            }
            value = {
                betaEnabled
            }
            type = {
                "checkbox"
            }
            onCheckboxChange = {
                this.onCheckboxChange
            } >
            <
            a className = "info"
            href = {
                betaLink
            }
            target = "_blank"
            rel = "noopener noreferrer" >
            {
                trans("Learn more")
            } <
            /a> <
            span id = "beta-tooltip"
            className = "help" >
            <
            Icon iconName = "fa-info"
            height = "16"
            color = "wp-neutral-2" / >
            <
            /span> <
            /FormField> <
            FormField label = {
                trans("Download your Personal Information")
            } > { /* eslint-disable-next-line wp-lint-rules/valid-href */ } <
            a href = "/settings/your-wattpad-data" > {
                trans("HTML")
            } < /a> { /* eslint-disable-next-line wp-lint-rules/valid-href */ } <
            a href = "/settings/your-wattpad-data?json=1"
            style = {
                {
                    paddingLeft: "5px"
                }
            } >
            {
                trans("JSON")
            } <
            /a> <
            span id = "info-tooltip"
            className = "help" >
            <
            Icon iconName = "fa-info"
            height = "16"
            color = "wp-neutral-2" / >
            <
            /span> <
            /FormField> <
            AccountSocialMedia facebook = {
                facebook
            }
            /> <
            FormField label = {
                "Lulu"
            }
            value = {
                lulu
            }
            type = {
                "text"
            }
            name = {
                "lulu"
            }
            icon = { <
                img
                className = "label-icon"
                src = "/image/icon22_lulu.png"
                alt = "icon22_lulu.png" /
                >
            }
            /> <
            FormField label = {
                "Smashwords"
            }
            value = {
                smashwords
            }
            type = {
                "text"
            }
            name = {
                "smashwords"
            }
            icon = { <
                img
                className = "label-icon"
                src = "/image/icon22_smashwords.png"
                alt = "icon22_smashwords.png" /
                >
            }
            /> {
                (language === 5 || language === 6) && ( <
                    FormField label = {
                        "Bubok"
                    }
                    name = {
                        "bubok"
                    }
                    value = {
                        bubok
                    }
                    type = {
                        "text"
                    }
                    icon = { <
                        img
                        className = "label-icon"
                        src = "/image/icon22_bubok.png"
                        alt = "icon22_bubok.png" /
                        >
                    }
                    />
                )
            } <
            FormField label = {
                trans("Website")
            }
            value = {
                website
            }
            name = {
                "website"
            }
            type = {
                "text"
            }
            icon = { <
                img
                className = "label-icon"
                src = "/image/icon22_web.png"
                alt = "icon22_web.png"
                border = "0"
                align = "absmiddle" /
                >
            }
            /> <
            /div>

            <
            div className = "row about-me" >
            <
            label htmlFor = "description"
            className = "about-title" > {
                trans("About")
            } <
            /label> <
            textarea className = "inputbox col-xs-12"
            name = "description"
            id = "description"
            cols = "30"
            rows = "10"
            defaultValue = {
                description
            }
            onKeyUp = {
                this.updateWordCount
            }
            /> <
            span className = "word-count" > {
                wordCount
            }
            / 2000</span >
            <
            /div>

            <
            div className = "row submit" >
            <
            input type = "submit"
            className = "btn btn-md btn-orange"
            defaultValue = {
                trans("Save")
            }
            /> <
            /div> <
            /form> <
            /div>
        );
    }
}

AccountSettings.propTypes = {
    trans: PropTypes.func.isRequired,
    username: PropTypes.string.isRequired,
    has_password: PropTypes.bool,
    name: PropTypes.string,
    email: PropTypes.string.isRequired,
    language: PropTypes.number.isRequired,
    gender: PropTypes.string,
    genderCode: PropTypes.string,
    verified_email: PropTypes.bool,
    birthdate: PropTypes.string,
    location: PropTypes.string,
    bubok: PropTypes.string,
    smashwords: PropTypes.string,
    website: PropTypes.string,
    lulu: PropTypes.string,
    description: PropTypes.string,
    isPremium: PropTypes.bool.isRequired,
    beta_enabled: PropTypes.bool.isRequired,
    appear_offline: PropTypes.any,
    show_name: PropTypes.any,
    facebook: PropTypes.string.isRequired,
    app: PropTypes.object.isRequired,
    openEditModal: PropTypes.func,
    onSubmit: PropTypes.func,
    onUpdateEmail: PropTypes.func
};

if (isClient()) {
    _.extend(AccountSettings.propTypes, {
        openEditModal: PropTypes.func.isRequired,
        onSubmit: PropTypes.func.isRequired
    });
}

export default injectTrans(AccountSettings);