import React, {
    useState,
    useRef,
    useEffect
} from "react";
import {
    useTrans
} from "../../hooks";
import PropTypes from "prop-types";
import PasswordFields from "../../shared-components/PasswordFields";
import {
    withValidation,
    FormField
} from "../../shared-components";
import {
    Button,
    ButtonVariant
} from "@wattpad/web-ui-library";

const ValidatedFormField = withValidation(FormField);

function RequestAccountDetails({
    errorMsg,
    model,
    preservedVal = {}
}) {
    const {
        trans
    } = useTrans();
    const {
        email,
        token,
        type,
        username
    } = preservedVal;

    const [isUsernameValid, setIsUsernameValid] = useState(false);
    const [isEmailValid, setIsEmailValid] = useState(false);
    const [isPasswordValid, setIsPasswordValid] = useState(false);

    const [usernameValue, setUsernameValue] = useState();
    const usernameRef = useRef();
    const emailRef = useRef();

    const policy_agreement = trans('By clicking below, you agree to Wattpad\'s <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>.'); // prettier-ignore

    const isValidated = isEmailValid && isUsernameValid && isPasswordValid;

    const validateSignupForm = (isValid, key) => {
        if (key.toLowerCase().includes("username")) {
            setIsUsernameValid(isValid);
        } else if (key.toLowerCase().includes("email")) {
            setIsEmailValid(isValid);
        }
    };

    useEffect(
        () => {
            if (username) {
                usernameRef.current.value = username;
                usernameRef.current.focus();
                usernameRef.current.blur();
            }
            if (email) {
                emailRef.current.value = email;
                emailRef.current.focus();
                emailRef.current.blur();
            }
        }, [username, email]
    );

    return ( <
        div className = "container" >
        <
        div className = "onboardingModal request-account-details modal fade in"
        data - backdrop = "static"
        data - keyboard = "false"
        style = {
            {
                display: "block"
            }
        } >
        <
        div className = "v-align-wrap" >
        <
        div className = "modal-dialog v-align" >
        <
        div className = "modal-content" >
        <
        div className = "modal-header" >
        <
        h1 className = "modal-title text-center" > {
            trans("You're almost there.")
        } <
        /h1> <
        /div> <
        div className = "modal-body" >
        <
        h2 className = "text-center" > {
            trans("We need some details to keep in contact with you.")
        } <
        /h2> <
        form id = "signupForm"
        action = ""
        method = "POST"
        onSubmit = {
            e => {
                if (!isEmailValid) {
                    e.preventDefault();
                    emailRef.current.focus();
                }
                if (!isUsernameValid) {
                    e.preventDefault();
                    usernameRef.current.focus();
                }
            }
        } >
        <
        ValidatedFormField name = "username"
        label = {
            trans("Username")
        }
        form = "signup"
        inputType = "text"
        title = {
            trans("Enter username")
        }
        inputRef = {
            usernameRef
        }
        validationModel = {
            model
        }
        showLabel = {
            true
        }
        onValid = {
            key => validateSignupForm(true, key)
        }
        onInvalid = {
            key => validateSignupForm(false, key)
        }
        onBlur = {
            () => setUsernameValue(usernameRef.current ? .value)
        }
        /> <
        ValidatedFormField name = "email"
        label = {
            trans("Email")
        }
        form = "signup"
        inputType = "text"
        title = {
            trans("Enter email")
        }
        inputRef = {
            emailRef
        }
        validationModel = {
            model
        }
        showLabel = {
            true
        }
        onValid = {
            key => validateSignupForm(true, key)
        }
        onInvalid = {
            key => validateSignupForm(false, key)
        }
        /> <
        PasswordFields username = {
            usernameValue
        }
        validatePassword = {
            setIsPasswordValid
        }
        /> {
            errorMsg && ( <
                div className = "alert alert-danger"
                role = "alert" > {
                    errorMsg
                } <
                /div>
            )
        } <
        span className = "terms-of-service"
        dangerouslySetInnerHTML = {
            {
                __html: policy_agreement
            }
        }
        /> {
            token && ( <
                input className = "token hidden"
                readOnly value = {
                    token
                }
                name = "token" /
                >
            )
        } {
            type && ( <
                input className = "account-type hidden"
                readOnly value = {
                    type
                }
                name = "type" /
                >
            )
        } <
        Button fullWidth disabled = {!isValidated
        }
        variant = {
            ButtonVariant.PRIMARY
        }
        aria - label = "Continue" >
        {
            trans("Continue")
        } <
        /Button> <
        /form> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div>
    );
}

RequestAccountDetails.propTypes = {
    errorMsg: PropTypes.string,
    model: PropTypes.object,
    preservedVal: PropTypes.shape({
        email: PropTypes.string,
        token: PropTypes.string,
        type: PropTypes.string,
        username: PropTypes.string
    })
};

export default RequestAccountDetails;