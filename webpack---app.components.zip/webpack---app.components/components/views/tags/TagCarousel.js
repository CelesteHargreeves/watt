import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
    TAG_NUM_COLOURS,
    TAG_BG_COLOURS,
    TAG_TEXT_COLOURS
} from "../../constants";
import TagItem from "./TagItem";
import TagItemWithIcon from "./TagItemWithIcon";

// Component expects relatedTags={ tags: [ 'array', 'of', 'tags' ], withIcon: (default false) }
export default class TagCarousel extends React.Component {
    tagClickHandler = (evt, tag) => {
        window.wattpad.utils.stopEvent(evt);
        window.app.trigger(
            "app:component:TagCarouselItem:click",
            evt.currentTarget.textContent,
            evt
        );
        this.props.onTagClicked && this.props.onTagClicked(tag);
    };

    render() {
        const tags = this.props.relatedTags.tags,
            withIcon = this.props.relatedTags.withIcon || false;

        return ( <
            div className = {
                classNames("tag-carousel", this.props.className, {
                    hidden: !(tags ? .length > 0)
                })
            } >
            <
            div className = "tag-items" > {
                tags ? .map((tag, i) => {
                    if (withIcon) {
                        return ( <
                            TagItemWithIcon key = {
                                tag.id
                            } { ...tag
                            }
                            clickHandler = {
                                this.tagClickHandler
                            }
                            />
                        );
                    } else {
                        return ( <
                            TagItem key = {
                                tag.id
                            }
                            bgColor = {
                                this.getNextTagColor(i, "bg")
                            }
                            color = {
                                this.getNextTagColor(i)
                            } { ...tag
                            }
                            clickHandler = {
                                this.tagClickHandler
                            }
                            />
                        );
                    }
                })
            } <
            /div> <
            /div>
        );
    }

    getNextTagColor(index, type) {
        var i = index % TAG_NUM_COLOURS;
        return type === "bg" ? TAG_BG_COLOURS[i] : TAG_TEXT_COLOURS[i];
    }
}

TagCarousel.propTypes = {
    relatedTags: PropTypes.object.isRequired,
    className: PropTypes.string,
    onTagClicked: PropTypes.func
};