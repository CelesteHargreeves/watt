import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
    TAG_NUM_COLOURS,
    TAG_BG_COLOURS,
    TAG_TEXT_COLOURS
} from "../../constants";
import {
    TagPill as TagItem
} from "@wattpad/web-ui-library";
import TagItemWithIcon from "./TagItemWithIcon";

// Component expects relatedTags={ tags: [ 'array', 'of', 'tags' ], withIcon: (default false) }
export default class TagGrid extends React.Component {
    tagClickHandler = (evt, tag) => {
        this.props.onTagClicked && this.props.onTagClicked(tag, evt);
        window.wattpad.utils.stopEvent(evt);
        window.app.trigger("app:component:TagGridItem:click", evt);
    };

    tagKeyDownHandler = (evt, tag) => {
        if (evt.key === " " || evt.key === "Spacebar") {
            this.props.onTagClicked && this.props.onTagClicked(tag, evt);
            window.wattpad.utils.stopEvent(evt);
        }
    };

    render() {
        const tags = this.props.tagGridTags.tags,
            withIcon = this.props.tagGridTags.withIcon || false;

        if (tags && tags.length > 0) {
            return ( <
                div className = {
                    classNames("tag-grid clearfix", this.props.className)
                } >
                <
                ul className = "tag-items" > {
                    tags.map((tag, i) => {
                        if (withIcon) {
                            return ( <
                                li key = {
                                    tag.id
                                } >
                                <
                                TagItemWithIcon { ...tag
                                }
                                clickHandler = {
                                    this.tagClickHandler
                                }
                                /> <
                                /li>
                            );
                        } else {
                            return ( <
                                li key = {
                                    tag.id
                                } >
                                <
                                TagItem bgColor = {
                                    this.getNextTagColor(i, "bg")
                                }
                                color = {
                                    this.getNextTagColor(i)
                                } { ...tag
                                }
                                clickHandler = {
                                    this.tagClickHandler
                                }
                                keyDownHandler = {
                                    this.tagKeyDownHandler
                                }
                                /> <
                                /li>
                            );
                        }
                    })
                } <
                /ul> <
                /div>
            );
        }
        return null;
    }

    getNextTagColor(index, type) {
        var i = index % TAG_NUM_COLOURS;
        return type === "bg" ? TAG_BG_COLOURS[i] : TAG_TEXT_COLOURS[i];
    }
}

TagGrid.propTypes = {
    tagGridTags: PropTypes.object.isRequired,
    onTagClicked: PropTypes.func,
    className: PropTypes.string
};