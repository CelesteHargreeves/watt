import PropTypes from "prop-types";
import React from "react";

import {
    ContestFormHeader
} from "./ContestFormHeader";
import {
    useTrans
} from "../../../hooks";
import {
    Loader
} from "../../../shared-components";
import {
    MAP_WATTYS_MILESTONES_TO_LINKS
} from "./constants";
import {
    getCategoryTranslation
} from "./helpers";

const SubmissionSuccess = ({
    isStandalonePage = false,
    closeModal,
    formState
}) => {
    const {
        trans
    } = useTrans();

    const headerTitle = trans(
        "Congratulations! You have been entered\ninto the 2022 Watty Awards."
    );

    const awardCategory = getCategoryTranslation(
        trans,
        formState.data.contest_submission.award_category
    );

    if (formState.isLoading) {
        return ( <
            div className = "loading-spinner" >
            <
            Loader / >
            <
            /div>
        );
    }

    const trackBannerOnClosePopup = () => {
        window.te.push("event", "wattys", "banner", null, "view", {
            storyid: parseInt(formState.data.story_id),
            type: "confirmed_submission",
            page: "story_details"
        });
        closeModal();
    };

    return ( <
        div id = "submission-success" >
        <
        ContestFormHeader subtitle = {
            headerTitle
        }
        closeModal = {
            trackBannerOnClosePopup
        }
        isStandalonePage = {
            isStandalonePage
        }
        /> <
        div className = "form-deadline" >
        <
        div className = "deadline-text"
        dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans('<a target="_blank" href="%s">When will winners be announced?</a>', MAP_WATTYS_MILESTONES_TO_LINKS[parseInt(app.get("language"), 10)])
            }
        }
        /> <
        /div> <
        div className = "main-container" >
        <
        div className = "content" >
        <
        h3 className = "black bold" > {
            trans("Share the exciting news with your readers!")
        } <
        /h3> <
        /div> <
        /div> <
        div className = "main-container-cover" >
        <
        div className = "content" >
        <
        h5 className = "bold" > {
            trans("I entered my story in the 2022 Wattys!")
        } <
        /h5> <
        div className = "image-container" >
        <
        img src = {
            formState.cover
        }
        alt = "story cover" / >
        <
        /div> <
        h6 dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("<span class='bold'>%s</span><br>by @%s", formState.title, formState.user)
            }
        }
        /> <
        /div> <
        /div> <
        div className = "main-container" >
        <
        div className = "content" >
        <
        div className = "submission-info-text"
        dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("Your story has been submitted in the ‘<strong>%s</strong>’ category for the 2022 Watty Awards", awardCategory)
            }
        }
        /> <
        div className = "submission-info-text"
        dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("<span class='bold'>Good luck and happy writing!</span>")
            }
        }
        /> <
        /div> {
            !isStandalonePage && ( <
                React.Fragment >
                <
                div className = "btn-container" >
                <
                button onClick = {
                    trackBannerOnClosePopup
                }
                className = "btn btn-primary" >
                {
                    trans("Done")
                } <
                /button> <
                /div> <
                /React.Fragment>
            )
        } <
        /div> <
        /div>
    );
};

SubmissionSuccess.propTypes = {
    isStandalonePage: PropTypes.bool,
    closeModal: PropTypes.func,
    formState: PropTypes.object
};

export {
    SubmissionSuccess
};