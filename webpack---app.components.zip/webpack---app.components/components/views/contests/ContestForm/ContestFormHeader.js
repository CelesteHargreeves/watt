import PropTypes from "prop-types";
import React from "react";
import Icon from "../../../shared-components/Icon";

import {
    useTrans
} from "../../../hooks";

function ContestFormHeader({
    subtitle,
    closeModal,
    isStandalonePage
}) {
    const {
        trans
    } = useTrans();
    return ( <
        div className = "form-header" > {!isStandalonePage && ( <
                button className = "close-btn"
                onClick = {
                    closeModal
                }
                aria - label = "Close modal" // TODO add translation to aria-label when copy is approved
                >
                <
                Icon name = "close"
                size = "24"
                color = "wp-neutral-5" / >
                <
                /button>
            )
        } <
        div className = "centered-text" >
        <
        h2 dangerouslySetInnerHTML = {
            {
                __html: trans("the<span class='mediumbold'>wattys</span>2022")
            }
        }
        /> <
        div className = "subtitle bold" > {
            subtitle
        } < /div> <
        /div> <
        /div>
    );
}

ContestFormHeader.propTypes = {
    subtitle: PropTypes.string.isRequired,
    closeModal: PropTypes.func,
    isStandalonePage: PropTypes.bool.isRequired
};

export {
    ContestFormHeader
};