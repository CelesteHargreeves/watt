import React from "react";

import {
    addStoryTag
} from "../../story-details/StoryTags/reducers";
import {
    ContestForm
} from "./ContestForm";
import {
    toggleModal
} from "../../../shared-components/modals/actions";

const namespace = "CONTEST_FORM";

const FORM_REQUEST = `${namespace}/REQUEST`;
const FORM_FETCH = `${namespace}/FETCH`;
const FORM_SET = `${namespace}/SET`;
const FORM_ERROR = `${namespace}/ERROR`;
const FORM_SUBMITTED_SET = `${namespace}/SUBMITTED_SET`;
const FORM_NEAR_ELIGIBLE_SET = `${namespace}/NEAR_ELIGIBLE_SET`;

const ADDED_WATTYS_TAG = `${namespace}/ADDED_WATTYS_TAG`;

const initialState = {
    isLoading: true,
    hasCheckedSubmission: false,
    hasSubmitted: false,
    isNearEligible: false,
    hasAddedWattysTag: false,
    user: "",
    cover: "",
    title: "",

    data: {
        story_id: null,
        contest_submission: {
            contest: "",
            wattys_submitted_time: 0,
            language: "",
            award_category: "",
            subgenre: "",
            sexual_content: "",
            is_exclusive: false,
            is_final_consent: false,
            preferred_email: "",
            target_audience: "",
            mature_themes: [],
            others: {
                mature_themes: ""
            },
            plot_details: {
                summary: "",
                logline: ""
            }
        }
    }
};
export default function reducer(state = initialState, action = {}) {
    switch (action.type) {
        case FORM_REQUEST:
            {
                return {
                    ...state,
                    isLoading: true
                };
            }
        case FORM_FETCH:
            {
                //Parse contest from server json to match our reducer data structure

                let hasSubmitted = initialState.hasSubmitted;

                let wattysContest;

                if (action.data.contest) {
                    if (action.data.contest === window.wattpad.wattysActiveKey) {
                        wattysContest = action.data;
                    }

                    if (wattysContest) {
                        hasSubmitted = true;
                    }
                }
                return {
                    ...initialState,
                    isLoading: false,
                    hasCheckedSubmission: true,
                    hasSubmitted,
                    // Merge the new form data into the default ones
                    data: {
                        story_id: action.story_id || initialState.data.story_id,
                        contest_submission: {
                            award_category: action.data.award_category ||
                                initialState.data.contest_submission.award_category,
                            subgenre: action.data.subgenre ||
                                initialState.data.contest_submission.subgenre,
                            target_audience: action.data.target_audience ||
                                initialState.data.contest_submission.target_audience,
                            mature_themes: action.data.mature_themes ||
                                initialState.data.contest_submission.mature_themes,
                            plot_details: action.data.plot_details ||
                                initialState.data.contest_submission.plot_details,
                            others: action.data.others || initialState.data.contest_submission.others,
                            preferred_email: action.data.preferred_email ||
                                initialState.data.contest_submission.preferred_email,
                            is_exclusive: action.data.is_exclusive ||
                                initialState.data.contest_submission.is_exclusive,
                            is_final_consent: action.data.is_final_consent ||
                                initialState.data.contest_submission.is_final_consent,
                            sexual_content: action.data.sexual_content ||
                                initialState.data.contest_submission.sexual_content,
                            language: action.data.language ||
                                initialState.data.contest_submission.language
                        }
                    },
                    language: action.storyData.language && action.storyData.language.id,
                    cover: action.storyData.cover,
                    title: action.storyData.title,
                    user: action.storyData.user.name
                };
            }
        case FORM_SET:
            {
                return {
                    ...state,
                    data: {
                        ...state.data,
                        story_id: action.story_id,
                        contest_submission: {
                            ...state.data.contest_submission,
                            ...action.data
                        }
                    },
                    isLoading: false,
                    hasCheckedSubmission: true
                };
            }
        case FORM_SUBMITTED_SET:
            {
                return {
                    ...state,
                    isLoading: false,
                    hasCheckedSubmission: true,
                    hasSubmitted: action.status
                };
            }
        case FORM_NEAR_ELIGIBLE_SET:
            {
                return {
                    ...state,
                    isLoading: false,
                    isNearEligible: action.isNearEligible
                };
            }
        case FORM_ERROR:
            {
                return {
                    ...state,
                    isLoading: false
                };
            }
        case ADDED_WATTYS_TAG:
            {
                return {
                    ...state,
                    hasAddedWattysTag: true
                };
            }
        default:
            return state;
    }
}

export function fetchContestForm(storyId) {
    return async function(dispatch, getState) {
        const storyUrl = `/api/v3/stories/${storyId}?fields=cover,title,language,user`;

        const hasSubmitted = getState().contestForm.hasSubmitted;

        if (hasSubmitted) {
            const storyDetailsUrl = `/v5/contests/${
        window.wattpad.wattysActiveKey
      }/story/${storyId}/`;
            if (!getState().contestForm.isLoading) {
                dispatch({
                    type: FORM_REQUEST
                });
            }
            return Promise.all([
                Promise.resolve($.get(storyDetailsUrl)),
                Promise.resolve($.get(storyUrl))
            ]).then(([storyDetailsData, storyData]) => {
                dispatch({
                    type: FORM_FETCH,
                    data: storyDetailsData.contest_submission,
                    story_id: storyDetailsData.story_id,
                    storyData
                });
            });
        } else {
            window.te.push("event", "wattys", "submission_form", null, "view", {
                storyid: parseInt(storyId)
            });
            return Promise.resolve($.get(storyUrl)).then(storyData => {
                dispatch({
                    type: FORM_FETCH,
                    data: initialState.data.contest_submission,
                    story_id: storyData.story_id,
                    storyData
                });
            });
        }
    };
}

export function fetchSubmittedFormBannerInfo(storyId) {
    return async function(dispatch, getState) {
        const storyUrl = `/api/v3/stories/${storyId}?fields=cover,title,language,user`;
        const storyDetailsUrl = `/v5/contests/${
      window.wattpad.wattysActiveKey
    }/story/${storyId}/`;
        if (!getState().contestForm.isLoading) {
            dispatch({
                type: FORM_REQUEST
            });
        }
        return Promise.all([
            Promise.resolve($.get(storyDetailsUrl)),
            Promise.resolve($.get(storyUrl))
        ]).then(([storyDetailsData, storyData]) => {
            dispatch({
                type: FORM_FETCH,
                data: storyDetailsData.contest_submission,
                story_id: storyDetailsData.story_id,
                storyData
            });
        });
    };
}

export function setContestForm(storyId, body) {
    return async function(dispatch) {
        const storyDetailsUrl = `/v5/contests/${
      window.wattpad.wattysActiveKey
    }/submit`;
        const storyTagsUrl = "/apiv2/editstorytags";
        const storyLandingUrl = `/api/v3/stories/${storyId}?fields=tags,parts`;
        dispatch({
            type: FORM_REQUEST
        });
        //Submit wattys contest form
        try {
            await Promise.resolve(
                $.ajax({
                    url: storyDetailsUrl,
                    type: "POST",
                    data: JSON.stringify(body),
                    dataType: "json",
                    headers: {
                        "Content-Type": "application/json"
                    }
                })
            );
            window.te.push("event", "wattys", "submission_form", null, "submit", {
                storyid: parseInt(storyId)
            });
        } catch (err) {
            let message = wattpad.utils.trans(
                "Sorry, something went wrong. Please try again."
            );
            try {
                if (
                    err.status === 400 &&
                    (err.responseJSON.error.error_type === "InvalidParam" ||
                        err.responseJSON.error.error_type === "RequiredParamMissing") &&
                    err.responseJSON.error.fields.length > 0
                ) {
                    message += " [fields = ";
                    err.responseJSON.error.fields.forEach((field, i) => {
                        message +=
                            field +
                            (i !== err.responseJSON.error.fields.length - 1 ? ", " : "");
                    });
                    message += "]";
                } else if (
                    err.status === 401 &&
                    err.responseJSON.error.error_type === "PermissionDenied"
                ) {
                    message += wattpad.utils.trans(
                        "You do not have permission to modify this story"
                    );
                }
            } catch (err) {
                // Do nothing if fails.
            }
            const toast = new window.app.views.ErrorToast({
                message
            }, {
                type: "dismissable"
            });
            toast.render();
            dispatch({
                type: FORM_ERROR
            });
            throw err;
        }
        // Feed only the award category since the submission success requires it

        dispatch({
            type: FORM_SET,
            story_id: body.story_id,
            data: {
                award_category: body.contest_submission.award_category,
                preferred_email: body.contest_submission.preferred_email,
                is_final_consent: body.contest_submission.is_final_consent
            }
        });
        // Fetch tags to see if wattys exist & create wattys tag
        const {
            tags,
            parts
        } = await Promise.resolve($.get(storyLandingUrl));
        const wattysTag = window.wattpad.wattysActiveKey;
        let hasAddedWattysTag = false;
        if (tags.indexOf(wattysTag) === -1 && parts && parts.length > 0) {
            // Wattys tag doesn't exist. We create it here.
            try {
                await Promise.resolve(
                    $.post(storyTagsUrl, {
                        request_type: "add",
                        tag_value: wattysTag,
                        story_id: parts[0].id
                    })
                );
                dispatch(
                    addStoryTag({
                        id: wattysTag,
                        name: wattysTag,
                        active: true,
                        className: "wattys-tag"
                    })
                );
                dispatch({
                    type: ADDED_WATTYS_TAG
                });
                hasAddedWattysTag = true;
            } catch (err) {
                // Allow continuation if adding tag fails since it's only cosmetic
            }
        }
        dispatch(setContestFormSubmissionStatus(true));
        return hasAddedWattysTag;
    };
}

export function openContestForm(storyId) {
    return function(dispatch) {
        const ContestFormOpener = () => ( <
            ContestForm closeModal = {
                () => dispatch(toggleModal())
            }
            storyId = {
                storyId
            }
            />
        );
        dispatch(
            toggleModal({
                component: ContestFormOpener,
                disableClose: true,
                animate: false,
                className: "modal-contest",
                disableScroll: true
            })
        );
    };
}

export function setContestFormSubmissionStatus(status) {
    // Set whether the contest has been submitted or not
    return function(dispatch) {
        dispatch({
            type: FORM_SUBMITTED_SET,
            status
        });
    };
}

export function setContestFormNearEligibleStatus(isNearEligible) {
    // Set whether the contest form is near eligible
    return function(dispatch) {
        dispatch({
            type: FORM_NEAR_ELIGIBLE_SET,
            isNearEligible
        });
    };
}