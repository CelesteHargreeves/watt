export const MAP_WATTYS_MILESTONES_TO_LINKS = {
    1: "https://www.wattpad.com/1229519119-the-2022-watty-awards-important-milestones", //English
    2: "https://www.wattpad.com/1231193319-les-wattys-2022-rep%C3%A8res-importants", //French
    3: "https://www.wattpad.com/1231200684-wattys-2022-date-importanti", // Italian
    4: "https://www.wattpad.com/1231213225-die-watty-awards-2022-wichtige-meilensteine", //German
    5: "https://www.wattpad.com/1231224345-los-premios-watty-2022-fechas-importantes", //Spanish
    6: "https://www.wattpad.com/1231203611-pr%C3%AAmio-wattys-2022-datas-importantes", //Portuguese
    18: "https://www.wattpad.com/1230991990-ang-2022-watty-awards-mga-importanteng-milestone", //Filipino
    20: "https://www.wattpad.com/1231220047-penghargaan-wattys-2022-tahapan-penting", //Indonesian
    23: "https://www.wattpad.com/1231197934-2022-watty-%C3%B6d%C3%BClleri-%C3%B6nemli-tarihler" //Turkish
};

export const MAP_WATTYS_ELIGIBILITY_TO_LINKS = {
    1: "https://www.wattpad.com/1229514157-the-2022-watty-awards-eligibility", //English
    2: "https://www.wattpad.com/1231191747-les-wattys-2022-admissibilit%C3%A9", //French
    3: "https://www.wattpad.com/1231196027-wattys-2022-criteri-di-idoneit%C3%A0", // Italian
    4: "https://www.wattpad.com/1231211090-die-watty-awards-2022-teilnahmebedingungen", //German
    5: "https://www.wattpad.com/1231223859-los-premios-watty-2022-elegibilidad", //Spanish
    6: "https://www.wattpad.com/1231202510-pr%C3%AAmio-wattys-2022-elegibilidade", //Portuguese
    18: "https://www.wattpad.com/1230988479-ang-2022-watty-awards-eligibility", //Filipino
    20: "https://www.wattpad.com/1231219135-penghargaan-wattys-2022-kelayakan", //Indonesian
    23: "https://www.wattpad.com/1231196861-2022-watty-%C3%B6d%C3%BClleri-ba%C5%9Fvuru-%C5%9Fartlar%C4%B1" //Turkish
};

export const MAP_RULES_LANGUAGE_TO_LINKS = {
    1: "https://drive.google.com/file/d/1xzmsUjk1DrLsmsTBJ5mh4vp3oBKk5xkZ/view?usp=sharing", //English
    2: "https://www.wattpad.com/1231194648-les-wattys-2022-questions-juridiques", //French
    3: "https://www.wattpad.com/1231203286-wattys-2022-aspetti-legali", // Italian
    4: "https://www.wattpad.com/1231213855-die-watty-awards-2022-rechtliche-dinge", //German
    5: "https://www.wattpad.com/1231224960-los-premios-watty-2022-asuntos-legales", //Spanish
    6: "https://www.wattpad.com/1231204225-pr%C3%AAmio-wattys-2022-informa%C3%A7%C3%B5es-legais", //Portuguese
    18: "https://www.wattpad.com/1230995005-ang-2022-watty-awards-mga-legal-na-usapin", //Filipino
    20: "https://www.wattpad.com/1231221492-penghargaan-wattys-2022-hal-hal-hukum", //Indonesian
    23: "https://www.wattpad.com/1231198642-2022-watty-%C3%B6d%C3%BClleri-yasal-esaslar" //Turkish
};

export const WATTYS_CLOSING_DATETIME = new Date(
    "19 Aug 2022 23:59:59 GMT-0400"
).getTime();

export const PLOT_SUMMARY_CHARACTER_MIN = 100;
export const PLOT_SUMMARY_CHARACTER_MAX = 15000;
export const LOGLINE_CHARACTER_MAX = 500;
export const LOGLINE_CHARACTER_MIN = 20;
export const EMAIL_CHARACTER_MAX = 128;
export const OTHER_MATURE_THEMES_CHARACTER_MAX = 100;

export const MAP_AWARD_CATEGORY = trans => [{
        key: "fanfiction",
        value: trans("Fanfiction"),
        subgenres: [{
                key: "alternate_universe",
                value: trans("Alternate Universe")
            },
            {
                key: "crossover",
                value: trans("Crossover")
            },
            {
                key: "fix_fic",
                value: trans("Fix Fic")
            },
            {
                key: "one_shots",
                value: trans("One Shots")
            },
            {
                key: "real_person",
                value: trans("Real Person")
            },
            {
                key: "self_insert",
                value: trans("Self Insert")
            },
            {
                key: "shipping",
                value: trans("Shipping")
            },
            {
                key: "slash_fic",
                value: trans("Slash Fic")
            }
        ]
    },
    {
        key: "fantasy",
        value: trans("Fantasy"),
        subgenres: [{
                key: "fantasy_ancient_world",
                value: trans("Ancient World")
            },
            {
                key: "epic",
                value: trans("Epic")
            },
            {
                key: "fairy_tales_legends",
                value: trans("Fairy Tales/Folk Tales/Legends & Mythology")
            },
            {
                key: "fantasy_creatures",
                value: trans("Fantasy Creatures")
            },
            {
                key: "fantasy_litrpg",
                value: trans("LitRPG")
            },
            {
                key: "magical_realism",
                value: trans("Magical Realism")
            },
            {
                key: "fantasy_royalty",
                value: trans("Royalty")
            },
            {
                key: "fantasy_slice_of_life",
                value: trans("Slice of Life")
            },
            {
                key: "transmigration",
                value: trans("Transmigration")
            },
            {
                key: "urban_fantasy",
                value: trans("Urban Fantasy")
            },
            {
                key: "fantasy_war_military",
                value: trans("War & Military")
            },
            {
                key: "witches_wizards",
                value: trans("Witches & Wizards")
            },
            {
                key: "wuxia",
                value: trans("Wuxia")
            }
        ]
    },
    {
        key: "historical_fiction",
        value: trans("Historical Fiction"),
        subgenres: [{
                key: "17th_century",
                value: trans("17th Century")
            },
            {
                key: "18th_century",
                value: trans("18th Century")
            },
            {
                key: "19th_century",
                value: trans("19th Century")
            },
            {
                key: "20th_century",
                value: trans("20th Century")
            },
            {
                key: "alternate_history",
                value: trans("Alternate History")
            },
            {
                key: "historical_ancient_world",
                value: trans("Ancient World")
            },
            {
                key: "dark_academia",
                value: trans("Dark Academia")
            },
            {
                key: "medieval",
                value: trans("Medieval")
            },
            {
                key: "regency",
                value: trans("Regency")
            },
            {
                key: "time_slip",
                value: trans("Time Slip")
            },
            {
                key: "victorian",
                value: trans("Victorian")
            },
            {
                key: "historical_war_military",
                value: trans("War & Military")
            }
        ]
    },
    {
        key: "horror",
        value: trans("Horror"),
        subgenres: [{
                key: "horror_apocalyptic_dystopian",
                value: trans("Apocalyptic/Dystopian")
            },
            {
                key: "horror_fantasy_creatures",
                value: trans("Fantasy Creatures")
            },
            {
                key: "gore_disturbing",
                value: trans("Gore & Disturbing")
            },
            {
                key: "gothic",
                value: trans("Gothic")
            },
            {
                key: "horror_murder",
                value: trans("Murder")
            },
            {
                key: "horror_psychological",
                value: trans("Psychological")
            },
            {
                key: "serial_killer",
                value: trans("Serial Killer")
            },
            {
                key: "horror_zombies",
                value: trans("Zombies")
            }
        ]
    },
    {
        key: "mystery_thriller",
        value: trans("Mystery / Thriller"),
        subgenres: [{
                key: "abuse_trauma",
                value: trans("Abuse & Trauma")
            },
            {
                key: "adventure",
                value: trans("Adventure")
            },
            {
                key: "amateur_sleuth",
                value: trans("Amateur Sleuth")
            },
            {
                key: "assassin_espionage",
                value: trans("Assassin & Espionage")
            },
            {
                key: "cozy",
                value: trans("Cozy")
            },
            {
                key: "kidnapping",
                value: trans("Kidnapping")
            },
            {
                key: "mystery_mafia",
                value: trans("Mafia")
            },
            {
                key: "mystery_murder",
                value: trans("Murder")
            },
            {
                key: "police_legal_procedural",
                value: trans("Police & Legal Procedural")
            },
            {
                key: "mystery_psychological",
                value: trans("Psychological")
            },
            {
                key: "mystery_war_military",
                value: trans("War & Military")
            }
        ]
    },
    {
        key: "new_adult",
        value: trans("New Adult"),
        subgenres: [{
                key: "new_adult_billionaires_ceos",
                value: trans("Billionaires and CEOs")
            },
            {
                key: "new_adult_body_positivity",
                value: trans("Body Positivity")
            },
            {
                key: "new_adult_college_university",
                value: trans("College/University")
            },
            {
                key: "new_adult_coming_of_age",
                value: trans("Coming of Age")
            },
            {
                key: "new_adult_contract_relationship",
                value: trans("Contract Relationship")
            },
            {
                key: "new_adult_disability_illness",
                value: trans("Disability and Illness")
            },
            {
                key: "new_adult_family_life",
                value: trans("Family Life")
            },
            {
                key: "new_adult_friendship",
                value: trans("Friendship")
            },
            {
                key: "new_adult_marriage_divorce",
                value: trans("Marriage & Divorce")
            },
            {
                key: "new_adult_mental_health",
                value: trans("Mental Health")
            },
            {
                key: "personal_journey",
                value: trans("Personal Journey")
            },
            {
                key: "new_adult_slice_of_life",
                value: trans("Slice of Life")
            },
            {
                key: "new_adult_slow_burn",
                value: trans("Slow Burn")
            },
            {
                key: "new_adult_social_issues",
                value: trans("Social Issues")
            },
            {
                key: "new_adult_sports",
                value: trans("Sports")
            },
            {
                key: "new_adult_tragedy",
                value: trans("Tragedy")
            },
            {
                key: "new_adult_workplace",
                value: trans("Workplace")
            }
        ]
    },
    {
        key: "paranormal",
        value: trans("Paranormal"),
        subgenres: [{
                key: "angels_demons",
                value: trans("Angels and Demons")
            },
            {
                key: "paranormal_fantasy_creatures",
                value: trans("Fantasy Creatures")
            },
            {
                key: "fated_mates",
                value: trans("Fated Mates")
            },
            {
                key: "occult_supernatural",
                value: trans("Occult & Supernatural")
            },
            {
                key: "shifters",
                value: trans("Shifters")
            },
            {
                key: "paranormal_vampires",
                value: trans("Vampires")
            },
            {
                key: "werewolves",
                value: trans("Werewolves")
            }
        ]
    },
    {
        key: "romance",
        value: trans("Romance"),
        subgenres: [{
                key: "romance_billionaires_ceos",
                value: trans("Billionaires and CEOs")
            },
            {
                key: "romance_college_university",
                value: trans("College/University")
            },
            {
                key: "contemporary",
                value: trans("Contemporary")
            },
            {
                key: "romance_contract_relationship",
                value: trans("Contract Relationship")
            },
            {
                key: "dark_romance",
                value: trans("Dark Romance")
            },
            {
                key: "enemies_to_lovers",
                value: trans("Enemies to Lovers")
            },
            {
                key: "friends_to_lovers",
                value: trans("Friends to Lovers")
            },
            {
                key: "happy_ending",
                value: trans("Happy Ending")
            },
            {
                key: "romance_mafia",
                value: trans("Mafia")
            },
            {
                key: "romance_marriage_divorce",
                value: trans("Marriage & Divorce")
            },
            {
                key: "romantic_comedy",
                value: trans("Romantic Comedy")
            },
            {
                key: "romance_royalty",
                value: trans("Royalty")
            },
            {
                key: "romance_slice_of_life",
                value: trans("Slice of Life")
            },
            {
                key: "romance_slow_burn",
                value: trans("Slow Burn")
            },
            {
                key: "small_town",
                value: trans("Small Town")
            },
            {
                key: "romance_sports",
                value: trans("Sports")
            },
            {
                key: "romance_workplace",
                value: trans("Workplace")
            }
        ]
    },
    {
        key: "science_fiction",
        value: trans("Science Fiction"),
        subgenres: [{
                key: "alien_contact",
                value: trans("Alien Contact")
            },
            {
                key: "scifi_apocalyptic_dystopian",
                value: trans("Apocalyptic/Dystopian")
            },
            {
                key: "artificial_intelligence",
                value: trans("Artificial Intelligence")
            },
            {
                key: "scifi_litrpg",
                value: trans("LitRPG")
            },
            {
                key: "scifi_slice_of_life",
                value: trans("Slice of Life")
            },
            {
                key: "space_exploration",
                value: trans("Space Exploration")
            },
            {
                key: "steampunk",
                value: trans("Steampunk")
            },
            {
                key: "technological",
                value: trans("Technological")
            },
            {
                key: "time_travel",
                value: trans("Time Travel")
            },
            {
                key: "scifi_war_military",
                value: trans("War & Military")
            }
        ]
    },
    {
        key: "young_adult",
        value: trans("Young Adult"),
        subgenres: [{
                key: "young_adult_body_positivity",
                value: trans("Body Positivity")
            },
            {
                key: "young_adult_coming_of_age",
                value: trans("Coming of Age")
            },
            {
                key: "young_adult_disability_illness",
                value: trans("Disability and Illness")
            },
            {
                key: "young_adult_family_life",
                value: trans("Family Life")
            },
            {
                key: "young_adult_friendship",
                value: trans("Friendship")
            },
            {
                key: "young_adult_mental_health",
                value: trans("Mental Health")
            },
            {
                key: "young_adult_romance",
                value: trans("Romance")
            },
            {
                key: "young_adult_school_life",
                value: trans("School Life")
            },
            {
                key: "young_adult_social_issues",
                value: trans("Social Issues")
            },
            {
                key: "young_adult_tragedy",
                value: trans("Tragedy")
            }
        ]
    },
    {
        key: "wild_card",
        value: trans("Wild Card"),
        subgenres: []
    },
    {
        key: "sequels",
        value: trans("Sequels"),
        onlyEnglish: true,
        subgenres: []
    }
];

export const MAP_WATTYS_LANGUAGES = trans => [{
        code: "en",
        value: trans("English")
    },
    {
        code: "fr",
        value: trans("French")
    },
    {
        code: "tl",
        value: trans("Filipino")
    },
    {
        code: "de",
        value: trans("German")
    },
    {
        code: "id",
        value: trans("Indonesian")
    },
    {
        code: "it",
        value: trans("Italian")
    },
    {
        code: "pt",
        value: trans("Portuguese")
    },
    {
        code: "es",
        value: trans("Spanish")
    },
    {
        code: "tr",
        value: trans("Turkish")
    }
];

export const MAP_MATURITY_RATINGS = trans => [{
        key: "no_sexual_content",
        value: trans("No sexual content")
    },
    {
        key: "steamy",
        value: trans("Steamy")
    },
    {
        key: "fade_to_black",
        value: trans("Fade to Black")
    },
    {
        key: "explicit_rare",
        value: trans("Explicit Sex Rare")
    },
    {
        key: "explicit_common",
        value: trans("Explicit Sex Common")
    }
];

export const MAP_TARGET_AUDIENCE = trans => [{
        key: "8-12",
        value: trans("Middle Grade (8-12 years old)")
    },
    {
        key: "13-18",
        value: trans("Young Adult (13-18 years old)")
    },
    {
        key: "18-24",
        value: trans("New Adult (18-24 years old)")
    },
    {
        key: "25+",
        value: trans("Adult (25+ years old)")
    }
];

export const MAP_MATURE_THEMES = (trans, isFrenchForm) => [{
        key: "none",
        value: trans("My story does not contain any mature themes")
    },
    {
        key: "sex",
        value: isFrenchForm ?
            /* prettier-ignore */ trans("Sexual Content") :
            /* prettier-ignore */ trans("Sex")
    },
    {
        key: "language",
        value: trans("Explicit Language")
    },
    {
        key: "drug_use",
        value: trans("Drug Use")
    },
    {
        key: "self-harm",
        value: trans("Self-harm")
    },
    {
        key: "other",
        value: trans("Other")
    }
];