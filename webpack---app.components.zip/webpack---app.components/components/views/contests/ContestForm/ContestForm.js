import {
    connect
} from "react-redux";
import classNames from "classnames";
import PropTypes from "prop-types";
import React, {
    useState,
    useEffect,
    useCallback
} from "react";

import {
    ContestFormHeader
} from "./ContestFormHeader";
import {
    fetchContestForm,
    setContestForm
} from "./reducers";
import {
    FormValidation
} from "./FormValidation";

import {
    SubmissionSuccess
} from "./SubmissionSuccess";
import {
    useTrans
} from "../../../hooks";
import {
    Icon,
    Loader,
    NewCheckbox
} from "../../../shared-components";

import {
    getLength,
    requiredField,
    maxCharLengthField,
    minCharLengthField,
    formToSubmissionBody,
    getCategoryTranslation,
    getCategorySubgenres,
    filterCategoryByLanguage
} from "./helpers";
import {
    MAP_MATURE_THEMES,
    MAP_AWARD_CATEGORY,
    EMAIL_CHARACTER_MAX,
    LOGLINE_CHARACTER_MAX,
    LOGLINE_CHARACTER_MIN,
    PLOT_SUMMARY_CHARACTER_MAX,
    PLOT_SUMMARY_CHARACTER_MIN,
    MAP_RULES_LANGUAGE_TO_LINKS,
    OTHER_MATURE_THEMES_CHARACTER_MAX,
    WATTYS_CLOSING_DATETIME,
    MAP_WATTYS_LANGUAGES,
    MAP_MATURITY_RATINGS,
    MAP_TARGET_AUDIENCE
} from "./constants";

let submitted = false;

function Form({
    submitForm,
    closeModal,
    isStandalonePage,
    storyId,
    setContestForm,
    formState,
    formIsOpen
}) {
    // Default values from server
    const {
        data: initialData
    } = formState;

    let {
        hasSubmitted,
        isLoading
    } = formState;
    let disableForm = hasSubmitted || isLoading || !formIsOpen;

    // States
    const [form, setForm] = useState(initialData.contest_submission);
    const [emailConfirmField, setEmailConfirmField] = useState("");
    const [rulesLink, setRulesLink] = useState("");
    const [isFrenchForm, setIsFrenchForm] = useState(false);
    const [fieldStatus, setStatus] = useState({
        fieldName: "",
        fieldInvalid: false
    });
    const [requiredMatureThemesError, setRequiredMatureThemesError] = useState(
        false
    );

    // Update form state when redux store finishes fetching
    useEffect(
        () => {
            setForm(initialData.contest_submission);
            setRulesLink(
                MAP_RULES_LANGUAGE_TO_LINKS[parseInt(app.get("language"), 10)]
            );
            if (parseInt(app.get("language"), 10) === 2) {
                setIsFrenchForm(true);
            }
        }, [initialData.contest_submission]
    );

    const {
        trans
    } = useTrans();

    const isFieldInvalid = form => {
        return (
            form.award_category.length === 0 ||
            form.language.length === 0 ||
            form.mature_themes.length === 0 ||
            (form.mature_themes.includes("other") &&
                form.others.mature_themes === "") ||
            (form.mature_themes.includes("sex") && form.sexual_content === "") ||
            form.target_audience === "" ||
            form.plot_details.summary === "" ||
            form.plot_details.logline === "" ||
            form.preferred_email === "" ||
            emailConfirmField === "" ||
            emailConfirmField !== form.preferred_email ||
            !form.is_exclusive ||
            !form.is_final_consent
        );
    };

    function onSubmit(event) {
        event.preventDefault();
        event.stopPropagation();
        // Build data to send over.
        submitted = true;

        if (isFieldInvalid(form)) {
            setStatus({
                fieldInvalid: true
            });
        }

        const body = formToSubmissionBody(parseInt(storyId), form);

        const canSubmit = !disableForm &&
            (form.plot_details.logline &&
                getLength(form.plot_details.logline) <= LOGLINE_CHARACTER_MAX &&
                getLength(form.plot_details.logline) >= LOGLINE_CHARACTER_MIN &&
                form.award_category &&
                (form.mature_themes.includes("sex") ? form.sexual_content : true) &&
                form.target_audience &&
                form.language &&
                form.plot_details.summary &&
                getLength(form.plot_details.summary) >= PLOT_SUMMARY_CHARACTER_MIN &&
                getLength(form.plot_details.summary) <= PLOT_SUMMARY_CHARACTER_MAX) &&
            form.preferred_email &&
            getLength(form.preferred_email) <= EMAIL_CHARACTER_MAX &&
            emailConfirmField &&
            getLength(emailConfirmField) <= EMAIL_CHARACTER_MAX &&
            form.preferred_email === emailConfirmField &&
            form.mature_themes.length != 0 &&
            !requiredMatureThemesError &&
            (form.mature_themes.includes("other") ?
                form.others.mature_themes.length != 0 :
                true) &&
            getLength(form.others.mature_themes) <=
            OTHER_MATURE_THEMES_CHARACTER_MAX &&
            form.is_exclusive != false &&
            form.is_final_consent != false;

        if (canSubmit) {
            setContestForm(storyId, body).then(hasAddedWattysTag => {
                submitForm(hasAddedWattysTag);
            });
        }
    }

    const onMatureThemesChange = useCallback(
        event => {
            let newMatureThemes;
            const {
                name,
                checked
            } = event.target;
            setStatus({
                fieldName: "mature_themes",
                fieldInvalid: false
            });
            if (checked) {
                // Add mature theme
                if (form.mature_themes.includes("none")) {
                    newMatureThemes = form.mature_themes.filter(
                        mature_theme => mature_theme !== "none"
                    );
                    newMatureThemes = [...newMatureThemes, name];
                } else if (name === "none") {
                    newMatureThemes = ["none"];
                } else {
                    newMatureThemes = [...form.mature_themes, name];
                }
            } else {
                // Remove mature theme
                newMatureThemes = form.mature_themes.filter(
                    mature_theme => mature_theme !== name
                );
            }
            setRequiredMatureThemesError(newMatureThemes.length === 0);

            if (name === "other" || (name === "none" && checked === true)) {
                setForm({
                    ...form,
                    mature_themes: newMatureThemes,
                    others: {
                        ...form.others,
                        mature_themes: ""
                    }
                });
            } else {
                setForm({
                    ...form,
                    mature_themes: newMatureThemes
                });
            }
        }, [form]
    );

    function onOtherMatureFieldTextChange(event) {
        const {
            name,
            value
        } = event.target;
        setStatus({
            fieldName: name,
            fieldInvalid: false
        });

        setForm({
            ...form,
            others: {
                ...form.others,
                [name]: value
            }
        });
    }

    const onRadioBtnChange = event => {
        const {
            name,
            value
        } = event.target;

        let boolVal = value !== 0;
        if (name == "is_exclusive" || name == "is_final_consent") {
            boolVal = event.target.checked;
        }

        setForm({ ...form,
            [name]: boolVal
        });
    };

    function onFormChange(event) {
        const {
            name,
            value
        } = event.target;
        if (name === "language") {
            setStatus({
                fieldName: "language",
                fieldInvalid: false
            });
            setForm({
                ...form,
                [name]: value,
                award_category: "",
                subgenre: ""
            });
        } else if (name === "award_category") {
            setForm({
                ...form,
                [name]: value,
                subgenre: ""
            });
        } else {
            setStatus({
                fieldName: name,
                fieldInvalid: false
            });
            setForm({
                ...form,

                [name]: value
            });
        }
    }

    function onSummaryChange(event) {
        const {
            name,
            value
        } = event.target;
        setStatus({
            fieldName: name,
            fieldInvalid: false
        });

        setForm({
            ...form,
            plot_details: {
                ...form.plot_details,
                [name]: value
            }
        });
    }

    function onLoglineChange(event) {
        const {
            name,
            value
        } = event.target;
        setStatus({
            fieldName: name,
            fieldInvalid: false
        });
        setForm({
            ...form,
            plot_details: {
                ...form.plot_details,
                [name]: value
            }
        });
    }

    function onPreferredEmailChange(event) {
        const {
            name,
            value
        } = event.target;
        setStatus({
            fieldName: name,
            fieldInvalid: false
        });
        setForm({
            ...form,
            [name]: value
        });
    }

    const renderSubgenre = () => {
        const subgenres = getCategorySubgenres(trans, form.award_category);
        if (form.award_category === "" || subgenres.length > 0) {
            return ( <
                div className = "inline-row" >
                <
                h4 > {
                    trans("Story subgenre")
                } < /h4> <
                div className = "subtitle"
                dangerouslySetInnerHTML = {
                    {
                        __html: /* prettier-ignore */ trans('Subgenre declaration helps us learn more about your story and does not influence winners chosen for award categories. For more information on subgenres click <a href=%s target="_blank" rel="noopener noreferrer">HERE</a>', "https://www.wattpad.com/480647104-community-news-updates-profile-directory-explore")
                    }
                }
                /> <
                select id = "subgenre-select"
                value = {
                    form.subgenre
                }
                name = "subgenre"
                disabled = {
                    disableForm
                }
                className = "form-element"
                onChange = {
                    onFormChange
                }
                aria - label = {
                    trans("Select a subgenre")
                } >
                <
                option value = "" > {
                    trans("Select a subgenre")
                } < /option> {
                    subgenres.map(subgenre => ( <
                        option key = {
                            subgenre.key
                        }
                        value = {
                            subgenre.key
                        } > {
                            subgenre.value
                        } <
                        /option>
                    ))
                } <
                /select> <
                /div>
            );
        }
    };

    if (isLoading && hasSubmitted) {
        return ( <
            div className = "loading-spinner" >
            <
            Loader / >
            <
            /div>
        );
    }
    return ( <
        div id = "contest-form" >
        <
        form >
        <
        div className = {
            classNames("overflow-container", {
                disabled: isLoading
            })
        } >
        <
        ContestFormHeader subtitle = {
            /* prettier-ignore */
            trans("Thank you for your interest in the 2022 Watty Awards. In order to be considered for this year's awards, complete the following submission form.")
        }
        closeModal = {
            closeModal
        }
        isStandalonePage = {
            isStandalonePage
        }
        /> <
        div className = "form-deadline" >
        <
        div className = "deadline-text"
        dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("Submissions are due by August 19th, 2022. For full eligibility criteria, refer to the <a href=%s target=\"_blank\" rel=\"noopener noreferrer\">Rules and Regulations</a>.", rulesLink)
            }
        }
        /> <
        /div> <
        div className = "form-content" > {!formIsOpen && ( <
                div className = "form-message-box"
                dangerouslySetInnerHTML = {
                    {
                        __html: /* prettier-ignore */ trans("The 2022 Watty Awards are now closed. Thanks for your participation!")
                    }
                }
                />
            )
        } {
            hasSubmitted && ( <
                div className = "form-message-box"
                dangerouslySetInnerHTML = {
                    {
                        __html: /* prettier-ignore */ trans("You are viewing your submission for the ‘<strong>%s</strong>’ category in the 2022 Watty Awards. Changes cannot be made.", getCategoryTranslation(trans, formState.data.contest_submission.award_category))
                    }
                }
                />
            )
        } {
            !hasSubmitted &&
                formIsOpen && ( <
                    div className = "form-title"
                    id = "form-title"
                    dangerouslySetInnerHTML = {
                        {
                            /* prettier-ignore */
                            __html: trans("We need a few more details about the story you are entering:<br><span class='bold'>“%s”</span>", formState.title)
                        }
                    }
                    />
                )
        }

        <
        div className = "inline-row" >
        <
        h4 > {
            trans("Language")
        } < /h4> <
        div className = "subtitle" > {
            trans(
                "Select the award language you wish to be considered for. Stories that do not fit under any of the languages listed below will not be eligible to win."
            )
        } <
        /div> <
        FormValidation validationRules = {
            [requiredField(trans)]
        } > {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                select id = "language-select"
                ref = {
                    ref
                }
                value = {
                    form.language
                }
                name = "language"
                disabled = {
                    disableForm
                }
                className = {
                    classNames("form-element", className)
                }
                onChange = {
                    onFormChange
                }
                aria - label = {
                    trans("Select a language")
                } >
                <
                option value = ""
                disabled > {
                    trans("Select a language")
                } <
                /option> {
                    MAP_WATTYS_LANGUAGES(trans).map(lang => ( <
                        option key = {
                            lang.code
                        }
                        value = {
                            lang.code
                        } > {
                            lang.value
                        } <
                        /option>
                    ))
                } <
                /select> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid ||
                            (fieldStatus.fieldName !== "language" &&
                                fieldStatus.fieldName !== "" &&
                                submitted)) &&
                        form.language === "" && ( <
                            div className = "error-text"
                            id = "language-field-error" > {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> <
        /div>

        <
        div className = "inline-row" >
        <
        h4 > {
            trans("Award category")
        } < /h4> <
        div className = "subtitle"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans('Select the award category you wish to be considered for. If you don\'t see a category that you feel matches your story exactly, please submit under the category that you think is the closest match.')
            }
        }
        /> <
        FormValidation validationRules = {
            [requiredField(trans)]
        } > {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                select ref = {
                    ref
                }
                id = "award-category-select"
                value = {
                    form.award_category
                }
                name = "award_category"
                disabled = {
                    disableForm
                }
                className = {
                    classNames("form-element", className)
                }
                onChange = {
                    onFormChange
                }
                aria - label = {
                    trans("Select a category")
                } >
                <
                option value = ""
                disabled > {
                    trans("Select a category")
                } <
                /option> {
                    MAP_AWARD_CATEGORY(trans)
                        .filter(filterCategoryByLanguage(form.language))
                        .map(category => ( <
                            option key = {
                                category.key
                            }
                            value = {
                                category.key
                            } > {
                                category.value
                            } <
                            /option>
                        ))
                } <
                /select> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid == true ||
                            (fieldStatus.fieldName != "award_category" &&
                                fieldStatus.fieldName != "" &&
                                submitted)) &&
                        form.award_category == "" && ( <
                            div className = "error-text"
                            id = "award-category-field-error" >
                            {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> <
        /div>

        {
            renderSubgenre()
        }

        <
        div className = "inline-row" >
        <
        h4 > {
            trans("Mature themes")
        } < /h4> <
        div className = "subtitle" > {
            trans("Select the themes that your story contains.")
        } <
        /div> <
        div id = "mature-themes" > {
            MAP_MATURE_THEMES(trans, isFrenchForm).map(theme => ( <
                div className = "checkbox-group"
                key = {
                    theme.key
                } >
                <
                NewCheckbox name = {
                    theme.key
                }
                disabled = {
                    disableForm
                }
                onChange = {
                    onMatureThemesChange
                }
                contentId = {
                    `mature-themes-${theme.key}`
                }
                checked = {
                    form.mature_themes.includes(theme.key)
                } >
                {
                    theme.value
                } <
                /NewCheckbox> <
                /div>
            ))
        } <
        /div> {
            requiredMatureThemesError &&
                !disableForm && ( <
                    div className = "error-text" > {
                        trans("You must pick at least 1")
                    } <
                    /div>
                )
        } {
            !requiredMatureThemesError &&
                (fieldStatus.fieldInvalid == true ||
                    (fieldStatus.fieldName != "mature_themes" &&
                        fieldStatus.fieldName != "" &&
                        submitted)) &&
                form.mature_themes.length == 0 && ( <
                    div className = "error-text" > {
                        trans("This field is required.")
                    } <
                    /div>
                )
        }

        {
            form.mature_themes.includes("other") && ( <
                div className = "inline-row" >
                <
                h4 > {
                    trans("Mature themes")
                } < /h4> <
                FormValidation validationRules = {
                    [
                        requiredField(trans),
                        maxCharLengthField(
                            OTHER_MATURE_THEMES_CHARACTER_MAX,
                            trans
                        )
                    ]
                } >
                {
                    ({
                        ref,
                        className
                    }) => ( <
                        React.Fragment >
                        <
                        textarea ref = {
                            ref
                        }
                        className = {
                            classNames("form-element", className)
                        }
                        id = "other-themes-textarea"
                        name = "mature_themes"
                        value = {
                            form.others.mature_themes
                        }
                        placeholder = {
                            trans("Enter your mature themes")
                        }
                        disabled = {
                            disableForm
                        }
                        onChange = {
                            onOtherMatureFieldTextChange
                        }
                        /> {
                            form.others.mature_themes === "" && ( <
                                div className = "error-text"
                                id = "other-theme-error" > {
                                    trans("Specify other mature themes.")
                                } <
                                /div>
                            )
                        } {
                            form.others.mature_themes ? .length >
                                OTHER_MATURE_THEMES_CHARACTER_MAX && ( <
                                    div className = "error-text" > {
                                        trans(
                                            "This field has to contain less than 100 characters."
                                        )
                                    } <
                                    /div>
                                )
                        } <
                        /React.Fragment>
                    )
                } <
                /FormValidation> <
                /div>
            )
        } <
        /div> {
            form.mature_themes.includes("sex") && ( <
                div className = "inline-row" >
                <
                div className = "story-maturity-title-container" >
                <
                h4 > {
                    trans("Story Maturity")
                } < /h4> <
                button id = "content-tooltip"
                className = "icon-container on-contest-popover popover-icon" >
                <
                Icon iconName = "fa-warning"
                height = "17"
                color = "wp-neutral-2" /
                >
                <
                /button> <
                /div> <
                div className = "subtitle" > {
                    trans("Select one of the story maturity ratings:")
                } <
                /div> <
                FormValidation validationRules = {
                    [requiredField(trans)]
                } > {
                    ({
                        ref,
                        errorMessage,
                        className
                    }) => ( <
                        React.Fragment >
                        <
                        select ref = {
                            ref
                        }
                        id = "maturity-rating-select"
                        value = {
                            form.sexual_content
                        }
                        name = "sexual_content"
                        disabled = {
                            disableForm
                        }
                        className = {
                            classNames(
                                "form-element sexual-content",
                                className
                            )
                        }
                        onChange = {
                            onFormChange
                        }
                        aria - label = {
                            trans("Select a maturity level")
                        } >
                        <
                        option value = ""
                        disabled > {
                            trans("Select a maturity level")
                        } <
                        /option> {
                            MAP_MATURITY_RATINGS(trans).map(rating => ( <
                                option key = {
                                    rating.key
                                }
                                value = {
                                    rating.key
                                } > {
                                    rating.value
                                } <
                                /option>
                            ))
                        } <
                        /select> {
                            errorMessage && ( <
                                div className = "error-text" > {
                                    errorMessage
                                } < /div>
                            )
                        } {
                            !errorMessage &&
                                (fieldStatus.fieldInvalid == true ||
                                    (fieldStatus.fieldName != "sexual_content" &&
                                        fieldStatus.fieldName != "" &&
                                        submitted)) &&
                                form.sexual_content == "" && ( <
                                    div className = "error-text"
                                    id = "maturity-rating-field-error" >
                                    {
                                        trans("This field is required.")
                                    } <
                                    /div>
                                )
                        } <
                        /React.Fragment>
                    )
                } <
                /FormValidation> <
                /div>
            )
        } <
        div className = "inline-row" >
        <
        h4 > {
            trans("Target Audience")
        } < /h4> <
        div className = "subtitle" > {
            trans("Tell us what age group your story is intended for.")
        } <
        /div> <
        FormValidation validationRules = {
            [requiredField(trans)]
        } > {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                select ref = {
                    ref
                }
                id = "target-audience-select"
                value = {
                    form.target_audience
                }
                name = "target_audience"
                disabled = {
                    disableForm
                }
                className = {
                    classNames("form-element", className)
                }
                onChange = {
                    onFormChange
                }
                aria - label = {
                    trans("Select an audience")
                } >
                <
                option value = ""
                disabled > {
                    trans("Select an audience")
                } <
                /option> {
                    MAP_TARGET_AUDIENCE(trans).map(target => ( <
                        option key = {
                            target.key
                        }
                        value = {
                            target.key
                        } > {
                            target.value
                        } <
                        /option>
                    ))
                } <
                /select> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid == true ||
                            (fieldStatus.fieldName != "target_audience" &&
                                fieldStatus.fieldName != "" &&
                                submitted)) &&
                        form.target_audience == "" && ( <
                            div className = "error-text"
                            id = "target-audience-field-error" >
                            {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> <
        /div> <
        div className = "inline-row" >
        <
        h4 > {
            trans("Logline")
        } < /h4> <
        div className = "subtitle"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans("Give us a one-sentence description of your story that conveys the dramatic narrative and hook. It should follow the below format:<br>[Character Name], [Character Description], has to [Action] in order to [Result].")
            }
        }
        /> <
        div className = "subtitle"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans("Ex. “Cleopatra, <strong>a</strong> zombified ruler of Egypt, <strong>has to</strong> resist the temptation of eating Mark Antony, <strong>in order to</strong> not change the course of Egypt's future.”")
            }
        }
        /> <
        FormValidation validationRules = {
            [
                requiredField(trans),
                maxCharLengthField(LOGLINE_CHARACTER_MAX, trans),
                minCharLengthField(LOGLINE_CHARACTER_MIN, trans)
            ]
        } >
        {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                textarea ref = {
                    ref
                }
                id = "logline-textarea"
                className = {
                    classNames("form-element", className)
                }
                name = "logline"
                value = {
                    form.plot_details.logline
                }
                placeholder = {
                    trans("Enter your logline")
                }
                disabled = {
                    disableForm
                }
                onChange = {
                    onLoglineChange
                }
                /> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid == true ||
                            (fieldStatus.fieldName != "logline" &&
                                fieldStatus.fieldName != "" &&
                                submitted)) &&
                        form.plot_details.logline == "" && ( <
                            div className = "error-text"
                            id = "logline-feild-error" > {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> <
        /div> <
        div className = "inline-row" >
        <
        h4 > {
            trans("Plot Summary")
        } < /h4> <
        div className = "subtitle"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans(
                    "How to Write a Story Summary:<br/>Your summary should be at least 750 words, introduce the main character(s) and tell us everything that happens in the story.<br/>Who, what, where? Introduce us to your hero, the conflict, and the world. Tell us about your villain and the most important secondary characters.<br/>What happens next? Tell us all of the events of the story - this can be in point-form and does not have to describe the actions of each individual chapter.<br/>How does it end? Tell us how the story resolves and what happens to each of the central characters."
                )
            }
        }
        /> {
            form.language === "en" && ( <
                div className = "subtitle"
                dangerouslySetInnerHTML = {
                    {
                        __html: /* prettier-ignore */ trans("If you are submitting a Sequel (which should <i>only</i> be submitted to the Sequels Category), please also give us a summary of the previous book(s) in the series.")
                    }
                }
                />
            )
        } <
        FormValidation validationRules = {
            [
                requiredField(trans),
                minCharLengthField(PLOT_SUMMARY_CHARACTER_MIN, trans),
                maxCharLengthField(PLOT_SUMMARY_CHARACTER_MAX, trans)
            ]
        } >
        {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                textarea ref = {
                    ref
                }
                id = "summary-textarea"
                className = {
                    classNames("form-element", className)
                }
                name = "summary"
                value = {
                    form.plot_details.summary
                }
                disabled = {
                    disableForm
                }
                onChange = {
                    onSummaryChange
                }
                placeholder = {
                    trans("Enter your plot summary")
                }
                /> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid == true ||
                            (fieldStatus.fieldName != "summary" &&
                                fieldStatus.fieldName != "" &&
                                submitted)) &&
                        form.plot_details.summary == "" && ( <
                            div className = "error-text"
                            id = "summary-field-error" > {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> <
        /div> {
            !hasSubmitted && ( <
                div className = "inline-row" >
                <
                div className = "form-title form-title-width-limited"
                id = "second-header"
                dangerouslySetInnerHTML = {
                    {
                        /* prettier-ignore */
                        __html: trans("There are just a few more things to answer to complete your submission for the <strong>thewattys2022</strong>", formState.title)
                    }
                }
                /> <
                /div>
            )
        } <
        div className = "inline-row" >
        <
        h4 > {
            trans("Exclusivity")
        } < /h4> <
        div className = "subtitle" > { /* prettier-ignore */
            trans("If you are notified that your story has been selected for the Wattys shortlist, it is expected that your story be exclusive to Wattpad for the period between when we tell you you’re on the shortlist until the date we announce the winners. If you are notified that your story has won a Watty, it is expected that your story be exclusive to Wattpad for 1 year from the date that we announce the Wattys winners. You will not be permitted to upload it to another platform and you will be required to remove it from existing platforms.")
        } <
        /div> <
        div className = "subtitle" > { /* prettier-ignore */
            trans("I agree to make the story exclusive on Wattpad for the periods of time listed above, if my story is selected for the shortlist and/or wins a Watty.")
        } <
        /div> <
        div className = "checkbox-group"
        id = "is-exclusive-select" >
        <
        NewCheckbox name = "is_exclusive"
        disabled = {
            disableForm
        }
        checked = {
            form.is_exclusive
        }
        onChange = {
            onRadioBtnChange
        }
        contentId = "is-exclusive-message" >
        {
            trans("I agree")
        } <
        /NewCheckbox> <
        /div> {
            (fieldStatus.fieldInvalid == true ||
                (fieldStatus.fieldName != "is_exclusive" &&
                    fieldStatus.fieldName != "" &&
                    submitted)) &&
            form.is_exclusive == false && ( <
                div className = "error-text"
                id = "exclusivity-error" > {
                    trans("This checkbox is required.")
                } <
                /div>
            )
        } <
        /div> <
        div className = "inline-row" >
        <
        h4 > {
            trans("Email")
        } < /h4> <
        div className = "subtitle"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans("What is the best email for us to contact you about your entry?")
            }
        }
        /> <
        FormValidation validationRules = {
            [
                requiredField(trans),
                maxCharLengthField(EMAIL_CHARACTER_MAX, trans)
            ]
        } >
        {
            ({
                ref,
                errorMessage,
                className
            }) => ( <
                React.Fragment >
                <
                input type = "email"
                ref = {
                    ref
                }
                id = "preferred-email-input"
                className = {
                    classNames(
                        "form-element",
                        className,
                        "half-width"
                    )
                }
                name = "preferred_email"
                value = {
                    form.preferred_email
                }
                placeholder = {
                    trans("Email address")
                }
                disabled = {
                    disableForm
                }
                onChange = {
                    onPreferredEmailChange
                }
                /> {
                    errorMessage && ( <
                        div className = "error-text" > {
                            errorMessage
                        } < /div>
                    )
                } {
                    !errorMessage &&
                        (fieldStatus.fieldInvalid == true ||
                            (fieldStatus.fieldName != "preferred_email" &&
                                fieldStatus.fieldName != "" &&
                                submitted)) &&
                        form.preferred_email == "" && ( <
                            div className = "error-text"
                            id = "preferred-email-field-error" >
                            {
                                trans("This field is required.")
                            } <
                            /div>
                        )
                } <
                /React.Fragment>
            )
        } <
        /FormValidation> {
            !hasSubmitted && ( <
                div className = "secondary-email" >
                <
                FormValidation validationRules = {
                    [
                        requiredField(trans),
                        maxCharLengthField(EMAIL_CHARACTER_MAX, trans)
                    ]
                } >
                {
                    ({
                        ref,
                        errorMessage,
                        className
                    }) => ( <
                        React.Fragment >
                        <
                        input type = "email"
                        ref = {
                            ref
                        }
                        id = "confirm-email-input"
                        className = {
                            classNames(
                                "form-element",
                                className,
                                "half-width"
                            )
                        }
                        name = "email_confirm_field"
                        value = {
                            emailConfirmField
                        }
                        placeholder = {
                            trans("Confirm email address")
                        }
                        disabled = {
                            disableForm
                        }
                        onChange = {
                            ({
                                target: {
                                    value
                                }
                            }) =>
                            setEmailConfirmField(value)
                        }
                        /> {
                            errorMessage && ( <
                                div className = "error-text" > {
                                    errorMessage
                                } < /div>
                            )
                        } {
                            !hasSubmitted &&
                                !errorMessage &&
                                (fieldStatus.fieldInvalid == true || submitted) &&
                                emailConfirmField == "" && ( <
                                    div className = "error-text"
                                    id = "confirm-email-field-error" >
                                    {
                                        trans("This field is required.")
                                    } <
                                    /div>
                                )
                        } {
                            !hasSubmitted &&
                                form.preferred_email != emailConfirmField && ( <
                                    div className = "error-text"
                                    id = "matching-email-error" >
                                    {
                                        trans("These two fields must match.")
                                    } <
                                    /div>
                                )
                        } <
                        /React.Fragment>
                    )
                } <
                /FormValidation> <
                /div>
            )
        } <
        /div> <
        /div> <
        div className = "footer-section-submission" >
        <
        div className = "checkbox-group"
        id = "final-consent-checkbox" >
        <
        NewCheckbox disabled = {
            disableForm
        }
        name = "is_final_consent"
        onChange = {
            onRadioBtnChange
        }
        checked = {
            form.is_final_consent
        }
        contentId = "consent-checkbox-message" >
        <
        div dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans('I confirm that I\'ve read, understood, and agree to the contest <a class="bold" target="_blank" rel="noopener noreferrer" href="%s">Rules and Regulations</a>.', rulesLink)
            }
        }
        /> <
        /NewCheckbox> <
        /div> {
            (fieldStatus.fieldInvalid == true ||
                (fieldStatus.fieldName != "is_final_consent" &&
                    fieldStatus.fieldName != "" &&
                    submitted)) &&
            form.is_final_consent == false && ( <
                div className = "error-text"
                id = "final-consent-error" > {
                    trans("This field is required.")
                } <
                /div>
            )
        } <
        div className = "subtitle-small" > {
            trans(
                "Ready to hit submit? Please note that once you’ve submitted your story, you won’t be able to resubmit the same one, so make sure your story is Wattys ready. This information will be kept confidential and is for internal purposes only."
            )
        } <
        /div> {
            isStandalonePage && hasSubmitted ? null : ( <
                div className = "btn-container" > {!hasSubmitted &&
                    formIsOpen && ( <
                        button type = "button"
                        onClick = {
                            onSubmit
                        }
                        className = "btn btn-primary submit-btn" >
                        {
                            trans("Enter the 2022 Wattys!")
                        } <
                        /button>
                    )
                } <
                /div>
            )
        } <
        /div> <
        /div> <
        /form> <
        /div>
    );
}

Form.propTypes = {
    submitForm: PropTypes.func.isRequired,
    closeModal: PropTypes.func.isRequired,
    isStandalonePage: PropTypes.bool.isRequired,
    fetchContestForm: PropTypes.func,
    setContestForm: PropTypes.func,
    storyId: PropTypes.string,
    formIsOpen: PropTypes.bool,
    formState: PropTypes.shape({
        isLoading: PropTypes.bool.isRequired,
        hasSubmitted: PropTypes.bool.isRequired,
        cover: PropTypes.string.isRequired,
        user: PropTypes.string.isRequired,
        title: PropTypes.string,
        data: PropTypes.shape({
            story_id: PropTypes.number,
            contest_submission: PropTypes.shape({
                contest: PropTypes.string,
                award_category: PropTypes.string.isRequired,
                target_audience: PropTypes.string.isRequired,
                is_exclusive: PropTypes.bool,
                is_final_consent: PropTypes.bool,
                mature_themes: PropTypes.arrayOf(PropTypes.string).isRequired,
                language: PropTypes.string.isRequired,
                preferred_email: PropTypes.string,
                others: PropTypes.shape({
                    mature_themes: PropTypes.string
                }),
                plot_details: PropTypes.shape({
                    summary: PropTypes.string.isRequired,
                    logline: PropTypes.string.isRequired
                }).isRequired
            })
        }),
        language: PropTypes.number
    })
};

Form.defaultProps = {
    formIsOpen: new Date().getTime() < WATTYS_CLOSING_DATETIME
};

const ContestFormUI = ({
    success,
    isStandalonePage,
    closeModal,
    storyId,
    formState,
    fetchContestForm,
    setContestForm
}) => {
    const [view, setView] = useState("form");
    let component;

    // Fetch contest form from server
    useEffect(
        () => {
            if (storyId) {
                fetchContestForm(storyId);
            }
        }, [storyId, fetchContestForm]
    );

    function onSubmit(hasAddedWattysTag) {
        if (isStandalonePage) {
            // Standalone page: we maintain the state via url. We modify href so the clients can detect this change in url.
            window.location.href = `/contests/${
        window.wattpad.wattysActiveKey
      }?storyId=${storyId}&success=true&hasAddedWattysTag=${hasAddedWattysTag}`;
        } else {
            // Inside the modal: we maintain page state via the "view" param
            setView("success");
        }
    }

    if (view === "success" || success) {
        component = ( <
            SubmissionSuccess isStandalonePage = {
                isStandalonePage
            }
            formState = {
                formState
            }
            closeModal = {
                closeModal
            }
            />
        );
    } else {
        component = ( <
            Form storyId = {
                storyId
            }
            closeModal = {
                closeModal
            }
            formState = {
                formState
            }
            setContestForm = {
                setContestForm
            }
            isStandalonePage = {
                isStandalonePage
            }
            submitForm = {
                onSubmit
            }
            />
        );
    }
    return component;
};

ContestFormUI.defaultProps = {
    success: false,
    isStandalonePage: false,
    closeModal: () => {},
    storyId: ""
};

ContestFormUI.propTypes = {
    formState: PropTypes.object,
    fetchContestForm: PropTypes.func,
    setContestForm: PropTypes.func,
    closeModal: PropTypes.func,
    success: PropTypes.bool,
    hasAddedWattysTag: PropTypes.bool,
    isStandalonePage: PropTypes.bool,
    storyId: PropTypes.string
};

const ContestForm = connect(
    state => ({
        formState: { ...state.contestForm
        }
    }), {
        fetchContestForm,
        setContestForm
    }
)(ContestFormUI);

export {
    ContestForm,
    ContestFormUI,
    Form
};