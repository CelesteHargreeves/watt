import {
    MAP_AWARD_CATEGORY
} from "./constants";

export const getLength = text => {
    // https://stackoverflow.com/questions/5515869/string-length-in-bytes-in-javascript
    return encodeURI(text).split(/%..|./).length - 1;
};

export const requiredField = trans => ({
    rule: value => value.length > 0,
    errorMessage: () => trans("This field is required.")
});

export const maxCharLengthField = (maxLength, trans) => ({
    rule: value => getLength(value) <= maxLength,
    errorMessage: () =>
        trans("This field has to contain less than %s characters.", maxLength)
});

export const minCharLengthField = (minLength, trans) => ({
    rule: value => getLength(value) >= minLength,
    errorMessage: () =>
        trans("This field has to contain more than %s characters.", minLength)
});

export const getCategoryByKey = (trans, categoryKey) =>
    MAP_AWARD_CATEGORY(trans).find(cat => cat.key === categoryKey);

export const getCategoryTranslation = (trans, categoryKey) =>
    getCategoryByKey(trans, categoryKey) ? .value;

export const getCategorySubgenres = (trans, categoryKey) =>
    getCategoryByKey(trans, categoryKey) ? .subgenres || [];

/*
 * Return false if the language is not english and the category is marked to be shown only for english
 * */
export const filterCategoryByLanguage = language => category =>
    !(!!category.onlyEnglish && language !== "en");

export const formToSubmissionBody = (storyId, formData) => {
    const submissionBody = {
        story_id: storyId,
        contest_submission: {
            award_category: formData.award_category,
            language: formData.language,
            mature_themes: formData.mature_themes,
            sexual_content: "no_sexual_content",
            target_audience: formData.target_audience,
            plot_details: formData.plot_details,
            is_exclusive: formData.is_exclusive,
            preferred_email: formData.preferred_email,
            is_final_consent: formData.is_final_consent
        }
    };

    if (formData.subgenre ? .trim() !== "") {
        submissionBody.contest_submission.subgenre = formData.subgenre;
    }

    if (formData.mature_themes.includes("sex")) {
        submissionBody.contest_submission.sexual_content = formData.sexual_content;
    }
    if (formData.mature_themes.includes("other")) {
        submissionBody.contest_submission.others = {
            mature_themes: formData.others.mature_themes
        };
    }

    return submissionBody;
};