import React from "react";
import PropTypes from "prop-types";

import {
    useTrans
} from "../../../hooks";
import {
    MAP_WATTYS_MILESTONES_TO_LINKS
} from "../ContestForm/constants";
import {
    getCategoryTranslation
} from "../ContestForm/helpers";

const SuccessBanner = ({
    awardCategory
}) => {
    const {
        trans
    } = useTrans();

    return ( <
        div className = "text" >
        <
        div className = "success-text"
        dangerouslySetInnerHTML = {
            {
                __html: /* prettier-ignore */ trans("Your story has been submitted in the ‘<strong>%s</strong>’ category for the 2022 Watty Awards", getCategoryTranslation(trans, awardCategory))
            }
        }
        /> <
        a className = "plain-link bold margin-top"
        href = {
            MAP_WATTYS_MILESTONES_TO_LINKS[parseInt(app.get("language"), 10)]
        }
        target = "_blank"
        rel = "noopener noreferrer" >
        {
            trans("When will winners be announced?")
        } <
        /a> <
        /div>
    );
};

SuccessBanner.propTypes = {
    awardCategory: PropTypes.string.isRequired
};

export default SuccessBanner;