import React from "react";
import PropTypes from "prop-types";

import {
    useTrans
} from "../../../hooks";

const EligibleBanner = ({
    onBtnClick
}) => {
    const {
        trans
    } = useTrans();

    return ( <
        >
        <
        div className = "text" > {
            trans("Congratulations! Your story is eligible for the 2022 Wattys!")
        } <
        a className = "plain-link bold"
        href = "http://wattys.wattpad.com/"
        target = "_blank"
        rel = "noopener noreferrer" >
        {
            trans("Find out more about the Wattys")
        } <
        /a> <
        /div> <
        button onClick = {
            onBtnClick
        }
        className = "btn btn-white" >
        <
        div className = "btn-text" > {
            trans("Enter this story")
        } < /div> <
        /button> <
        />
    );
};

EligibleBanner.propTypes = {
    onBtnClick: PropTypes.func.isRequired
};

export default EligibleBanner;