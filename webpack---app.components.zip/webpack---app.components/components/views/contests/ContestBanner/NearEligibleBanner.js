import React from "react";

import {
    useTrans
} from "../../../hooks";
import {
    MAP_WATTYS_ELIGIBILITY_TO_LINKS
} from "../ContestForm/constants";

const NearEligibleBanner = () => {
    const {
        trans
    } = useTrans();

    return ( <
        >
        <
        div className = "text" >
        <
        span dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("Your story is <strong>so close</strong> to being eligible for the 2022 Wattys!")
            }
        }
        /> <
        a className = "plain-link bold"
        href = {
            MAP_WATTYS_ELIGIBILITY_TO_LINKS[parseInt(app.get("language"), 10)]
        }
        target = "_blank"
        rel = "noopener noreferrer" >
        {
            trans("What is the eligibility criteria?")
        } <
        /a> <
        /div> <
        a href = "https://www.wattpad.com/wattys"
        target = "_blank"
        rel = "noopener noreferrer"
        className = "btn btn-white" >
        <
        div className = "btn-text" > {
            trans("2022 Wattys")
        } < /div> <
        /a> <
        />
    );
};

export default NearEligibleBanner;