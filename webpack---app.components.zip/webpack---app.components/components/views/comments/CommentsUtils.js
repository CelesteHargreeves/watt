import Colours from "../../../assets/swatch";
import {
    fromNow
} from "../../helpers";
import {
    postSentiment,
    removeSentiment,
    SentimentNamespaces,
    SentimentTypes
} from "@wattpad/client-platform-comments";
import {
    BadgeToBadgeVariant,
    CommentsLocation,
    INIT_COMMENTS_REPLIES
} from "./CommentsConstants";

const commentResource = commentId => ({
    resourceId: commentId,
    namespace: SentimentNamespaces.COMMENTS
});

const writerPill = trans => ({
    text: trans("Writer"),
    color: Colours["ds-neutral-00-solid"],
    backgroundColor: Colours["ds-base-1-60"]
});

export const isStoryPart = location => location === CommentsLocation.STORY_PART;

export const isReply = location => location === CommentsLocation.REPLIES;

export const toBadgesVariant = badges =>
    badges ? badges.map(badge => BadgeToBadgeVariant[badge]) : [];

export const getPills = (isStoryWriter, trans) =>
    isStoryWriter ? [writerPill(trans)] : [];

export const toPostedDate = createDate =>
    fromNow(createDate, {
        fuzzyTime: true
    });

export const getLikes = sentiments => sentiments ? .[SentimentTypes.LIKE];

export const getIsLiked = sentiments => !!getLikes(sentiments) ? .interaction;

export const getLikesCount = sentiments => getLikes(sentiments) ? .count || 0;

export const removeLike = commentId =>
    removeSentiment(commentResource(commentId), SentimentTypes.LIKE);

export const addLike = commentId =>
    postSentiment(commentResource(commentId), SentimentTypes.LIKE);

export const canDeleteComment = (user, commentAuthor, storyAuthor) => {
    const isAmbassador = user.ambassador || user.isSysAdmin;
    const isStoryAuthor = storyAuthor === user.username;
    const isCommentAuthor = commentAuthor.name === user.username;

    return {
        canDelete: user && (isAmbassador || isStoryAuthor || isCommentAuthor),
        isCommentAuthor
    };
};

export const getReplyLimit = (showReplyBox, replyCount) => {
    if (showReplyBox) {
        return replyCount > 0 ? INIT_COMMENTS_REPLIES : 0;
    }
};