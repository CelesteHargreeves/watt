import React, {
    useState
} from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
    TextBox
} from "@wattpad/web-ui-library";
import {
    postComment
} from "@wattpad/client-platform-comments";

import {
    useTrans,
    useUserVerification
} from "../../../hooks";
import {
    isReply
} from "../CommentsUtils";

const PostNewComment = ({
    resource,
    isSticky,
    placeholder,
    replyToUsername,
    onCommentPosted
}) => {
    const {
        trans
    } = useTrans();
    const {
        userNeedsVerification
    } = useUserVerification();
    const [isPosting, setIsPosting] = useState(false);
    const [hasError, setHasError] = useState(false);

    const placeholderText = placeholder || trans("Write a comment...");

    const handleCommentPosted = result => {
        result.isNewComment = true;
        setHasError(false);
        setIsPosting(false);
        onCommentPosted(result);
    };

    const handleOnSendClick = commentBody => {
        if (userNeedsVerification()) return;
        setIsPosting(true);
        postComment(resource, commentBody)
            .then(handleCommentPosted)
            .catch(() => {
                setHasError(true);
                setIsPosting(false);
            });
    };

    return ( <
        div className = {
            classNames("new-comment-field", {
                sticky: isSticky,
                replyTo: !!replyToUsername,
                reply: isReply(resource.namespace)
            })
        } >
        {
            replyToUsername && ( <
                div className = "reply-to-user" > {
                    trans("Replying to %s", replyToUsername)
                } <
                /div>
            )
        } <
        TextBox isLoading = {
            isPosting
        }
        placeholder = {
            placeholderText
        }
        actionSend = {
            handleOnSendClick
        }
        ariaLabel = {
            trans("Post new comment")
        }
        initialValue = {
            replyToUsername && `@${replyToUsername} `
        }
        errorMessage = {
            hasError ? trans("Comment failed to post") : undefined
        }
        /> <
        /div>
    );
};

PostNewComment.propTypes = {
    resource: PropTypes.object.isRequired,
    isSticky: PropTypes.bool,
    placeholder: PropTypes.string,
    replyToUsername: PropTypes.string,
    onCommentPosted: PropTypes.func.isRequired
};

export default PostNewComment;