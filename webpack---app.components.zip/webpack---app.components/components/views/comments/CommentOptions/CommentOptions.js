import React, {
    useRef
} from "react";
import PropTypes from "prop-types";

import {
    Icon
} from "../../../shared-components";
import {
    useTrans,
    useReportModal,
    useMuteUsers,
    useConfirmModal
} from "../../../hooks";
import UserSafetyLinks from "../../../shared-components/UserSafetyLinks";
import {
    ReportTypes
} from "../../report/ReportModal";

const CommentOptions = ({
    canMute,
    canDeleteData,
    commentAuthor,
    commentBody,
    deeplink,
    onDeleteComment
}) => {
    const {
        trans
    } = useTrans();
    const {
        openReportModal
    } = useReportModal();
    const {
        openMuteUserModal
    } = useMuteUsers();
    const {
        openConfirmModal
    } = useConfirmModal();

    let deleteButtonRef = useRef();

    const handleReportCommentClick = () => {
        openReportModal(
            ReportTypes.COMMENT,
            commentAuthor,
            commentBody,
            window ? .location.href,
            deeplink,
            "report-comment-modal"
        );
    };

    const handleDeleteClick = () => {
        const contentText = canDeleteData.isCommentAuthor ?
            trans("Are you sure you want to delete your comment?") :
            trans(
                "Are you sure you want to delete this comment from @%s?",
                commentAuthor
            );

        openConfirmModal({
            contentText,
            title: trans("Delete Comment"),
            onConfirmClick: onDeleteComment,
            openTriggerRef: deleteButtonRef
        });
    };

    return ( <
        div className = "comment-options" > {
            canMute && ( <
                button id = "mute-user"
                className = "option btn-no-background"
                onClick = {
                    () => openMuteUserModal(commentAuthor)
                } >
                <
                Icon name = "mute"
                size = "14"
                color = "wp-neutral-1" / >
                <
                span > {
                    trans("Mute %s", commentAuthor)
                } < /span> <
                /button>
            )
        } <
        button id = "report-comment"
        className = "option btn-no-background"
        onClick = {
            handleReportCommentClick
        } >
        <
        Icon name = "report" / > {
            trans("Report Comment")
        } <
        /button> {
            canDeleteData.canDelete && ( <
                button ref = {
                    deleteButtonRef
                }
                id = "delete-comment"
                className = "option btn-no-background"
                onClick = {
                    handleDeleteClick
                } >
                <
                Icon name = "trash"
                size = "14"
                color = "wp-neutral-1" / > {
                    trans("Delete Comment")
                } <
                /button>
            )
        } <
        a tabIndex = "0"
        href = {
            deeplink
        }
        id = "deeplink-comment"
        className = "option btn-no-background" >
        <
        Icon name = "link"
        size = "14"
        color = "wp-neutral-1" / > {
            trans("Link to Comment")
        } <
        /a> <
        UserSafetyLinks / >
        <
        /div>
    );
};

CommentOptions.propTypes = {
    canMute: PropTypes.bool,
    canDeleteData: PropTypes.shape({
        canDelete: PropTypes.bool,
        isCommentAuthor: PropTypes.bool
    }),
    commentAuthor: PropTypes.string,
    commentBody: PropTypes.string,
    deeplink: PropTypes.string,
    onDeleteComment: PropTypes.func
};

export default CommentOptions;