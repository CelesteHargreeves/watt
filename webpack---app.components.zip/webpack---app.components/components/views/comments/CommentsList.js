import React, {
    useCallback,
    useEffect,
    useState
} from "react";
import PropTypes from "prop-types";
import {
    useMuteUsers,
    useInfiniteScroll,
    useTrans
} from "../../hooks";
import {
    Button,
    ButtonVariant
} from "@wattpad/web-ui-library";
import {
    fetchComments,
    deleteComment
} from "@wattpad/client-platform-comments";

import {
    CommentsLocation
} from "./CommentsConstants";
import {
    isReply,
    isStoryPart
} from "./CommentsUtils";
import CommentContainer from "./CommentContainer";
import PostNewComment from "./PostNewComment/PostNewComment";
import {
    ConnectImage
} from "../../shared-components";
import CommentsEmptyStage from "./EmptyStage/CommentsEmptyStage";

const CommentsList = ({
    location,
    parentLocation,
    partId,
    paragraphId,
    commentId,
    storyAuthor,
    initialLimit,
    scrollableRef,
    addNewCommentRef,
    sentimentEventData,
    onUpdateCount
}) => {
    const {
        trans
    } = useTrans();

    const [comments, setComments] = useState([]);
    const [hasMore, setHasMore] = useState(false);
    const [hasError, setHasError] = useState(false);
    const [isLoading, setIsLoading] = useState(initialLimit !== 0);
    const [afterComment, setAfterComment] = useState(undefined);

    const isEmptyComments = comments.length === 0;

    const mainResource = {
        namespace: location,
        partId: partId ? .toString(),
        paragraphId: paragraphId,
        commentId: commentId
    };

    const getNextComments = limit => {
        setIsLoading(true);
        fetchComments(mainResource, afterComment, limit)
            .then(data => {
                setComments([...comments, ...data.comments]);
                setHasMore(data.hasMore);
                setAfterComment(data.after);
                setHasError(false);
                setIsLoading(false);
            })
            .catch(() => {
                setHasError(true);
                setIsLoading(false);
            });
    };

    const handleDeleteComment = (commentId, replyCount) => {
        deleteComment(commentId)
            .then(() => {
                onUpdateCount ? .(-(replyCount + 1));
                setComments(comments.filter(c => c.id !== commentId));
            })
            .catch(() => {
                wattpad.utils.showToast(
                    trans("Sorry, something went wrong. Please try again."), {
                        type: "dismissable"
                    }
                );
            });
    };

    const handleOnCommentPosted = newComment => {
        onUpdateCount ? .(1);
        setComments(currentComments => [newComment, ...currentComments]);
    };

    const initializeList = () => {
        /* Only load comments when the initial limit undefined or higher than 0 */
        if (initialLimit !== 0) {
            getNextComments(initialLimit);
        }

        /* This ref allows to add new comments in the List from outside */
        if (addNewCommentRef) {
            addNewCommentRef.current = handleOnCommentPosted;
        }
    };

    const filterOutMutedUser = username => {
        setComments(comments.filter(c => c.author.name !== username));
    };

    useEffect(initializeList, []);
    useMuteUsers(filterOutMutedUser);

    useInfiniteScroll({
        hasMore,
        scrollableRef,
        scrollOffset: 100,
        isDisabled: hasError || isLoading,
        onLoadMore: useCallback(getNextComments, [comments, hasMore, afterComment])
    });

    const showMoreOrLoading = showMoreContent => {
        if (isLoading || (hasError && !isEmptyComments)) {
            return ( <
                div className = "loader-animation-wrapper" >
                <
                ConnectImage name = "icons/loader-light.svg"
                id = "loader-light" / >
                <
                /div>
            );
        } else if (hasMore && !scrollableRef) {
            return showMoreContent;
        }
    };

    const showCommentsEmptyStage = () => {
        if (!isReply(location) && !isLoading && isEmptyComments) {
            return ( <
                CommentsEmptyStage isError = {
                    hasError
                }
                onRetryFetch = {
                    getNextComments
                }
                />
            );
        }
    };

    const handleShowMoreComments = () => {
        getNextComments();
    };

    const getComments = () =>
        isReply(location) ? [...comments].reverse() : comments;

    return ( <
        div className = "comments-list" > {!isReply(location) && ( <
                PostNewComment resource = {
                    mainResource
                }
                isSticky = {!isStoryPart(location)
                }
                onCommentPosted = {
                    handleOnCommentPosted
                }
                />
            )
        } {
            isReply(location) &&
                showMoreOrLoading( <
                    span className = "show-more-replies-wrapper" >
                    <
                    hr className = "show-more-replies-hr" / >
                    <
                    button className = "show-more-replies-btn"
                    onClick = {
                        handleShowMoreComments
                    } >
                    {
                        trans("View more replies")
                    } <
                    /button> <
                    hr className = "show-more-replies-hr" / >
                    <
                    /span>
                )
        } {
            getComments().map(comment => ( <
                CommentContainer key = {
                    `${location}-${comment.id}`
                }
                comment = {
                    comment
                }
                mainLocation = {
                    parentLocation || location
                }
                storyAuthor = {
                    storyAuthor
                }
                onDeleteComment = {
                    handleDeleteComment
                }
                onReplyPosted = {
                    handleOnCommentPosted
                }
                sentimentEventData = {
                    sentimentEventData
                }
                onUpdateCount = {
                    onUpdateCount
                }
                />
            ))
        } {
            !isReply(location) &&
                showMoreOrLoading( <
                    div className = "show-more-btn" >
                    <
                    Button fullWidth variant = {
                        ButtonVariant.SECONDARY
                    }
                    onClick = {
                        handleShowMoreComments
                    } >
                    {
                        trans("Show more")
                    } <
                    /Button> <
                    /div>
                )
        } {
            showCommentsEmptyStage()
        } <
        /div>
    );
};

CommentsList.propTypes = {
    location: PropTypes.oneOf(Object.values(CommentsLocation)).isRequired,
    partId: PropTypes.number,
    commentId: PropTypes.string,
    paragraphId: PropTypes.string,
    storyAuthor: PropTypes.string,
    parentLocation: PropTypes.oneOf(Object.values(CommentsLocation)),
    sentimentEventData: PropTypes.object,
    initialLimit: PropTypes.number,
    scrollableRef: PropTypes.object,
    addNewCommentRef: PropTypes.object,
    onUpdateCount: PropTypes.func
};

export default CommentsList;