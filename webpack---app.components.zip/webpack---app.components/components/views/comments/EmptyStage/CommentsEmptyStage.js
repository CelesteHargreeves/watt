import React from "react";
import PropTypes from "prop-types";
import {
    Button
} from "@wattpad/web-ui-library";

import {
    ConnectImage
} from "../../../shared-components";
import {
    useTrans
} from "../../../hooks";

const CommentsEmptyStage = ({
    isError,
    onRetryFetch
}) => {
    const {
        trans
    } = useTrans();

    const ConnectImageProps = {
        id: isError ? "failed-comment-fetch" : "no-comments-graphics",
        name: isError ? "comments/failed-fetch.svg" : "comments/no-comments.svg",
        title: ""
    };

    return ( <
        div className = "comments-empty-stage" >
        <
        ConnectImage { ...ConnectImageProps
        }
        /> {
            isError ? ( <
                >
                <
                p className = "message" > {
                    trans("There was an issue retrieving comments.")
                } <
                /p> <
                Button onClick = {
                    onRetryFetch
                } > {
                    trans("Retry")
                } < /Button> <
                />
            ) : ( <
                p className = "message" > {
                    `${trans("Be the first to comment")} 💬`
                } < /p>
            )
        } <
        /div>
    );
};

CommentsEmptyStage.propTypes = {
    isError: PropTypes.bool,
    onRetryFetch: PropTypes.func
};

export default CommentsEmptyStage;