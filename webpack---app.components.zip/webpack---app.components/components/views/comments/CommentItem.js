import React, {
    useEffect,
    useState
} from "react";
import {
    sprintf
} from "sprintf-js";
import PropTypes from "prop-types";
import {
    CommentCard,
    BadgeVariant
} from "@wattpad/web-ui-library";
import {
    postSentiment,
    removeSentiment,
    SentimentTypes,
    SentimentNamespaces
} from "@wattpad/client-platform-comments";

import {
    fromNow,
    linkify,
    count
} from "../../helpers";
import {
    useTrans,
    useGetUser
} from "../../hooks";
import AuthForm from "../authentication/AuthForm";
import {
    toggleModal
} from "../../shared-components/modals/actions";
import {
    useDispatch
} from "react-redux";

const badgeToBadgeVariant = {
    staff: BadgeVariant ? .STAFF,
    ambassador: BadgeVariant ? .AMBASSADORS,
    verified: BadgeVariant ? .VERIFIED
};

function CommentItem({
    author,
    createDate,
    isOffensive,
    id,
    isReply,
    numReplies,
    body,
    renderId,
    commentLocation,
    sentimentDetails,
    isStoryWriter = false,
    backboneModel,
    pushSentimentEvent
}) {
    const {
        trans,
        ngettext
    } = useTrans();
    const dispatch = useDispatch();
    const user = useGetUser();

    const [replyCount, setReplyCount] = useState(numReplies);
    const [isLiked, setIsLiked] = useState(!!sentimentDetails ? .[SentimentTypes.LIKE] ? .interaction);
    const [likeCount, setLikeCount] = useState(
        sentimentDetails ? .[SentimentTypes.LIKE] ? .count || 0
    );

    const writerPillText = trans("Writer");
    const writerPillTextColor = "#FFF";
    const writerPillColour = "#a93e19"; // @ds-base-1-60

    const sentimentResource = {
        namespace: SentimentNamespaces.COMMENTS,
        resourceId: id
    };

    const updateReplyCount = count => () => setReplyCount(c => c + count);

    const initializeListeners = () => {
        if (!isReply) {
            backboneModel.on("replyCount:add", updateReplyCount(1));
            backboneModel.on("replyCount:sub", updateReplyCount(-1));
        }
    };

    useEffect(initializeListeners, []);

    const handleShowSignupPrompt = () => {
        const modalProps = {
            nextUrl: window.location.href
        };
        const component = () => < AuthForm { ...modalProps
        }
        />;
        component.displayName = "AuthForm";

        dispatch(
            toggleModal({
                className: "signup-modal comments-signup-modal",
                disableScroll: true,
                useGlobalModalContainer: true,
                component
            })
        );
    };

    const handleReply = event => {
        app ? .trigger ? .(
            "app:comment:view-replies",
            event,
            id,
            renderId,
            commentLocation,
            isReply
        );
    };

    const handleSentimentAction = () => {
        if (!user.username) {
            return handleShowSignupPrompt();
        }
        if (!user.verified_email) {
            return wattpad.utils.showPleaseVerifyModal();
        }

        if (isLiked) {
            setLikeCount(likeCount => likeCount - 1);
            setIsLiked(false);
            removeSentiment(sentimentResource, SentimentTypes.LIKE)
                .then(() => {
                    pushSentimentEvent("remove");
                })
                .catch(() => {
                    setIsLiked(true);
                    setLikeCount(likeCount => likeCount + 1);
                });
        } else {
            setLikeCount(likeCount => likeCount + 1);
            setIsLiked(true);
            postSentiment(sentimentResource, SentimentTypes.LIKE)
                .then(() => {
                    pushSentimentEvent("add");
                })
                .catch(() => {
                    setIsLiked(false);
                    setLikeCount(likeCount => likeCount - 1);
                });
        }
    };

    const commentPills = isStoryWriter ?
        [{
            backgroundColor: writerPillColour,
            color: writerPillTextColor,
            text: writerPillText
        }] :
        [];

    const toBadgesVariant = badges =>
        badges ? badges.map(badge => badgeToBadgeVariant[badge]) : [];

    const actionLike = {
        ariaLabel: isLiked ?
            trans("Unlike this comment") :
            trans("Like this comment"),
        onClick: handleSentimentAction,
        displayText: likeCount > 0 && count(likeCount)
    };

    const actionReply = {
        ariaLabel: "Reply to comment",
        onClick: handleReply,
        displayText: trans("Reply")
    };

    const actionViewMoreReplies = replyCount > 0 && {
        onClick: handleReply,
        ariaLabel: "View replies",
        displayText: sprintf(
            ngettext("View %s Reply", "View %s Replies", replyCount),
            replyCount
        )
    };

    const offensiveText = isOffensive && trans("This comment may be offensive.");

    return ( <
        >
        <
        CommentCard badges = {
            toBadgesVariant(author.badges)
        }
        content = {
            linkify(body)
        }
        commentAuthorAvatar = {
            author.avatar
        }
        commentAuthorName = {
            author.name
        }
        postedDate = {
            fromNow(createDate, {
                fuzzyTime: true
            })
        }
        isStoryAuthor = {
            isStoryWriter
        }
        pills = {
            commentPills
        }
        isLiked = {
            isLiked
        }
        actionLike = {
            actionLike
        }
        actionReply = {
            actionReply
        }
        readMoreText = {
            trans("Read more")
        }
        actionViewMoreReplies = {
            actionViewMoreReplies
        }
        offensiveText = {
            offensiveText
        }
        /> {
            !isReply && ( <
                div id = {
                    `replies-${renderId}`
                }
                className = "replies-list collapse"
                data - id = {
                    id
                }
                data - message - owner = {
                    author.name
                }
                />
            )
        } <
        />
    );
}

CommentItem.propTypes = {
    author: PropTypes.shape({
        name: PropTypes.string,
        avatar: PropTypes.string,
        badges: PropTypes.array
    }),
    createDate: PropTypes.string,
    isOffensive: PropTypes.bool,
    id: PropTypes.string,
    isReply: PropTypes.bool,
    numReplies: PropTypes.number,
    body: PropTypes.string,
    isStoryWriter: PropTypes.bool,
    canDelete: PropTypes.bool,
    showMuteOption: PropTypes.bool,
    onMuteHelper: PropTypes.func,
    deeplink: PropTypes.string,
    reportModalId: PropTypes.object,
    renderId: PropTypes.string,
    commentLocation: PropTypes.string,
    sentimentDetails: PropTypes.object,
    backboneModel: PropTypes.object,
    pushSentimentEvent: PropTypes.func.isRequired
};

export {
    CommentItem
};