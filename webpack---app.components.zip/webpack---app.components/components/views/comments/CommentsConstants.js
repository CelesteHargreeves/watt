import {
    BadgeVariant
} from "@wattpad/web-ui-library";
import {
    CommentsNamespaces
} from "@wattpad/client-platform-comments";

export const INIT_COMMENTS_REPLIES = 2;
export const INIT_COMMENTS_STORY_PART = 2;

export const CommentsLocation = {
    STORY_PART: CommentsNamespaces.PARTS,
    REPLIES: CommentsNamespaces.COMMENTS,
    PARAGRAPH: CommentsNamespaces.PARAGRAPHS
};

export const BadgeToBadgeVariant = {
    staff: BadgeVariant.STAFF,
    ambassador: BadgeVariant.AMBASSADORS,
    verified: BadgeVariant.VERIFIED
};

export const CommentItemDropdownProps = {
    CLASS: "comment-item-options-dropdown",
    PROPS: {
        placement: "bottom",
        showArrow: "true",
        modifiers: [{
                name: "offset",
                options: {
                    offset: [-50, 0]
                }
            },
            {
                name: "preventOverflow",
                options: {
                    padding: {
                        left: 16,
                        right: 16
                    }
                }
            }
        ]
    }
};

export const ScrollSmoothCenter = {
    block: "center",
    behavior: "smooth"
};