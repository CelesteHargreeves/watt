import React, {
    useState,
    useRef,
    useEffect
} from "react";
import PropTypes from "prop-types";
import {
    sprintf
} from "sprintf-js";
import {
    CommentCard
} from "@wattpad/web-ui-library";

import {
    useTrans,
    usePopover,
    useGetUser,
    useUserVerification
} from "../../hooks";
import CommentOptions from "./CommentOptions/CommentOptions";
import {
    count,
    linkify
} from "../../helpers";
import {
    addLike,
    getIsLiked,
    getLikesCount,
    getPills,
    isStoryPart,
    removeLike,
    toBadgesVariant,
    toPostedDate,
    canDeleteComment,
    getReplyLimit
} from "./CommentsUtils";
import CommentsList from "./CommentsList";
import {
    CommentItemDropdownProps,
    CommentsLocation,
    ScrollSmoothCenter
} from "./CommentsConstants";
import PostNewComment from "./PostNewComment/PostNewComment";

const CommentContainer = ({
    comment,
    mainLocation,
    storyAuthor,
    onReplyPosted,
    onDeleteComment,
    sentimentEventData,
    onUpdateCount
}) => {
    const {
        author,
        isReply,
        numReplies,
        isOffensive,
        id: commentId,
        sentimentDetails: sentiments
    } = comment;

    const user = useGetUser();
    const {
        trans,
        ngettext
    } = useTrans();
    const {
        handleOpenPopover,
        handleClosePopover
    } = usePopover();
    const {
        userNeedsVerification
    } = useUserVerification();

    const triggerRef = useRef();
    const autofocusRef = useRef();
    const addNewCommentRef = useRef();

    const [isLiked, setIsLiked] = useState(getIsLiked(sentiments));
    const [likesCount, setLikesCount] = useState(getLikesCount(sentiments));
    const [replyCount, setReplyCount] = useState(numReplies);
    const [showReplies, setShowReplies] = useState(false);
    const [showCommentTextBox, setShowCommentTextBox] = useState(false);

    const isStoryAuthor = storyAuthor === author.name;
    const canMute = user.username && user.username !== author.name;
    const offensiveText = isOffensive && trans("This comment may be offensive.");

    const replyResource = {
        commentId,
        namespace: CommentsLocation.REPLIES
    };

    const pushSentimentEvent = action => {
        const eventData = { ...sentimentEventData,
            commentId: commentId
        };

        window.te.push("event", "sentiment", null, null, action, eventData);
    };

    const triggerAutoFocus = () => {
        const shouldFocus = comment.isNewComment && !isStoryPart(mainLocation);

        if (shouldFocus && autofocusRef.current) {
            autofocusRef.current.scrollIntoView(ScrollSmoothCenter);
        }
    };

    useEffect(triggerAutoFocus, []);

    const updateIsLiked = liked => {
        if (liked) {
            setIsLiked(true);
            setLikesCount(count => count + 1);
        } else {
            setIsLiked(false);
            setLikesCount(count => count - 1);
        }
    };

    const handleLikeClick = () => {
        if (userNeedsVerification()) return;

        if (isLiked) {
            updateIsLiked(false);
            removeLike(commentId)
                .then(() => sentimentEventData && pushSentimentEvent("remove"))
                .catch(() => updateIsLiked(true));
        } else {
            updateIsLiked(true);
            addLike(commentId)
                .then(() => sentimentEventData && pushSentimentEvent("add"))
                .catch(() => updateIsLiked(false));
        }
    };

    const handleUpdateCount = difference => {
        onUpdateCount ? .(difference);
        setReplyCount(count => count + difference);
    };

    const handleDeleteComment = () => {
        handleClosePopover(triggerRef);
        onDeleteComment(commentId, replyCount);
    };

    const handleOpenCommentItemOptions = event => {
        event.preventDefault();

        const component = () => {
            return ( <
                CommentOptions canMute = {
                    canMute
                }
                commentBody = {
                    comment.body
                }
                deeplink = {
                    comment.deeplink
                }
                commentAuthor = {
                    author.name
                }
                canDeleteData = {
                    canDeleteComment(user, author, storyAuthor)
                }
                onDeleteComment = {
                    handleDeleteComment
                }
                />
            );
        };

        handleOpenPopover(
            component,
            triggerRef,
            `${CommentItemDropdownProps.CLASS} ${
        isStoryPart(mainLocation) ? "sp" : "pa"
      }`,
            CommentItemDropdownProps.PROPS
        );
    };

    const handleOnCommentPosted = newComment => {
        if (isReply && onReplyPosted) {
            // When posting a reply of a reply, we let the parent list know that a new comment was added
            onReplyPosted(newComment);
        } else {
            // When posting a reply, we should add a new comment in the replies list
            addNewCommentRef.current(newComment);
        }
        setShowCommentTextBox(false);
    };

    const actionLike = {
        ariaLabel: isLiked ?
            trans("Unlike this comment") :
            trans("Like this comment"),
        onClick: handleLikeClick,
        displayText: likesCount > 0 && count(likesCount)
    };

    const actionDropdown = {
        ariaLabel: trans("More options"),
        outsideRef: triggerRef,
        onClick: handleOpenCommentItemOptions
    };

    const actionReply = {
        onClick: () => {
            setShowReplies(true);
            setShowCommentTextBox(true);
        },
        ariaLabel: "Reply to comment",
        displayText: trans("Reply")
    };

    const actionViewMoreReplies = replyCount > 0 &&
        !showReplies && {
            onClick: () => setShowReplies(true),
            ariaLabel: "View replies",
            displayText: sprintf(
                ngettext("View %s Reply", "View %s Replies", replyCount),
                replyCount
            )
        };

    return ( <
        div className = "comment-card-container" > {!isReply && < hr className = "comment-divider" / >
        } <
        div ref = {
            autofocusRef
        } >
        <
        CommentCard isLiked = {
            isLiked
        }
        isReplyComment = {
            isReply
        }
        offensiveText = {
            offensiveText
        }
        content = {
            linkify(comment.body)
        }
        commentAuthorName = {
            author.name
        }
        commentAuthorAvatar = {
            author.avatar
        }
        isNewComment = {
            comment.isNewComment
        }
        badges = {
            toBadgesVariant(author.badges)
        }
        isStoryAuthor = {
            isStoryAuthor
        }
        pills = {
            getPills(isStoryAuthor, trans)
        }
        readMoreText = {
            trans("Read more")
        }
        postedDate = {
            toPostedDate(comment.createDate)
        }
        actionLike = {
            actionLike
        }
        actionReply = {
            actionReply
        }
        actionDropdown = {
            actionDropdown
        }
        actionViewMoreReplies = {
            actionViewMoreReplies
        }
        /> <
        /div> {
            showCommentTextBox && ( <
                PostNewComment resource = {
                    replyResource
                }
                onCommentPosted = {
                    handleOnCommentPosted
                }
                replyToUsername = {
                    isReply ? author.name : undefined
                }
                placeholder = {
                    trans("Write a reply...")
                }
                />
            )
        } {
            showReplies && ( <
                CommentsList location = {
                    CommentsLocation.REPLIES
                }
                parentLocation = {
                    mainLocation
                }
                commentId = {
                    commentId
                }
                storyAuthor = {
                    storyAuthor
                }
                sentimentEventData = {
                    sentimentEventData
                }
                addNewCommentRef = {
                    addNewCommentRef
                }
                onUpdateCount = {
                    handleUpdateCount
                }
                initialLimit = {
                    getReplyLimit(showCommentTextBox, replyCount)
                }
                />
            )
        } <
        /div>
    );
};

CommentContainer.propTypes = {
    comment: PropTypes.object.isRequired,
    mainLocation: PropTypes.oneOf(Object.values(CommentsLocation)),
    storyAuthor: PropTypes.string,
    sentimentEventData: PropTypes.object,
    onReplyPosted: PropTypes.func,
    onDeleteComment: PropTypes.func.isRequired,
    onUpdateCount: PropTypes.func
};

export default CommentContainer;