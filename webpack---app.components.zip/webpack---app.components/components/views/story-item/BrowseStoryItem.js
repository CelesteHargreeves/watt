import PropTypes from "prop-types";
import React, {
    Component
} from "react";

import {
    simpleShorten,
    count,
    formatStoryUrl,
    sanitizeHTML,
    resizeCover,
    injectTrans,
    getCoverSize
} from "../../helpers";
import {
    Icon
} from "../../shared-components";
import TagMeta from "../tags/TagMeta";

class BrowseStoryItem extends Component {
    render() {
        const {
            title,
            user,
            url,
            readCount,
            numParts,
            voteCount,
            cover,
            description,
            mature,
            completed,
            tags,
            rank,
            id,
            app,
            trans
        } = this.props;

        const tagMeta = {
            tags,
            storyId: id,
            numShown: app.deviceType === "desktop" ? 3 : 2
        };

        const titleLink = simpleShorten(title, 35, false);
        const username = user.fullname || user.name;
        const shortUsername = simpleShorten(username, 30, false);
        const userNode = trans("by %s", shortUsername);
        const storyUrl = formatStoryUrl(url);
        const userLink = "/user/" + user.name;

        const readCountText = count(readCount).toString();
        const numPartsText = count(numParts).toString();
        const voteCountText = count(voteCount).toString();

        const mobileCoverSize = 92;
        const desktopCoverSize = 142;

        let coverImageUrl,
            descriptionText = sanitizeHTML(description);

        if (app.deviceType === "desktop") {
            coverImageUrl = resizeCover(
                cover,
                getCoverSize(desktopCoverSize),
                app.devicePixelRatio,
                app.matchMedia,
                app.msMatchMedia
            );
            descriptionText = simpleShorten(descriptionText, 170, false);
        } else {
            coverImageUrl = resizeCover(
                cover,
                getCoverSize(mobileCoverSize),
                app.devicePixelRatio,
                app.matchMedia,
                app.msMatchMedia
            );
            descriptionText = simpleShorten(descriptionText, 170, false);
        }
        const coverAlt = trans("%1$s by %2$s", title, user.name);

        // The description is sanitized on the backend
        var innerDescription = {
            __html: descriptionText
        };
        const descriptionNode = ( <
            div className = "description"
            dangerouslySetInnerHTML = {
                innerDescription
            }
            />
        );
        const coverImage = < img src = {
            coverImageUrl
        }
        alt = {
            coverAlt
        }
        />;

        let storyRankNode;

        // rank is for tags, a formulated data attribute added in the view
        // If parent view requests the tag via showStoryRank, then rank will be the index of the story in the collection
        if (rank) {
            storyRankNode = ( <
                div className = "story-rank" >
                <
                span > #{
                    rank
                } < /span> <
                /div>
            );
        }

        return ( <
            div className = "item" >
            <
            a className = "on-story-preview cover cover-lg"
            data - story - id = {
                id
            }
            href = {
                storyUrl
            } >
            <
            div className = "fixed-ratio fixed-ratio-cover" > {
                coverImage
            } {
                storyRankNode
            } <
            /div> <
            /a> <
            div className = "content" >
            <
            a className = {
                "title meta on-story-preview"
            }
            data - story - id = {
                id
            }
            href = {
                storyUrl
            } >
            {
                titleLink
            } <
            /a> <
            a className = "username meta on-navigate"
            href = {
                userLink
            } > {
                userNode
            } <
            /a> <
            div className = "meta social-meta" >
            <
            span className = "read-count" >
            <
            Icon iconName = "fa-view"
            height = "12"
            color = "wp-neutral-2" / > {
                readCountText
            } <
            /span> <
            span className = "vote-count" >
            <
            Icon iconName = "fa-vote"
            height = "12"
            color = "wp-neutral-2" / > {
                voteCountText
            } <
            /span> <
            span className = "part-count" >
            <
            Icon iconName = "fa-list"
            height = "12"
            color = "wp-neutral-2" / > {
                numPartsText
            } <
            /span> <
            /div> {
                descriptionNode
            } <
            div className = "bottom-content clearfix" >
            <
            div className = "story-status" > {
                completed ? ( <
                    span className = "label label-info" > {
                        trans("Completed")
                    } < /span>
                ) : null
            } {
                mature ? ( <
                    span className = "label label-danger" > {
                        trans("Mature")
                    } < /span>
                ) : null
            } <
            /div> <
            TagMeta tagMeta = {
                tagMeta
            }
            /> <
            /div> <
            /div> <
            /div>
        );
    }
}

BrowseStoryItem.propTypes = {
    completed: PropTypes.bool,
    cover: PropTypes.string,
    description: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    mature: PropTypes.bool,
    numParts: PropTypes.number.isRequired,
    rank: PropTypes.number,
    readCount: PropTypes.number.isRequired,
    trans: PropTypes.func.isRequired,
    tags: PropTypes.arrayOf(PropTypes.string).isRequired, // validation for this object will happen at the TagMeta component level
    title: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    user: PropTypes.shape({
        avatar: PropTypes.string,
        fullname: PropTypes.string,
        name: PropTypes.string
    }),
    voteCount: PropTypes.number.isRequired,
    app: PropTypes.object
};

export default injectTrans(BrowseStoryItem);