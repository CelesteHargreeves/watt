import React from "react";
import PropTypes from "prop-types";
import {
    useTrans
} from "../../hooks";
import {
    CatalogHeader
} from "./CatalogHeader";
import {
    PaidStoriesCatalog
} from "./catalogs/PaidStoriesCatalog";

function Catalog({
    catalog,
    isMobile
}) {
    const {
        trans
    } = useTrans();
    return ( <
        div className = "catalog-container" >
        <
        CatalogHeader title = {
            trans("Paid Stories")
        }
        isMobile = {
            isMobile
        }
        /> {
            catalog === "paidstories" && < PaidStoriesCatalog / >
        } <
        /div>
    );
}

Catalog.propTypes = {
    catalog: PropTypes.string.isRequired,
    isMobile: PropTypes.bool.isRequired
};

export {
    Catalog
};