export const WATTPAD_USER_COUNT = 90; //Million is assumed

export const HOW_WATTPAD_WORKS_STEPS = trans => [{
        number: 1,
        title: trans("Create"),
        description: trans(
            "Share your unique voice and original story on Wattpad. Find the writing resources you need to craft a story only you can tell."
        ),
        stat: {
            count: trans("50+"),
            title: trans("Writing Resources")
        }
    },
    {
        number: 2,
        title: trans("Build"),
        description: trans(
            "Establish a global fan base as your story gains readership and momentum. Connect with other like-minded writers through storytelling."
        ),
        stat: {
            count: trans("%s <span>MILLION</span>", WATTPAD_USER_COUNT),
            title: trans("Readers")
        }
    },
    {
        number: 3,
        title: trans("Amplify"),
        description: trans(
            "Gain Wattpad Star status and get your story published or adapted into film or television with Wattpad Books and Wattpad Studios!"
        ),
        stat: {
            count: trans("1000+"),
            title: trans("Story deals")
        }
    }
];

const GET_DISCOVERED_LINKS = trans => [{
        name: trans("Writing Contests"),
        description: trans(
            "Enter writing contests to get published, win awards, and partner with global brands."
        ),
        img: "/landing/writing-contests.png",
        url: "https://www.wattpad.com/go/writing-contests/",
        id: "contests"
    },
    {
        name: trans("The Wattys"),
        description: trans(
            "Wattpad’s annual awards program committed to celebrating the best stories around the world."
        ),
        img: "/landing/wattys_avatar.png",
        url: "https://wattys.wattpad.com",
        id: "wattys"
    },
    {
        name: trans("Wattpad Picks"),
        description: trans("Get featured on our hand-picked reading list."),
        img: "/landing/wp-picks.png",
        url: "https://www.wattpad.com/featured/551324301",
        id: "picks"
    }
];

export const LINKS_SECTIONS = trans => [{
    title: trans("Get Discovered"),
    id: "GetDiscovered",
    links: GET_DISCOVERED_LINKS(trans)
}];

export const CAROUSEL_SLIDES = [{
        quoteText: "Working with Wattpad Studios is like a dream. Not only do they care about your success, but also staying true to your vision.",
        author: "KARA BARBIERI (@PANDEAN)",
        about: "Kara Barbieri is a twenty-two year old author with a love for the weird and mystic. Her debut novel, WHITE STAG, will be published by Wednesday Books/Macmillan in January 2019.",
        cover: "/landing/white-stag.png",
        url: "/story/51067091-white-stag-permafrost-1",
        id: "white_stag"
    },
    {
        quoteText: "When I joined Wattpad, I gained a second family who were as passionate about reading and writing as I am.",
        author: "ALI NOVAK (@FALLZSWIMMER)",
        about: "Ali Novak is a Wisconsin native and a graduate of the University of Wisconsin-Madison's creative writing program. She started writing her debut novel My Life with the Walter Boys when she was only fifteen. Since then, her work has received more than 150 million hits online and My Life with the Walter Boys has been optioned for television by Komixx Entertainment and Sony Pictures Television.",
        cover: "/landing/walter-boys.png",
        url: "/story/80479-my-life-with-the-walter-boys-wattpad-version",
        id: "walter_boys"
    },
    {
        quoteText: "Being a Wattpad Star is the foundation for everything I do as a writer, from the behind the scenes wrangling to the big, game-changing projects.",
        author: "BEN SOBIECK (@BENSOBIECK)",
        about: "Benjamin Sobieck is a Wattpad Star and editor of “The Writer’s Guide to Wattpad,” published in August 2018 by Writer’s Digest Books and featuring contributions by 23 Wattpad Stars, ambassadors, and staff. His stories on Wattpad, such as “When the Black-Eyed Children Knock,” have drawn more than 1.5 million reads.",
        cover: "/landing/black-eye.png",
        url: "/story/59324321-black-eye-confessions-of-a-fake-psychic-detective",
        id: "black_eye"
    },
    {
        quoteText: "Having been active on Wattpad for several  years, I knew it would be the perfect platform for a thriller with lots of cliffhangers for readers to discuss. Teen horror is my passion, so I can’t wait to be able to share Light as a Feather with other horror aficionados on Hulu.",
        author: "ZOE AARSEN (@ZAARSENIST)",
        about: "Zoe Aarsen is a graphic designer and copywriter. Her first paranormal YA novel, Light as a Feather, Stiff as a Board, is being published by Simon & Schuster and turned into a television series on Hulu.",
        cover: "/landing/feather.png",
        url: "/story/5949534-light-as-a-feather-stiff-as-a-board",
        id: "light_as_a_feather"
    },
    {
        quoteText: "The Wattpad Stars Program gave me opportunities I never thought possible. It connected me to a world that I had only imagined. I don’t know how else to say it. It changed my life!",
        author: "ISABELLE RONIN (@ISABELLERONIN)",
        about: "Chasing Red was one of 2016’s most-read stories on Wattpad -- and that was just the beginning for this Winnipeg-Manitoba-based writer. In a single year, her explosive hit has racked up over 127 million reads on Wattpad. Newly edited and expanded, the book was split into two and hit bookstore shelves in 2017.",
        cover: "/landing/chasing-red.png",
        url: "/story/18024139-chasing-red",
        id: "chasing_red"
    }
];