export const linkClicked = (linkId, url) => {
    wattpad.utils.pushEvent({
        category: "new_landing",
        action: `click:${linkId}`
    });
    if (url) {
        window.open(url, "_blank");
    }
};