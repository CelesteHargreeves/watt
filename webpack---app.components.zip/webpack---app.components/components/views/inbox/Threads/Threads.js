import {
    connect
} from "react-redux";
import PropTypes from "prop-types";
import React, {
    useEffect
} from "react";

import {
    loadThreads
} from "./reducers";
import {
    NewMessage
} from "../NewMessage";
import {
    toggleModal
} from "../../../shared-components/modals/actions";
import {
    useTrans,
    useSetDocumentTitle
} from "../../../hooks";
import {
    WPModal
} from "../../../shared-components";
import LazyLoader from "../LazyLoader";
import Thread from "./Thread";
import ThreadFilter from "./ThreadFilter";

import {
    Toast
} from "../../../shared-components/toasts/Toast";
import PleaseVerify from "../../verification/PleaseVerify";

const useMountEffect = func => useEffect(func, []);

const ThreadsUI = ({
    loadThreads,
    isLoading,
    isLoadingMore,
    isEmailVerified,
    threads,
    username,
    total,
    offset,
    filter,
    toggleModal
}) => {
    const {
        trans
    } = useTrans();

    useSetDocumentTitle(`${trans("Inbox")} - Wattpad`);
    useMountEffect(() => {
        loadThreads({});
    });

    const onLoadMore = offset => {
        loadThreads({
            offset,
            filter
        });
    };

    const onClickNewMessage = () => {
        if (!isEmailVerified) {
            const component = () => ( <
                PleaseVerify email = {
                    wattpad.utils.currentUser().get("email")
                }
                userId = {
                    wattpad.utils.currentUser().get("id")
                }
                hideModal = {
                    toggleModal
                }
                />
            );
            component.displayName = "PleaseVerify";
            toggleModal({
                className: "please-verify-modal",
                hideClose: true,
                component
            });
        } else {
            const component = () => < NewMessage toggleModal = {
                toggleModal
            }
            />;
            component.displayName = "NewMessage";

            toggleModal({
                className: "new-message-modal",
                component
            });
        }
    };
    return ( <
        div id = "inbox" >
        <
        div className = "threads-container" >
        <
        div className = "threads-header" >
        <
        div className = "flex-part" >
        <
        h2 > {
            trans("My Messages")
        } < /h2> <
        /div> <
        ThreadFilter filter = {
            filter
        }
        loadThreads = {
            loadThreads
        }
        /> <
        button className = "new-msg-btn"
        onClick = {
            onClickNewMessage
        } >
        <
        span > {
            trans("+ New Message")
        } < /span> <
        /button> <
        WPModal / >
        <
        /div> <
        div className = "threads-list" > {
            threads.length === 0 && !isLoading ? ( <
                div className = "thread-row empty-row" > {
                    trans("You have no messages.")
                } <
                /div>
            ) : (
                threads.map(thread => ( <
                    Thread key = {
                        thread.user.name
                    }
                    thread = {
                        thread
                    }
                    username = {
                        username
                    }
                    />
                ))
            )
        } <
        /div> <
        LazyLoader direction = "down"
        threshold = {
            0
        }
        isLoading = {
            isLoadingMore
        }
        isDisabled = {
            isLoadingMore
        }
        total = {
            total
        }
        offset = {
            offset
        }
        onLoad = {
            onLoadMore
        }
        /> <
        /div> <
        Toast / >
        <
        /div>
    );
};

ThreadsUI.propTypes = {
    isLoading: PropTypes.bool.isRequired,
    isLoadingMore: PropTypes.bool.isRequired,
    isEmailVerified: PropTypes.bool.isRequired,
    threads: PropTypes.array.isRequired,
    username: PropTypes.string.isRequired,
    loadThreads: PropTypes.func.isRequired,
    total: PropTypes.number.isRequired,
    offset: PropTypes.number.isRequired,
    filter: PropTypes.string.isRequired,
    toggleModal: PropTypes.func
};
const Threads = connect(
    state => ({ ...state.threads
    }), {
        loadThreads,
        toggleModal
    }
)(ThreadsUI);

export {
    Threads,
    ThreadsUI
};