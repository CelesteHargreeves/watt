import React from "react";
import {
    Route,
    BrowserRouter,
    StaticRouter,
    Switch
} from "react-router-dom";
import {
    isClient
} from "../../helpers";
import PropTypes from "prop-types";

import {
    Threads
} from "./Threads";
import {
    Conversation
} from "./Conversation";

export const Inbox = ({
    username,
    url
}) => {
    const Router = isClient() ? BrowserRouter : StaticRouter;
    return ( <
        Router basename = "/inbox"
        location = {
            url
        }
        context = {
            {}
        } >
        <
        Switch >
        <
        Route exact path = "/" >
        <
        Threads username = {
            username
        }
        /> <
        /Route> <
        Route exact path = "/:activeThread" >
        <
        Conversation username = {
            username
        }
        /> <
        /Route> <
        /Switch> <
        /Router>
    );
};

Inbox.propTypes = {
    username: PropTypes.string.isRequired,
    url: PropTypes.string
};