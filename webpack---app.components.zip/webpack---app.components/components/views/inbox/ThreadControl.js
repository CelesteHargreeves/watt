import React from "react";
import PropTypes from "prop-types";
import {
    connect
} from "react-redux";
import {
    UserSafetyOperations
} from "../../shared-components";
import {
    deleteConversation
} from "./Conversation/reducers";
import {
    muteUser,
    unmuteUser
} from "../profile/reducers";
import {
    toggleModal
} from "../../shared-components/modals/actions";
import {
    toggleToast
} from "../../shared-components/toasts/reducers";
import MuteModal from "../../shared-components/modals/components/user-safety-modals/MuteModal";
import UnmuteModal from "../../shared-components/modals/components/user-safety-modals/UnmuteModal";
import {
    useTrans
} from "../../hooks";
import ReportModal from "../report/ReportModal";

function ThreadControlUI({
    isLoading,
    activeThread,
    isMutedByCurrentUser,
    isBlockedByCurrentUser,
    muteUser,
    deleteConversation,
    unmuteUser,
    toggleModal,
    toggleToast
}) {
    const {
        trans
    } = useTrans();

    function reportConversation() {
        // Temporary error toast
        // TODO: Delete this function when new error designs are given
        const showErrorToast = errorMessage => {
            toggleToast({
                className: "report-private-message-toast",
                body: errorMessage
            });
        };

        const component = () => ( <
            ReportModal title = {
                trans("Report a Private Message")
            }
            reportType = "private-message"
            requesterUsername = {
                wattpad.utils.currentUser().get("username")
            }
            requesterEmail = {
                wattpad.utils.currentUser().get("email")
            }
            reportId = {
                {
                    name: activeThread
                }
            }
            hideModal = {
                toggleModal
            }
            showErrorToast = {
                showErrorToast
            }
            />
        );
        component.displayName = "ReportModal";

        toggleModal({
            className: "report-modal",
            hideClose: true,
            component
        });
    }

    function onDeleteConversation() {
        if (
            confirm(trans("Delete all messages between you and %s?", activeThread))
        ) {
            deleteConversation(activeThread).then(() => {
                if (window.location.pathname === "/inbox") {
                    window.location.reload();
                } else {
                    window.app.router.navigate("/inbox", {
                        trigger: true
                    });
                }
            });
        }
    }

    function onMuteSender() {
        const component = () => ( <
            MuteModal username = {
                activeThread
            }
            toggleModal = {
                toggleModal
            }
            muteUser = {
                muteUser
            }
            />
        );
        component.displayName = "MuteModal";

        toggleModal({
            className: "mute-modal",
            hideClose: true,
            component
        });
    }

    function onUnmuteSender() {
        const component = () => ( <
            UnmuteModal username = {
                activeThread
            }
            toggleModal = {
                toggleModal
            }
            onUnmute = {
                unmuteUser
            }
            />
        );
        component.displayName = "UnmuteModal";

        toggleModal({
            className: "mute-modal",
            hideClose: true,
            component
        });
    }
    return ( <
        div > {!isLoading && ( <
                UserSafetyOperations username = {
                    activeThread
                }
                isMutedByCurrentUser = {
                    isMutedByCurrentUser
                }
                isBlockedByCurrentUser = {
                    isBlockedByCurrentUser
                }
                onMuteUser = {
                    onMuteSender
                }
                onUnmuteUser = {
                    onUnmuteSender
                }
                onDeleteConversation = {
                    onDeleteConversation
                }
                onReportUser = {
                    reportConversation
                }
                showModerationOptions = {
                    true
                }
                />
            )
        } <
        /div>
    );
}

ThreadControlUI.propTypes = {
    activeThread: PropTypes.string.isRequired,
    isLoading: PropTypes.bool.isRequired,
    deleteConversation: PropTypes.func.isRequired,
    isMutedByCurrentUser: PropTypes.bool.isRequired,
    isBlockedByCurrentUser: PropTypes.bool,
    muteUser: PropTypes.func.isRequired,
    unmuteUser: PropTypes.func.isRequired,
    toggleModal: PropTypes.func,
    toggleToast: PropTypes.func
};

const ThreadControl = connect(
    null, {
        deleteConversation,
        muteUser,
        unmuteUser,
        toggleModal,
        toggleToast
    }
)(ThreadControlUI);

export {
    ThreadControl,
    ThreadControlUI
};