export const EditorTabs = {
    NOTES: "story-planner"
};