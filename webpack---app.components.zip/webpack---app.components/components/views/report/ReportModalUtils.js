const buildDmcaUrl = reportId => {
    const queryParams = new URLSearchParams();
    if (reportId.location) {
        queryParams.append("storyId", reportId.location);
    }
    if (reportId.deepLink) {
        queryParams.append("partId", reportId.deepLink);
    }
    if (reportId.name) {
        queryParams.append("reportedUser", reportId.name);
    }
    return `/help/dmca?${queryParams.toString()}`;
};

export const buildUserOptionUrl = reportId => baseUrl => {
    if (baseUrl.toLowerCase().includes("help/dmca")) {
        return buildDmcaUrl(reportId);
    } else {
        return baseUrl;
    }
};