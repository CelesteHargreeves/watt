import React from "react";
import PropTypes from "prop-types";
import Icon from "./Icon";

import {
    useTrans
} from "../hooks";

function UserSafetyOperations({
    username,
    isMutedByCurrentUser,
    isBlockedByCurrentUser,
    onMuteUser,
    onUnmuteUser,
    onBlockUser,
    onUnblockUser,
    onDeleteConversation,
    onReportUser,
    showBlockOption,
    showModerationOptions
}) {
    const {
        trans
    } = useTrans();
    const showMuteOption = isMutedByCurrentUser != undefined;

    return ( <
        div className = "user-safety-operations" > {
            showModerationOptions &&
            showMuteOption &&
            !isBlockedByCurrentUser && ( <
                MuteButton username = {
                    username
                }
                isMutedByCurrentUser = {
                    isMutedByCurrentUser
                }
                onMuteUser = {
                    () => onMuteUser(username)
                }
                onUnmuteUser = {
                    () => {
                        onUnmuteUser(username);
                    }
                }
                />
            )
        } {
            showModerationOptions &&
                showBlockOption &&
                isBlockedByCurrentUser !== undefined && ( <
                    BlockButton username = {
                        username
                    }
                    isBlockedByCurrentUser = {
                        isBlockedByCurrentUser
                    }
                    onBlockUser = {
                        () => onBlockUser(username)
                    }
                    onUnblockUser = {
                        () => {
                            onUnblockUser(username);
                        }
                    }
                    />
                )
        }

        {
            onReportUser && ( <
                button onClick = {
                    onReportUser
                }
                className = "on-report user-safety-operation btn-no-background btn-left-icon"
                data - username = {
                    username
                } >
                <
                Icon name = "report" / > {
                    trans("Report")
                } <
                /button>
            )
        } {
            onDeleteConversation && ( <
                button onClick = {
                    onDeleteConversation
                }
                className = "user-safety-operation btn-no-background btn-left-icon delete" >
                <
                Icon name = "trash" / > {
                    trans("Delete Conversation")
                } <
                /button>
            )
        }

        <
        a href = "https://support.wattpad.com/hc/en-us/articles/200774234-Code-of-Conduct"
        className = "conduct-link user-safety-operation btn-no-background btn-left-icon"
        target = "_blank"
        rel = "noopener noreferrer"
        tabIndex = "0" >
        <
        Icon name = "link" / > {
            trans("Code of Conduct")
        } <
        /a>

        <
        a href = "https://safetyportal.wattpad.com/"
        className = "safety-link user-safety-operation btn-no-background btn-left-icon"
        target = "_blank"
        rel = "noopener noreferrer"
        tabIndex = "0" >
        <
        Icon name = "link" / > {
            trans("Wattpad Safety Portal")
        } <
        /a> <
        /div>
    );
}

function MuteButton({
    isMutedByCurrentUser,
    onMuteUser,
    onUnmuteUser,
    username
}) {
    const {
        trans
    } = useTrans();
    return ( <
        React.Fragment > {!isMutedByCurrentUser ? ( <
                button onClick = {
                    onMuteUser
                }
                className = "user-safety-operation btn-no-background btn-left-icon mute" >
                <
                Icon name = "mute" / > {
                    trans("Mute %s", username)
                } <
                /button>
            ) : ( <
                button onClick = {
                    onUnmuteUser
                }
                className = "user-safety-operation btn-no-background btn-left-icon unmute" >
                <
                Icon name = "unmute" / > {
                    trans("Unmute %s", username)
                } <
                /button>
            )
        } <
        /React.Fragment>
    );
}

function BlockButton({
    isBlockedByCurrentUser,
    onBlockUser,
    onUnblockUser,
    username
}) {
    const {
        trans
    } = useTrans();
    return ( <
        React.Fragment > {!isBlockedByCurrentUser ? ( <
                button onClick = {
                    onBlockUser
                }
                className = "user-safety-operation btn-no-background btn-left-icon block" >
                <
                Icon name = "block"
                strokeWidth = "0"
                viewBox = "16" / > {
                    trans("Block %s", username)
                } <
                /button>
            ) : ( <
                button onClick = {
                    onUnblockUser
                }
                className = "user-safety-operation btn-no-background btn-left-icon unblock" >
                <
                Icon name = "block"
                strokeWidth = "0"
                viewBox = "16" / > {
                    trans("Unblock %s", username)
                } <
                /button>
            )
        } <
        /React.Fragment>
    );
}

UserSafetyOperations.propTypes = {
    username: PropTypes.string.isRequired,
    onDeleteConversation: PropTypes.func,
    isMutedByCurrentUser: PropTypes.bool,
    isBlockedByCurrentUser: PropTypes.bool,
    onMuteUser: PropTypes.func,
    onUnmuteUser: PropTypes.func,
    onBlockUser: PropTypes.func,
    onUnblockUser: PropTypes.func,
    onReportUser: PropTypes.func,
    showBlockOption: PropTypes.any,
    showModerationOptions: PropTypes.bool
};

MuteButton.propTypes = {
    username: PropTypes.string.isRequired,
    isMutedByCurrentUser: PropTypes.bool.isRequired,
    onMuteUser: PropTypes.func.isRequired,
    onUnmuteUser: PropTypes.func.isRequired
};

BlockButton.propTypes = {
    username: PropTypes.string.isRequired,
    isBlockedByCurrentUser: PropTypes.bool.isRequired,
    onBlockUser: PropTypes.func.isRequired,
    onUnblockUser: PropTypes.func.isRequired
};

export default UserSafetyOperations;