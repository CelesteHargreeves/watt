import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
    sprintf
} from "sprintf-js";

import {
    useTrans
} from "../hooks";

import {
    Icon
} from "./";

/**
 * The Story Parts Card.
 * Displays an action icon, title, description and navigation icon for the
 * parts attribute of story data.
 */
const StoryPartsCard = ({
    numParts,
    lastUpdated,
    handleClick,
    storyPartsVisible,
    className
}) => {
    const {
        trans,
        ngettext
    } = useTrans();

    return ( <
        button className = {
            classNames("card", className)
        }
        onClick = {
            handleClick
        } >
        <
        Icon className = "card__action-icon"
        name = "partsBeta"
        size = "32"
        fill = {
            true
        }
        viewBox = "16"
        strokeWidth = "1" /
        >
        <
        div className = "card__label" >
        <
        span className = {
            "card__title"
        } > {
            sprintf(ngettext("%s part", "%s parts", numParts), numParts)
        } <
        /span> <
        span className = {
            "card__description"
        }
        dangerouslySetInnerHTML = {
            {
                /* prettier-ignore */
                __html: trans("Last updated <strong>%s</strong>", lastUpdated)
            }
        }
        /> <
        /div> <
        Icon className = {
            classNames("card__nav-icon", {
                "card__nav-icon--rotated": storyPartsVisible
            })
        }
        name = "chevRight"
        size = "24" /
        >
        <
        /button>
    );
};

StoryPartsCard.propTypes = {
    className: PropTypes.string,
    numParts: PropTypes.number,
    lastUpdated: PropTypes.string,
    handleClick: PropTypes.func,
    storyPartsVisible: PropTypes.bool
};

export default StoryPartsCard;