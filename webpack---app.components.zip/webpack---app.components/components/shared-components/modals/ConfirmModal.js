import React from "react";
import PropTypes from "prop-types";
import {
    Button,
    ButtonVariant
} from "@wattpad/web-ui-library";

import {
    useTrans
} from "../../hooks";

const ConfirmModal = ({
        title,
        modalRef,
        contentText,
        confirmLabel,
        declineLabel,
        onConfirmClick,
        onDeclineClick
    }) => {
        const {
            trans
        } = useTrans();

        return ( <
                div className = "confirm-modal"
                ref = {
                    modalRef
                } > {
                    title && < h3 className = "title" > {
                        title
                    } < /h3>} {
                        contentText && < p className = "content-text" > {
                                contentText
                            } < /p>} <
                            div className = "confirm-buttons" >
                            <
                            Button onClick = {
                                onDeclineClick
                            }
                        variant = {
                                ButtonVariant.SECONDARY
                            } > {
                                declineLabel || trans("No")
                            } <
                            /Button> <
                            Button onClick = {
                                onConfirmClick
                            }
                        variant = {
                                ButtonVariant.PRIMARY
                            } > {
                                confirmLabel || trans("Yes")
                            } <
                            /Button> <
                            /div> <
                            /div>
                    );
                };

                ConfirmModal.propTypes = {
                    onConfirmClick: PropTypes.func.isRequired,
                    onDeclineClick: PropTypes.func.isRequired,
                    title: PropTypes.string,
                    modalRef: PropTypes.func,
                    contentText: PropTypes.string,
                    confirmLabel: PropTypes.string,
                    declineLabel: PropTypes.string
                };

                export default ConfirmModal;