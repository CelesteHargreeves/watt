// Actions
export const TOGGLE_MODAL_VISIBLE = "TOGGLE_MODAL_VISIBLE";
export const OPEN_MODAL = "OPEN_MODAL";
export const CLOSE_MODAL = "CLOSE_MODAL";