import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import {
    useTrans,
    useTrapKeyboardNavigation
} from "../../../../hooks";

const MuteModal = ({
    username,
    toggleModal,
    muteUser
}) => {
    const {
        trans
    } = useTrans();

    const confirmationText = trans("This account will not be able to follow you, send you messages, post on your profile or comment on your stories."); // prettier-ignore

    let muteClasses = classNames("btn-primary", {
        "on-mute-user": muteUser === undefined
    });

    let modalRef;
    let buttonRef;

    // Check window in case document is not planted
    if (typeof window !== undefined) {
        modalRef = document.querySelector(".mute-modal");
        buttonRef = document.querySelector(".dropdown-toggle");
    }

    useTrapKeyboardNavigation(modalRef, buttonRef, toggleModal);

    return ( <
        div className = "mute-modal-content" >
        <
        h3 className = "mute-modal-title" > {
            trans("Mute %s", username)
        } < /h3> <
        p > {
            confirmationText
        } < /p> <
        div className = "confirm-buttons" >
        <
        button className = "cancel-mute"
        onClick = {
            toggleModal
        } > {
            trans("Cancel")
        } <
        /button> <
        button className = {
            muteClasses
        }
        onClick = {
            () => {
                toggleModal();
                if (muteUser) {
                    muteUser(username);
                }
            }
        } >
        {
            trans("Mute")
        } <
        /button> <
        /div> <
        /div>
    );
};

MuteModal.propTypes = {
    username: PropTypes.string.isRequired,
    toggleModal: PropTypes.func.isRequired,
    muteUser: PropTypes.func,
    buttonRef: PropTypes.object
};

export default MuteModal;