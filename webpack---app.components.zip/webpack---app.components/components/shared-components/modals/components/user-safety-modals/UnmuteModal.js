import React from "react";
import PropTypes from "prop-types";
import {
    useTrans,
    useTrapKeyboardNavigation
} from "../../../../hooks";

const UnmuteModal = ({
    username,
    onUnmute,
    toggleModal
}) => {
    const {
        trans
    } = useTrans();

    const unmuteInfo = trans(
        "This account will now be able to follow you, send you messages, post on your profile and comment on your stories."
    );
    let modalRef;
    let buttonRef;

    // Check window in case document is not planted
    if (typeof window !== undefined) {
        modalRef = document.querySelector(".unmute-modal");
        buttonRef = document.querySelector(".unmute-button");
    }

    useTrapKeyboardNavigation(modalRef, buttonRef, toggleModal);

    return ( <
        div className = "mute-modal-content" >
        <
        h3 className = "mute-modal-title" > {
            trans("Unmute %s", username)
        } < /h3> <
        p > {
            unmuteInfo
        } < /p> <
        div className = "confirm-buttons" >
        <
        button className = "cancel-mute"
        onClick = {
            toggleModal
        } > {
            trans("Cancel")
        } <
        /button> <
        button className = "btn-primary btn-md"
        onClick = {
            () => {
                toggleModal();
                if (onUnmute) {
                    onUnmute(username);
                }
            }
        } >
        {
            trans("Unmute")
        } <
        /button> <
        /div> <
        /div>
    );
};

UnmuteModal.defaultProps = {
    onUnmute: () => {},
    toggleModal: () => {}
};

UnmuteModal.propTypes = {
    username: PropTypes.string.isRequired,
    trans: PropTypes.func,
    onUnmute: PropTypes.func,
    toggleModal: PropTypes.func,
    buttonRef: PropTypes.object
};

export default UnmuteModal;