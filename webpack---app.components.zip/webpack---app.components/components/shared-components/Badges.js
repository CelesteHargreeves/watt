import React from "react";
import PropTypes from "prop-types";

import AuthorName from "./AuthorName";
import TagItem from "../views/tags/TagItem";
import {
    useTrans
} from "../hooks";
import ReactTooltip from "react-tooltip";
import {
    fromNow,
    canUseDom
} from "../helpers";

/**
 * The story badges.
 * Displays the author and whether the story is paid or completed.
 */
const Badges = ({
        isCompleted,
        isMature,
        user: {
            username,
            avatar
        },
        publishDate
    }) => {
        const {
            trans
        } = useTrans();

        let completedText = null;
        let completedColor = null;
        if (isCompleted) {
            completedText = trans("Complete");
            completedColor = "#1C6F65";
        } else if (isCompleted === false) {
            completedText = trans("Ongoing");
            completedColor = "#8D5610";
        }
        const matureText = trans("Mature");

        // format first published date
        const date = fromNow(publishDate, {
            fuzzyTime: true
        });

        // prevent tooltip from overflowing on the left
        const overridePos = ({
            left,
            top
        }, _e, _t, node) => {
            return {
                top,
                left: typeof node === "string" ? left : Math.max(left, 0)
            };
        };

        return ( <
                div className = "xxs-container-padding badges" > {
                    username && < AuthorName username = {
                        username
                    }
                    avatar = {
                        avatar
                    }
                    />} <
                    div className = "story-badges" > {
                        completedText &&
                        completedColor && ( <
                            div className = "icon completed"
                            data - tip data -
                            for = "publish-date"
                            aria - describedby = "publish-date"
                            // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
                            tabIndex = "0"
                            aria - hidden >
                            <
                            TagItem name = {
                                completedText
                            }
                            bgColor = {
                                completedColor
                            }
                            color = "#ffffff"
                            disableClick = {
                                true
                            }
                            /> <
                            /div>
                        )
                    } <
                    span className = "sr-only" > {
                        trans("%s, First published %s", completedText, date)
                    } <
                    /span> {
                        canUseDom ? ( <
                                ReactTooltip id = "publish-date"
                                effect = "solid"
                                role = "tooltip"
                                backgroundColor = "#000000"
                                overridePosition = {
                                    overridePos
                                }
                                aria - hidden >
                                {
                                    trans("First published")
                                } { < strong > {
                                        trans("%s", date)
                                    } < /strong>} <
                                    /ReactTooltip>): null
                            } {
                                isMature && ( <
                                    div className = "icon mature" >
                                    <
                                    TagItem name = {
                                        matureText
                                    }
                                    bgColor = {
                                        "#9E1D42"
                                    }
                                    color = "#ffffff"
                                    disableClick = {
                                        true
                                    }
                                    /> <
                                    /div>
                                )
                            } <
                            /div> <
                            /div>
                    );
                };

                Badges.propTypes = {
                    user: PropTypes.shape({
                        username: PropTypes.string, // TODO: add placeholder author, and trans tag.
                        avatar: PropTypes.string.isRequired
                    }),
                    isCompleted: PropTypes.bool,
                    isMature: PropTypes.bool,
                    publishDate: PropTypes.string
                };

                export default Badges;