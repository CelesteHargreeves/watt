import React, {
    createRef,
    useState,
    useEffect
} from "react";
import PropTypes from "prop-types";
import {
    useTrans
} from "../../hooks/useTrans";
import classnames from "classnames";

import Icon from "../Icon";

export const BootstrapPopoverProps = {
    className: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.arrayOf(PropTypes.string)
    ]),
    href: PropTypes.string,
    hrefText: PropTypes.string,
    closeText: PropTypes.string,
    isPrefilledTagPopover: PropTypes.bool
};

/**
 * BootstrapPopover
 * Is a React wrapper for the `initPopover` function from `works-item-details`
 *
 * @param {string} className Custom classname for the trigger icon
 * @param {string} title Header of the popover
 * @param {array} content An array of paragraph strings
 * @param {string} href Optional URL for an off-page link
 * @param {string} hrefText Customizes the text for the off-page link
 * @param {string} closeText Customizes the close button text
 * @param {string} isPrefilledTagPopover Changes the style of the close button
 * @renders An information icon which generates a popover when clicked
 */
const BootstrapPopover = ({
    className,
    title,
    content,
    href,
    hrefText,
    closeText,
    isPrefilledTagPopover
}) => {
    const {
        trans
    } = useTrans();
    const popoverElRef = createRef();
    const [popoverIsSet, setPopoverIsSet] = useState(false);

    useEffect(
        () => {
            if (!popoverElRef.current || popoverIsSet) return;

            $(popoverElRef.current)
                .popover({
                    template: `<div class="popover writer-tooltip" role="tooltip">
            <div class="arrow"></div>
              <h3 class="popover-title"></h3>
            <div class="popover-content"></div></div>`,
                    title,
                    html: true,
                    placement: "top",
                    content: function() {
                        return (
                            (Array.isArray(content) ?
                                content
                                .map(
                                    (text, i) =>
                                    `<div class="${
                          i > 0 ? "additional" : "main"
                        }-content">${text}</div>`
                                )
                                .join("") :
                                content) +
                            `<div class="tooltip-footer">
              ${
                href
                  ? `<a href="${href}" target="_blank">${
                      hrefText ? hrefText : trans("Learn More")
                    }</a>`
                  : ""
              }
              <button type="button" class="btn on-okay ${
                isPrefilledTagPopover ? "btn-link " : "btn-purple"
              }">${
                isPrefilledTagPopover ? "Got It" : closeText || trans("OK")
              }</button>
            </div>`
                        );
                    }
                })
                .on("shown.bs.popover", function(e) {
                    var popover = $(e.target);
                    $(document).on("click.closePopover", function(e) {
                        if ($(e.target).parents(".popover").length === 0) {
                            popover.popover("hide");
                        }
                    });
                });

            setPopoverIsSet(true);
        }, [
            popoverElRef,
            popoverIsSet,
            setPopoverIsSet,
            title,
            content,
            href,
            hrefText,
            closeText,
            isPrefilledTagPopover,
            trans
        ]
    );

    return ( <
        div className = {
            classnames("bs-popover-tooltip", className)
        }
        ref = {
            popoverElRef
        } >
        <
        span data - toggle = "popover"
        className = "popover-icon" >
        <
        Icon iconName = "fa-info"
        height = "16"
        color = "wp-neutral-2" / >
        <
        /span> <
        /div>
    );
};

BootstrapPopover.defaultProps = {
    className: "",
    title: "",
    content: [],
    href: "",
    hrefText: "",
    closeText: "",
    isPrefilledTagPopover: false
};

BootstrapPopover.propTypes = BootstrapPopoverProps;

export default BootstrapPopover;