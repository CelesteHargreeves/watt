import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import {
    formatStoryUrl
} from "../helpers";
import {
    useTrans
} from "../hooks";
import {
    Icon
} from ".";

const StoryParts = ({
    storyId,
    sources,
    parts,
    isPaywalled,
    readingPosition,
    className
}) => {
    const onStoryPartClick = (evt, partId, partLink) => {
        evt.preventDefault();
        // Story click event
        window.te.push("event", "client", "story", null, null, "click", {
            storyid: storyId,
            page: "story_details",
            type: "primary",
            source: "story_details",
            partid: partId,
            algo_source: sources || ""
        });
        app.router.navigate(partLink, {
            trigger: true
        });
    };
    const {
        trans
    } = useTrans();

    return ( <
        div className = {
            classNames("story-parts", className)
        } >
        <
        ul > {
            parts &&
            parts.map(part => {
                const isActivelyReadingPart =
                    readingPosition && readingPosition.part === part.id;

                return ( <
                    li key = {
                        part.id
                    } >
                    <
                    a href = {
                        part.url && formatStoryUrl(part.url)
                    }
                    className = {
                        classNames("story-parts__part", {
                            "story-parts__part-currently-reading": isActivelyReadingPart
                        })
                    }
                    onClick = {
                        evt =>
                        onStoryPartClick(evt, part.id, formatStoryUrl(part.url))
                    } >
                    <
                    div className = "part__label" > {
                        part.title
                    } {
                        part.draft && ( <
                            span className = "draft-tag" > [{
                                trans("Draft")
                            }] < /span>
                        )
                    } {
                        part.deleted && ( <
                            span className = "deleted-tag" > [{
                                trans("Deleted")
                            }] < /span>
                        )
                    } {
                        isActivelyReadingPart && ( <
                            div className = "part__reading-progress" > {
                                trans(
                                    "%s%% Complete",
                                    (readingPosition.position * 100).toFixed(0)
                                )
                            } <
                            /div>
                        )
                    } <
                    /div>

                    { /* Render icon for all parts, but set visibility:none for parts that are not blocked, so that all story parts maintain the same alignment */ } {
                        !isActivelyReadingPart &&
                            isPaywalled && ( <
                                Icon className = {
                                    classNames("part__icon", {
                                        "part__icon--hidden": !part.isBlocked
                                    })
                                }
                                name = "lock"
                                size = "24"
                                color = "ds-neutral-100"
                                title = {
                                    part.isBlocked ? trans("Locked") : null
                                }
                                />
                            )
                    } <
                    /a> <
                    /li>
                );
            })
        } <
        /ul> <
        /div>
    );
};

StoryParts.propTypes = {
    parts: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number,
            title: PropTypes.string
        })
    ).isRequired,
    storyId: PropTypes.number,
    sources: PropTypes.array,
    isPaywalled: PropTypes.bool.isRequired,
    readingPosition: PropTypes.shape({
        part: PropTypes.number,
        position: PropTypes.oneOfType([
            // API returns 0 or "n"
            PropTypes.string,
            PropTypes.number
        ])
    }),
    className: PropTypes.string
};

export default StoryParts;