import React, {
    useEffect,
    useRef
} from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

/**
 * Advertisement
 * This creates an empty ad div that our code will fill with an ad placement
 * @param {String} placement The unit requested
 * @param {String} className Custom class for laying out ads in context
 * @param {String} shouldDelayAds Custom class for laying out ads in context
 * Returns
 * Ad placement div
 */
const Advertisement = ({
    placement,
    className,
    shouldDelayAds,
    shouldShowAds
}) => {
    let adUnitId = useRef(placement + "-" + Date.now());
    useEffect(
        () => {
            const adAvailableEvent = new CustomEvent("ad-available", {
                bubbles: true,
                detail: {
                    adUnitId: adUnitId.current,
                    shouldDelayAds: shouldDelayAds,
                    shouldShowAds: shouldShowAds,
                    lazyLoadAd: true
                }
            });
            window.dispatchEvent(adAvailableEvent);
        }, [placement, shouldDelayAds, shouldShowAds]
    );

    return ( <
        div id = {
            adUnitId.current
        }
        className = {
            classNames(`${placement}`, "advertisement", className)
        }
        alt = {
            `Advertisement - ${adUnitId.current}`
        }
        />
    );
};

Advertisement.propTypes = {
    placement: PropTypes.string.isRequired,
    className: PropTypes.string,
    shouldDelayAds: PropTypes.bool,
    shouldShowAds: PropTypes.bool
};

export default Advertisement;