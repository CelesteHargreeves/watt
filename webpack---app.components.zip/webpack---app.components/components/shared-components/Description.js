import React from "react";
import PropTypes from "prop-types";

/**
 * The story description.
 */
const Description = ({
    description,
    license
}) => {
    return ( <
        div className = "xxs-container-padding description" >
        <
        pre className = "description-text" > {
            description
        } < /pre> {
            license && ( <
                div className = "story-copyright" >
                <
                span className = "fa fa-copyright fa-wp-neutral-8"
                aria - hidden = "true" /
                > {
                    `${license.name}`
                } <
                /div>
            )
        } <
        /div>
    );
};

Description.propTypes = {
    description: PropTypes.string,
    license: PropTypes.object
};

export default Description;