import React, {
    useState
} from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
    BootstrapPopoverProps
} from "../popover/BootstrapPopover";

import {
    buildLabel
} from "./helpers/input-labels";
import {
    unixToDateTime
} from "../../../components/helpers/unixDateTime";

const DateTimeField = ({
    className,
    labelClassName,
    label,
    value,
    name,
    info,
    popover,
    min,
    max,
    onChange,
    onFocus,
    onBlur,
    disabled,
    required
}) => {
    const [isFocused, setIsFocused] = useState(false);
    const optionalAttributes = {};
    min && (optionalAttributes.min = unixToDateTime(min));
    max && (optionalAttributes.max = unixToDateTime(max));

    const handleChange = event => onChange(event);

    const handleFocus = () => {
        setIsFocused(true);
        onFocus();
    };

    const handleBlur = () => {
        setIsFocused(false);
        onBlur();
    };

    return ( <
        div className = {
            classNames("form-field", "date-time-field", className)
        } > {
            buildLabel({
                label,
                labelClassName,
                tooltip: info,
                popover
            })
        }

        <
        input className = {
            classNames("datetime-form-field", {
                focus: isFocused
            })
        }
        type = "datetime-local"
        name = {
            name
        }
        defaultValue = {
            unixToDateTime(value)
        } { ...optionalAttributes
        }
        disabled = {
            disabled
        }
        required = {
            required
        }
        onChange = {
            handleChange
        }
        onFocus = {
            handleFocus
        }
        onBlur = {
            handleBlur
        }
        /> <
        /div>
    );
};

DateTimeField.defaultProps = {
    popover: null,
    disabled: false,
    required: false,
    onChange: () => {},
    onFocus: () => {},
    onBlur: () => {}
};

DateTimeField.propTypes = {
    className: PropTypes.string,
    labelClassName: PropTypes.string,
    label: PropTypes.string,
    value: PropTypes.any,
    name: PropTypes.string,
    info: PropTypes.string,
    popover: PropTypes.shape(BootstrapPopoverProps),
    min: PropTypes.string,
    max: PropTypes.string,
    onChange: PropTypes.func.isRequired,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    disabled: PropTypes.bool,
    required: PropTypes.bool
};

export default DateTimeField;