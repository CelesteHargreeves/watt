import React, {
    useState
} from "react";
import {
    useTrans
} from "../../hooks";
import classNames from "classnames";
import PropTypes from "prop-types";

import {
    generateDropdownItems as generateSelectOptions
} from "./helpers";

const WPInput = ({
    inputType,
    name,
    id,
    onBlur,
    onFocus,
    onChange,
    autofocus,
    alt,
    inputRef,
    placeholder,
    showVisibilityToggle,
    addClassName
}) => {
    const {
        trans
    } = useTrans();

    let inputClasses = classNames(
        "form-control",
        addClassName,
        "enable",
        "input-lg", {
            "custom-select": inputType === "select",
            "custom-select-lg": inputType === "select"
        }
    );
    const [passwordType, setPasswordType] = useState("password");
    const togglePasswordVisibility = e => {
        e.preventDefault();
        e.stopPropagation();
        setPasswordType(passwordType === "text" ? "password" : "text");
    };

    switch (inputType) {
        case "select":
            return ( <
                div className = "birthday-dropdowns" >
                <
                select id = {
                    id
                }
                className = {
                    inputClasses
                }
                name = {
                    name
                }
                defaultValue = ""
                onBlur = {
                    onBlur
                }
                aria - label = {
                    alt
                }
                ref = {
                    inputRef
                }
                required >
                {
                    generateSelectOptions(name)
                } <
                /select> <
                /div>
            );
        case "password":
            return ( <
                div className = "password-container" >
                <
                input type = {
                    passwordType
                }
                id = {
                    id
                }
                className = {
                    inputClasses
                }
                name = {
                    name
                }
                placeholder = {
                    placeholder
                }
                autoFocus = {
                    autofocus
                }
                onBlur = {
                    onBlur
                }
                onFocus = {
                    onFocus
                }
                onChange = {
                    onChange
                }
                ref = {
                    inputRef
                }
                aria - label = {
                    alt
                }
                required /
                > {
                    showVisibilityToggle && ( <
                        button type = "button"
                        className = "password-show btn-no-background"
                        aria - label = {
                            passwordType === "text" ?
                            trans("Hide password") :
                                trans("Show password")
                        }
                        onClick = {
                            togglePasswordVisibility
                        } >
                        {
                            passwordType === "text" ? trans("Hide") : trans("Show")
                        } <
                        /button>
                    )
                } <
                /div>
            );
        default:
            return ( <
                input type = {
                    inputType
                }
                id = {
                    id
                }
                className = {
                    inputClasses
                }
                name = {
                    name
                }
                placeholder = {
                    placeholder
                }
                autoFocus = {
                    autofocus
                }
                onBlur = {
                    onBlur
                }
                aria - label = {
                    alt
                }
                ref = {
                    inputRef
                }
                required /
                >
            );
    }
};

WPInput.propTypes = {
    inputType: PropTypes.string,
    name: PropTypes.string,
    id: PropTypes.string,
    label: PropTypes.string,
    onBlur: PropTypes.func,
    onFocus: PropTypes.func,
    onChange: PropTypes.func,
    autofocus: PropTypes.bool,
    showVisibilityToggle: PropTypes.bool,
    alt: PropTypes.string,
    inputRef: PropTypes.object,
    placeholder: PropTypes.string,
    addClassName: PropTypes.string
};

export default WPInput;