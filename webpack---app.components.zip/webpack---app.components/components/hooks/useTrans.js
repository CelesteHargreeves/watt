import {
    useContext
} from "react";
import {
    I18nContext
} from "../contexts";

export function useTrans() {
    return useContext(I18nContext);
}