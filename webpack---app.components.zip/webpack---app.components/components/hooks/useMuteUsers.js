import React, {
    useEffect,
    useRef
} from "react";
import {
    useDispatch,
    useSelector
} from "react-redux";
import MuteModal from "../shared-components/modals/components/user-safety-modals/MuteModal";
import {
    toggleModal
} from "../shared-components/modals/actions";
import {
    muteUser
} from "../views/profile/reducers";

export const useMuteUsers = onUserMuted => {
    const dispatch = useDispatch();
    const mutedUsers = useSelector(state => state.profileData.mutedUsers);

    const isInitialMount = useRef(true);

    const triggerUserMuted = () => {
        if (isInitialMount.current) {
            isInitialMount.current = false;
        } else {
            if (onUserMuted && mutedUsers && mutedUsers.length > 0) {
                const username = mutedUsers[mutedUsers.length - 1].username;
                onUserMuted(username);
            }
        }
    };

    useEffect(triggerUserMuted, [mutedUsers]);

    const createMuteModal = username => {
        return ( <
            MuteModal username = {
                username
            }
            toggleModal = {
                () => dispatch(toggleModal())
            }
            muteUser = {
                user => dispatch(muteUser(user))
            }
            />
        );
    };

    const openMuteUserModal = username => {
        dispatch(
            toggleModal({
                hideClose: true,
                useGlobalModalContainer: true,
                className: "mute-modal report-comment-modal",
                component: () => createMuteModal(username)
            })
        );
    };

    return {
        openMuteUserModal
    };
};