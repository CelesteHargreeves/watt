import React from "react";
import {
    useDispatch
} from "react-redux";
import {
    useGetUser
} from "./useGetUser";
import ReportModal, {
    ReportTypes
} from "../views/report/ReportModal";
import {
    toggleModal
} from "../shared-components/modals/actions";

export const useReportModal = () => {
    const user = useGetUser();
    const dispatch = useDispatch();

    const createReportModal = (reportType, name, body, location, deepLink) => {
        return ( <
            ReportModal reportType = {
                reportType
            }
            requesterUsername = {
                user.username
            }
            requesterEmail = {
                user.email
            }
            reportId = {
                {
                    name,
                    body,
                    location,
                    deepLink
                }
            }
            hideModal = {
                () => dispatch(toggleModal())
            }
            />
        );
    };

    const openReportModal = (
        reportType,
        name,
        body,
        location,
        deepLink,
        classes = ""
    ) => {
        dispatch(
            toggleModal({
                hideClose: true,
                disableScroll: true,
                disableClose: true,
                className: `report-modal ${classes}`,
                useGlobalModalContainer: true,
                component: () =>
                    createReportModal(reportType, name, body, location, deepLink)
            })
        );
    };

    const openReportStoryModal = (
        storyId,
        storyTitle,
        author,
        partId = undefined
    ) => {
        openReportModal(ReportTypes.STORY, author, storyTitle, storyId, partId);
    };

    return {
        openReportStoryModal,
        openReportModal
    };
};