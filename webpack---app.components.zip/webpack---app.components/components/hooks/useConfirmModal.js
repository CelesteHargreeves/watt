import React, {
    useState,
    useCallback
} from "react";
import {
    useDispatch
} from "react-redux";

import {
    useTrapKeyboardNavigation
} from "../hooks";
import ConfirmModal from "../shared-components/modals/ConfirmModal";
import {
    toggleModal
} from "../shared-components/modals/actions";

export const useConfirmModal = () => {
    const dispatch = useDispatch();

    const [modalEle, setModalEle] = useState();
    const [buttonEle, setButtonEle] = useState();

    const closeModal = () => dispatch(toggleModal());

    useTrapKeyboardNavigation(modalEle, buttonEle, closeModal);

    const handleModalRef = useCallback(node => setModalEle(node), []);

    const createConfirmModal = (
        title,
        contentText,
        confirmLabel,
        declineLabel,
        onConfirmClick,
        onDeclineClick
    ) => {
        return ( <
            ConfirmModal title = {
                title
            }
            modalRef = {
                handleModalRef
            }
            contentText = {
                contentText
            }
            confirmLabel = {
                confirmLabel
            }
            declineLabel = {
                declineLabel
            }
            onConfirmClick = {
                onConfirmClick
            }
            onDeclineClick = {
                onDeclineClick
            }
            />
        );
    };

    const openConfirmModal = ({
        title,
        contentText,
        confirmLabel,
        declineLabel,
        onConfirmClick,
        openTriggerRef
    }) => {
        setButtonEle(openTriggerRef.current);

        const handleConfirm = () => {
            closeModal();
            onConfirmClick();
        };

        const handleDecline = () => {
            closeModal();
            openTriggerRef.current ? .focus();
        };

        dispatch(
            toggleModal({
                hideClose: true,
                useGlobalModalContainer: true,
                className: "confirm-modal-container",
                component: () =>
                    createConfirmModal(
                        title,
                        contentText,
                        confirmLabel,
                        declineLabel,
                        handleConfirm,
                        handleDecline
                    )
            })
        );
    };

    return {
        openConfirmModal
    };
};