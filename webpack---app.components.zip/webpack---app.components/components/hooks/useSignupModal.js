import React from "react";
import {
    useDispatch
} from "react-redux";

import AuthForm from "../views/authentication/AuthForm";
import {
    toggleModal
} from "../shared-components/modals/actions";

export const useSignupModal = () => {
    const dispatch = useDispatch();

    const createAuthForm = () => {
        return <AuthForm nextUrl = {
            window.location.href
        }
        />;
    };

    const openSignupModal = (classes = "") => {
        dispatch(
            toggleModal({
                className: `signup-modal ${classes}`,
                disableScroll: true,
                useGlobalModalContainer: true,
                component: () => createAuthForm()
            })
        );
    };

    return {
        openSignupModal
    };
};