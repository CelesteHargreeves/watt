import {
    useContext
} from "react";
import {
    UserContext
} from "../contexts";

export function useGetUser() {
    return useContext(UserContext);
}