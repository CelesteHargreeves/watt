import {
    useContext
} from "react";
import {
    FeatureFlagsContext
} from "../contexts";

export function useFeatureFlags() {
    return useContext(FeatureFlagsContext);
}