import {
    useCallback,
    useEffect
} from "react";

export const focusableElementsString =
    'a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex="0"], [contenteditable]';

/**
 * A hook that allows you trap the keyboard focus.
 *
 * @param modalRef The modal's DOM element
 * @param buttonRef The DOM element that triggered the modal. This element will be focused after the modal is closed.
 * @param toggleModal Function to be called when the escape key is pressed.
 */
export const useTrapKeyboardNavigation = (
    modalRef,
    buttonRef,
    toggleModal = () => {}
) => {
    useEffect(
        () => {
            if (!modalRef) return;

            // Refs for navigating tab in and out of modal
            let firstTabStop, lastTabStop;

            // Listen for and trap the keyboard in order to maintain the focus
            // inside the modal until ESC key is pressed. This was an exception
            // to the rule for allowing people with accessibility to  navigate
            // one interaction at a time.
            modalRef.addEventListener("keydown", e =>
                trapTabKey(e, firstTabStop, lastTabStop)
            );
            modalRef.addEventListener("tap", e =>
                trapTabKey(e, firstTabStop, lastTabStop)
            );

            // Find all focusable children in order to grab the first and last
            // interactive elements to navigate tab focus when the component is mounted.
            let focusableElements = modalRef.querySelectorAll(
                focusableElementsString
            );
            focusableElements = Array.prototype.slice.call(focusableElements);
            firstTabStop = focusableElements ? .[0];
            lastTabStop = focusableElements ? .[focusableElements.length - 1];

            // focus the first element
            firstTabStop ? .focus();

            return () => {
                modalRef.removeEventListener("keydown", e =>
                    trapTabKey(e, firstTabStop, lastTabStop)
                );
                modalRef.removeEventListener("tap", e =>
                    trapTabKey(e, firstTabStop, lastTabStop)
                );
            };
        }, [modalRef, trapTabKey]
    );

    const trapTabKey = useCallback(
        (e, firstTabStop, lastTabStop) => {
            // Check for TAB key press
            if (e.key === "Tab" && firstTabStop && lastTabStop) {
                // SHIFT + TAB: previous element
                if (e.shiftKey) {
                    if (document.activeElement == firstTabStop) {
                        e.preventDefault();
                        lastTabStop.focus();
                    }
                    // TAB: next element
                } else {
                    if (document.activeElement == lastTabStop) {
                        e.preventDefault();
                        firstTabStop.focus();
                    }
                }
            }
            //Escape the modal
            if (e.key === "Escape" && buttonRef) {
                toggleModal();
                buttonRef.focus();
            }
        }, [buttonRef, toggleModal]
    );
};