import moment from "moment";

const dateTimeToUnix = function(dateTimeString) {
    if (!dateTimeString) return null;
    return moment(dateTimeString).unix();
};

export {
    dateTimeToUnix
};