import moment from "moment";

const unixToDateTime = timeInteger => {
    if (isNaN(timeInteger)) return moment(timeInteger).format("YYYY-MM-DDThh:mm");
    const tStringNumber = parseInt(timeInteger);
    if (!tStringNumber) return null;
    if (tStringNumber <= 0) return null;

    return moment(tStringNumber * 1000).format("YYYY-MM-DDThh:mm");
};

const dateTimeToUnix = dateTimeString => {
    if (!dateTimeString) return null;
    return moment(dateTimeString).unix();
};

export {
    unixToDateTime,
    dateTimeToUnix
};