import _ from "lodash";

const getIndexForPartId = function(partId, story) {
    const parts = story.parts;

    return _.findIndex(parts, part => part.id === partId);
};

export {
    getIndexForPartId
};