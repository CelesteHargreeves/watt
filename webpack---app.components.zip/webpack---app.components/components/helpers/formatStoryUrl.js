const formatStoryUrl = storyUrl => {
    let schemeHostPortMatcher = /^((https?:)?\/\/)?[a-z-.]*[a-z-](:\d+)?(?=\/)/i;
    return storyUrl.replace(schemeHostPortMatcher, "");
};

export {
    formatStoryUrl
};