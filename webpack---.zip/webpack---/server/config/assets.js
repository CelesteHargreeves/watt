"use strict";

var path = require("path"),
    frontendPath = "../../../",
    srcPath = "../../";

exports.assetServer = "//static.wattpad.com";
exports.mediaServer = "//img.wattpad.com";
exports.ie8Server = "//www.wattpad.com";

// Views Information
exports.views = {
    script: "assets/script.handlebars",
    preloadScript: "assets/preload-script.handlebars",
    style: "assets/style.handlebars",
    image: "assets/image.handlebars",
    cover: "assets/story-cover.handlebars",
    avatar: "assets/user-avatar.handlebars"
};

// Global Paths
exports.paths = {
    public: [
        // frontend public folloed by www public
        path.resolve(__dirname, frontendPath, "public")
    ],
    assets: [
        // frontend assets followed by www assets
        path.resolve(__dirname, srcPath, "assets")
    ]
};

// CSS Specific Information
exports.css = {
    minifiedExtension: ".min.css",
    combinedExtension: ".css",
    rtlInfix: "-rtl",
    paths: {
        public: [
            // frontend public followed by www public
            path.resolve(__dirname, frontendPath, "public/css")
        ],
        assets: [
            // frontend assets followed by www assets
            path.resolve(__dirname, srcPath, "assets/styles")
        ]
    },
    baseURL: "/css",
    tmpURL: "/css/tmp/styles"
};

// JavaScript Specific Information
exports.js = {
    minifiedExtension: ".min.js",
    combinedExtension: ".js",
    // There's no difference between LTR and RTL JavaScript, unlike CSS.
    rtlInfix: "",
    paths: {
        public: [
            // frontend public folloed by www public
            path.resolve(__dirname, frontendPath, "public/js")
        ],
        assets: [
            // fronend assets followed by www assets
            path.resolve(__dirname, srcPath, "assets/scripts")
        ]
    },
    baseURL: "/js",
    tmpURL: "/tmp/scripts"
};

// Image Specific Information
exports.image = {
    paths: {
        public: [
            // frontend public followed by www public
            path.resolve(__dirname, frontendPath, "public/img")
        ],
        assets: [
            // frontend assets followed by www assets
            path.resolve(__dirname, srcPath, "assets/images")
        ]
    },
    baseURL: "/img"
};

exports.avatarSizes = [24, 32, 42, 48, 64, 84, 128, 256];
exports.coverSizes = [
    64,
    80,
    100,
    128,
    144,
    160,
    176,
    200,
    208,
    256,
    288,
    352,
    368,
    416,
    512
];
exports.logoSizes = [140, 280, 420];
exports.backgroundSizes = [320, 640, 720, 1280, 1920];