"use strict";

/**
 * ADSX-1479
 * Get Display Ad Eligibility
 * This helper will return a boolean indicating whether or not
 * the story (part + group) is brand safe to render an ad.
 *
 * @param {object} storyPartModel - Story Part model to extract data from
 * @param {object} storyGroupModel - Story Part model to extract data from
 * @param {object} userTestGroups - Test groups the user belongs in for experimental ad features
 * @returns {boolean} - Should we display the ad?  True = YES
 */

var isMatureStory = require("./handlebars/is-mature-story"),
    isBrandSafe = require("./handlebars/is-brand-safe");

const BRAND_SAFETY_RATING_THRESHOLD = 1;

const defaultSafety = storyGroup => {
    return !!(
        storyGroup &&
        //Captures if its brand safe through brand safe boolean value
        isBrandSafe(storyGroup) &&
        //Captures if rating < 4
        !isMatureStory(storyGroup)
    );
};

module.exports = function(
    storyPartModel,
    storyGroupModel,
    userTestGroups = {}
) {
    let brandSafetyLevel;

    if (storyPartModel && storyGroupModel) {
        //If both exists, it means its a story part
        brandSafetyLevel = storyPartModel.brandSafetyLevel;
    }

    if (storyGroupModel && !storyPartModel) {
        // if story part doesnt exist its a story group
        brandSafetyLevel = storyGroupModel.brandSafetyLevel;
    }

    // if a user is in this test group they don't get ads
    if (userTestGroups.SPECIAL_AD_EXEMPT) {
        return false;
    }

    // Tiered decisioning.  USE brand safety service then default
    if (typeof brandSafetyLevel !== "undefined") {
        return (
            brandSafetyLevel < BRAND_SAFETY_RATING_THRESHOLD &&
            !isMatureStory(storyGroupModel)
        );
    }

    if (storyGroupModel && Object.keys(storyGroupModel).length > 0) {
        return defaultSafety(storyGroupModel);
    }

    if (!storyGroupModel && !storyPartModel) {
        // no part or group, not in a reading page (i.e. library)
        return true;
    }

    // Something unexpected has happened
    console.error({
        storyPart: storyPartModel,
        storyGroup: storyGroupModel,
        message: "Brand Safety error"
    });

    // return false to not show ads
    return false;
};