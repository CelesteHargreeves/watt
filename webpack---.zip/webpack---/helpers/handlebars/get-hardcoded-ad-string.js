"use strict";

var getHardcodedAdsList = require("../get-hardcoded-ads-list"),
    assets = require("../../server/config/assets"),
    getPlacementConfiguration = require("../ads/get-placement-configuration");

module.exports = function(
    placement = "unknown",
    unitMeta = {
        additionalClasses: "",
        adText: "",
        adTextClass: "",
        height: 0,
        inlineStyle: "",
        parentClass: "",
        ts: Date.now(),
        width: 0
    }
) {
    // Set placement with multiple sizes to one size
    if (
        placement === "readinglong_mid_mweb" ||
        placement === "readinglong_mid_loggedout_mweb"
    ) {
        unitMeta.width = 300;
        unitMeta.height = 250;
    }
    let placementConfig = getPlacementConfiguration(placement);
    let hasParent = !!unitMeta.parentClass;
    let adTextTemplate = unitMeta.adText ?
        `<h4 class="${unitMeta.adTextClass}">${unitMeta.adText}</h4>` :
        "";

    let adsList = getHardcodedAdsList(unitMeta.width, unitMeta.height);

    let totalVariations = adsList.length;
    let variation = Math.floor(Math.random() * totalVariations);
    let ad = adsList[variation];
    let assetPath = `${assets.assetServer}/image/${ad.prefix}`;
    let creativePath = `${assetPath}_${unitMeta.width}x${unitMeta.height}${ad.postfix}.png`; // prettier-ignore

    let hardcodedCreative = `<a href="${ad.link}" class="hc-creative" rel="nofollow" target="_blank"><img src="${creativePath}" width="${unitMeta.width}" height="${unitMeta.height}" alt="" /></a>`; // prettier-ignore

    // Refreshing ads only generate creative assets, not containers
    if (!hasParent) {
        return hardcodedCreative;
    }

    // Ads from templates generate containers
    if (placementConfig ? .sticky) {
        return `<div id="${placement}-${unitMeta.ts}" class="${unitMeta.parentClass} ${unitMeta.additionalClasses}" data-start-selector="${placementConfig.stickyStart}" data-end-selector="${placementConfig.stickyEnd}" aria-label="Advertisement">${adTextTemplate}${hardcodedCreative}</div>`; // prettier-ignore
    } else {
        return `<div id="${placement}-${unitMeta.ts}" class="advertisement hc ${unitMeta.parentClass} ${unitMeta.additionalClasses}" ${unitMeta.inlineStyle}>${adTextTemplate}${hardcodedCreative}</div>`; // prettier-ignore
    }
};