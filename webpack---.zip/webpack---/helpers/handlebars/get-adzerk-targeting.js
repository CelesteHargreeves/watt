"use strict";

const getViewCountTargeting = require("./get-viewcount-targeting"),
    getRankingTargeting = require("./get-ranking-targeting"),
    getGenderTargeting = require("./get-gender-targeting"),
    getAgeTargeting = require("./get-age-targeting"),
    isServer = require("../is-server");

const serverCategoryList = () => {
    const configFilePath = "../../server/config";
    const mod = module;
    const config = mod.require(configFilePath);

    return config.application.categoryList;
};

const clientCategoryList = () => {
    return window.wattpad.categoryList;
};

module.exports = function(storyGroup, storyPart, user) {
    const categoryList = isServer() ? serverCategoryList() : clientCategoryList();

    var rankingStatus = storyPart ? storyPart.rank : undefined,
        category = storyGroup ?
        storyGroup.category ?
        storyGroup.category :
        storyGroup.categories[0] :
        undefined;

    var targeting = {};

    if (storyPart && storyPart.rating) {
        targeting["partRating"] = storyPart.rating;
    }
    if (storyGroup && storyGroup.rating) {
        targeting["storyRating"] = storyGroup.rating;
    }
    if (category) {
        targeting["category"] = category;
    }
    if (storyPart && storyPart.totalViewCount) {
        targeting["totalViewCount"] = getViewCountTargeting(
            storyPart.totalViewCount
        );
    } else if (storyGroup && storyGroup.totalViewCount) {
        targeting["totalViewCount"] = getViewCountTargeting(
            storyGroup.totalViewCount
        );
    }
    if (storyPart && storyPart.language) {
        targeting["language"] = storyPart.language;
    } else if (storyGroup && storyGroup.language.id) {
        targeting["language"] = storyGroup.language.id;
    }
    if (rankingStatus) {
        targeting["rankingStatus"] = getRankingTargeting(rankingStatus);
    }
    if (storyGroup && storyGroup.id) {
        targeting["storyId"] = storyGroup.id;
    }
    if (storyPart && storyPart.id) {
        targeting["partId"] = storyPart.id;
        targeting["tUrl"] = `https://www.wattpad.com/amp/${storyPart.id}`;
    }
    if (user && user.gender) {
        targeting["KV1"] = getGenderTargeting(user);
        targeting["KV2"] = getAgeTargeting(user);
    }
    if (
        storyPart &&
        (storyPart.brandSafetySource && storyPart.brandSafetyLevel !== undefined)
    ) {
        targeting["brandSafetySource"] = storyPart.brandSafetySource;
        targeting["brandSafetyLevel"] = storyPart.brandSafetyLevel;
    }

    return targeting;
};