"use strict";

module.exports = function(rankingStatus) {
    var rank;
    if (rankingStatus > 0 && rankingStatus <= 100) {
        rank = "0to100";
    } else {
        rank = "100plus";
    }
    return rank;
};