"use strict";

module.exports = function(storyGroup) {
    if (!storyGroup) {
        return true;
    }
    return storyGroup.rating >= 4;
};