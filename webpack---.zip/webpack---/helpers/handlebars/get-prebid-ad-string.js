"use strict";

var getHeaderBiddingInlineStyle = require("./get-header-bidding-inline-style");
var getPlacementConfiguration = require("../ads/get-placement-configuration");

module.exports = function(
    placement = "",
    unitMeta = {
        additionalClasses,
        adText,
        adTextClass,
        label,
        parentClass,
        shouldShowAds,
        sizes,
        ts: Date.now()
    }
) {
    if (placement === "" || !unitMeta.sizes) {
        throw new Error(`Ad failed to create placement: ${placement}, Skipping ad`);
    }

    let placementId = `${placement}-${unitMeta.ts}`;
    let placementConfig = getPlacementConfiguration(placement);
    let inlineStyle = getHeaderBiddingInlineStyle(unitMeta.sizes);
    let classes = `advertisement ${placement}`;

    if (placementConfig["lazyAd"]) {
        classes += " lazyAd";
    }
    if (unitMeta.additionalClasses) {
        classes += ` ${unitMeta.additionalClasses}`;
    }

    return unitMeta.parentClass ?
        wrapWithParentClass(createAdString()) :
        createAdString();

    function wrapWithParentClass(adString) {
        return (
            `<div ` +
            `class="${unitMeta.parentClass}" ` +
            `${
        !placementConfig?.stickyStart
          ? ""
          : `data-start-selector="${placementConfig.stickyStart}"`
      } ` +
            `${
        !placementConfig?.stickyEnd
          ? ""
          : `data-end-selector="${placementConfig.stickyEnd}"`
      }` +
            `>` +
            `${unitMeta.adText &&
        unitMeta.adTextClass &&
        `<h4 class="${unitMeta.adTextClass}">${unitMeta.adText}</h4>`}` +
            `${adString}` +
            `</div>`
        );
    }

    function createAdString() {
        return (
            `<div ` +
            `id="${placementId}" ` +
            `class="${classes}" ` +
            `${inlineStyle} ` +
            `aria-label="${unitMeta.label}">` +
            `</div>`
        );
    }
};