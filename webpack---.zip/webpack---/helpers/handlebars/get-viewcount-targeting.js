"use strict";

module.exports = function(totalViewCount) {
    var viewCount;
    if (totalViewCount >= 0 && totalViewCount < 100) {
        viewCount = "0to100";
    } else if (totalViewCount >= 100 && totalViewCount < 1000) {
        viewCount = "100to1000";
    } else if (totalViewCount >= 1000 && totalViewCount < 10000) {
        viewCount = "1000to10000";
    } else if (totalViewCount >= 10000 && totalViewCount < 100000) {
        viewCount = "10000to100000";
    } else if (totalViewCount >= 100000) {
        viewCount = "100000plus";
    }
    return viewCount;
};