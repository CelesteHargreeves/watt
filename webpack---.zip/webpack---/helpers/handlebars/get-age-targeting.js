"use strict";

module.exports = function(user) {
    var age;

    if (!user || !user.age) {
        age = "UNKn";
    } else if (user.age < 15) {
        age = "13HW";
    } else if (user.age >= 15 && user.age <= 17) {
        age = "59ss";
    } else if (user.age >= 18 && user.age <= 24) {
        age = "09Pv";
    } else if (user.age >= 25 && user.age <= 34) {
        age = "68OK";
    } else if (user.age >= 35 && user.age <= 40) {
        age = "71aa";
    } else if (user.age >= 41 && user.age <= 45) {
        age = "76PT";
    } else if (user.age >= 46 && user.age <= 49) {
        age = "74xS";
    } else if (user.age >= 50 && user.age <= 54) {
        age = "68zo";
    } else if (user.age >= 55 && user.age <= 59) {
        age = "33es";
    } else if (user.age >= 60 && user.age <= 64) {
        age = "84Vv";
    } else if (user.age >= 65) {
        age = "29kM";
    } else {
        age = "UNKn";
    }

    return age;
};