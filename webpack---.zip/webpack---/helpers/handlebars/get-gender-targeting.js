"use strict";

module.exports = function(user) {
    var gender;

    if (!user || !user.gender) {
        return "Ke28";
    }

    switch (user.gender) {
        case "Male":
        case "He":
            gender = "IU10";
            break;
        case "Female":
        case "She":
            gender = "Bu44";
            break;
        default:
            gender = "Ke28";
            break;
    }

    return gender;
};