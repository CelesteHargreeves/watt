"use strict";

/*
  When given a size object from unitMeta format this function will return the largest
  width and height available.
*/
module.exports = function(sizes) {
    let largestSize, largestID;

    if (!sizes || Object.keys(sizes).length === 0)
        throw new Error("Invalid Size entered");

    for (var sizeID in sizes) {
        let dimensions = sizes[sizeID];
        let currentArea = dimensions[0] * dimensions[1];
        if (!largestSize || largestSize < currentArea) {
            largestSize = currentArea;
            largestID = sizeID;
        }
    }

    return [sizes[largestID][0], sizes[largestID][1]];
};