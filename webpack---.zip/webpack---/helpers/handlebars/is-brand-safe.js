"use strict";

var _ = require("lodash");

module.exports = function(storyGroup) {
    return _.get(storyGroup, "isBrandSafe");
};