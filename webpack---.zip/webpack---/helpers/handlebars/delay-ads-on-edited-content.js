"use strict";

const moment = require("moment");
const WAIT_PERIOD = 5;

// this helper will return true if the part, or group, that an ad is being run on has
// a modified date within WAIT_PERIOD days from now. This is, theoretically, a short term
// work around to us not being able to tell whether or not text and/or images that have
// been recently edited are brand safe for ads or not.
// if either of the models is defined, but doesn't have a modifyDate on it then we return true
// to err on the side of caution. modifyDate should always be there, so this code path should
// not be executed often.

module.exports = function(testGroups, storyGroup, storyPart) {
    if (!testGroups.DELAY_ADS) {
        return false;
    }
    if (storyPart) {
        return storyPart.modifyDate ?
            moment().diff(moment(storyPart.modifyDate), "days") < WAIT_PERIOD :
            true;
    }
    if (storyGroup) {
        return storyGroup.modifyDate ?
            moment().diff(moment(storyGroup.modifyDate), "days") < WAIT_PERIOD :
            true;
    }
    return false;
};