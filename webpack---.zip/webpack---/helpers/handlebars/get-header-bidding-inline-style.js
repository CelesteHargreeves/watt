"use strict";

var _ = require("lodash");
/**
 * Given a adzerk hb unit map, this function will return the inline styles
 * to be used by an ad placement.  If multiple ad sizes are given it will return
 * the greatest width.
 * @param {object} sizes - Size of the adzerk HB unit mapping
 * @returns {string} (Blank string for undefined sizes)
 * @returns {string} Inline style string to be injected into ad
 */
module.exports = function(sizes) {
    const errorReturn = () => {
        console.error("Ad Size not found");
        return "";
    };
    if (!sizes) {
        return errorReturn();
    }
    var keys = Object.keys(sizes);

    if (keys.length === 0) {
        return errorReturn();
    } else if (keys.length > 1) {
        var maxVal = 0;
        _.forIn(sizes, function(val) {
            if (val[0] > maxVal) {
                maxVal = val[0];
            }
        });
        return `style="width:${maxVal}px;height:auto;"`;
    } else {
        let width = sizes[keys[0]][0];
        let height = sizes[keys[0]][1];
        return `style="width:${width}px;height:${height}px;"`;
    }
};