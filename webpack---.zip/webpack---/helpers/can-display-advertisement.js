"use strict";

/**
 * CanDisplayAdvertisement
 *
 * This function determines if we should render an advertisement div.  Stories can be ad-free
 * meaning we do not show ads at all.  The 3 reasons are the parameters listed below:
 *
 * @param {Boolean} isAdExempt - is story ad exempt
 * @param {Boolean} isPaidStory - is story is a paid story
 * @param {Boolean} isPremiumUser - is the user reading a premium user
 * @returns {Boolean} canDisplayAdvertisement - True = story is not blocked from showing ads
 */

module.exports = function(isAdExempt, isPaidStory, isPremiumUser) {
    return !isAdExempt && !isPaidStory && !isPremiumUser;
};