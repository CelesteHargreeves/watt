"use strict";
var isServer = require("./is-server");

const getHybeStoryIds = () => {
    if (isServer()) {
        const configFilePath = "../server/config";
        const mod = module;
        const config = mod.require(configFilePath);
        return config.application.hybeStoryIds;
    } else {
        return window ? .wattpad ? .hybeStoryIds;
    }
};

/**
 * This function takes the provided storyId and returns if a story is a hybe story.
 *
 * @param {String} storyId The id of story to be checked
 */
module.exports = function(storyId) {
    if (typeof storyId !== "string") {
        throw new TypeError("storyId must be a string");
    }
    const hybeStoryIds = getHybeStoryIds();

    return hybeStoryIds.includes(storyId);
};