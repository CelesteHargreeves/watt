"use strict";

// client and server side utility that returns true if the ad placement is considered disabled

const disabledUnits = [
    "readinglong_bottom",
    "readinglong_bottom_loggedout",
    "readingshort_bottom",
    "readingshort_bottom_loggedout"
];

module.exports = function(placement) {
    return disabledUnits.includes(placement);
};