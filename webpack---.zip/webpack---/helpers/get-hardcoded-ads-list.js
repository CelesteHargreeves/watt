"use strict";

//
// This is list of all our hardcoded house ads, which are used in regions
// that are currently ad disabled to reduced adzerk load. To add a new
// creative, add a new entry into the array, put the files in the assets s3
// and it should just work. all the ads are weighted equally. This list is
// used for both CSR and SSR generated ads
//
const adsList = [{
        prefix: "2021_House-Ad_Premium_01",
        link: "https://www.wattpad.com/premium/?utm_source=wattpad&utm_medium=wp_advertisement&utm_campaign=mkt_premium_adfree",
        postfix: "px_V1",
        sizes: ["300x250", "300x600", "728x90"]
    },
    {
        prefix: "2021_House-Ad_Premium_02",
        link: "https://www.wattpad.com/premium/?utm_source=wattpad&utm_medium=wp_advertisement&utm_campaign=mkt_premium_offline_reading",
        postfix: "px_V1",
        sizes: ["300x250", "300x600", "728x90"]
    },
    {
        prefix: "2021_House-Ad_Premium_03",
        link: "https://www.wattpad.com/premium/?utm_source=wattpad&utm_medium=wp_advertisement&utm_campaign=mkt_premium_uninterrupted_reading",
        postfix: "px_V1",
        sizes: ["300x250", "320x50"]
    }
];

module.exports = function(width, height) {
    return adsList.filter(ad => ad.sizes.includes(`${width}x${height}`));
};