const getPlacementConfiguration = require("./ads/get-placement-configuration");
const getAdzerkTargeting = require("./handlebars/get-adzerk-targeting");
const isBrandSafe = require("./handlebars/is-brand-safe");
const isMatureStory = require("./handlebars/is-mature-story");

/**
 * ADSX-1493
 * get Adzerk Tag
 *
 * @param {string} unit - Ad Unit
 * @param {object} currentUser - Wattpad User JSON
 * @param {object} storyPart - current story part the user may be on.  This field can be blank
 * @param {object} storyGroup - the story the user is on.  This field can be blank
 * @param {object} options
 *    @param {string} ts - timestamp to attach to the ad unit to make it unique
 *    @param {string} experience - The page the current user is on
 *    @param {number} minViewportWidth - the minimum viewport this ad will run on
 *    @param {string} adText - Additional text to display with the ad eg: "Story Continue Belows"
 *    @param {string} adTextClass - css classes to apply to the adText
 *    @param {boolean} parentClass - Wraps the ad div in a parent class
 *    @param {boolean} sticky - Is ad a sticky ad
 *    @param {string} stickyStart - attaches the proper HTML attributes to make the ad sticky (parentClass required)
 *    @param {string} stickyEnd - attaches the proper HTML attributes to make the ad sticky (parentClass required)
 *    @param {string} additionalClasses - Classes to be attached to the ad
 *    @param {string} inlineStyle - css styles to be added to the ad div
 *    @param {string} translatedLabel - Translated advertisement text for screen readers
 * @returns {string} - HTML String for the ad unit that contains the divs and script required
 * for ads to run on HBS templates
 */

module.exports = function(
    unit,
    currentUser,
    storyPart,
    storyGroup,
    options = {
        ts,
        experience,
        minViewportWidth,
        adText,
        adTextClass,
        parentClass,
        additionalClasses,
        inlineStyle,
        translatedLabel
    }
) {
    const request = `${options.experience}_${unit}-${options.ts}`;
    let adzerkUnitSizes = Object.keys(getPlacementConfiguration(unit).sizes);
    const adzerkId =
        adzerkUnitSizes.length > 1 ?
        "[ " + adzerkUnitSizes.join(", ") + " ]" :
        "" + adzerkUnitSizes[0];
    let viewportString = "";
    let zoneId;
    let placementConfig = getPlacementConfiguration(unit);

    if (!adzerkId) {
        return "";
    }

    // If my works page then set zone id
    if (options.experience === "myworks") {
        zoneId = "183796";
        // TODO:  Use get-display-ad-eligibility here.
    } else if (isBrandSafe(storyGroup) && !isMatureStory(storyGroup)) {
        zoneId = "181437";
    } else {
        console.error({
            message: "Get Adzerk Error",
            zoneId,
            unit
        });
        return "";
    }

    targeting = getAdzerkTargeting(storyGroup, storyPart, currentUser);

    if (options.minViewportWidth) {
        viewportString =
            "if ( window.innerWidth < " +
            options.minViewportWidth +
            " ) { return false; }";
    }

    const adFuncBody = `/* Unit: ${unit} Zone: ${zoneId} SizeID: ${adzerkId} */ if (window.ados_add_placement) { ados_add_placement(9660, 421790, "${request}", ${adzerkId}).setZone(${zoneId}).setProperties(${JSON.stringify(
    targeting
  )});ados_setConsent({gdpr: true});ados_load(); }`;

    if (placementConfig["lazyAd"]) {
        adString = `<div id="${request}" class="advertisement lazyAd ${unit}${
      options.additionalClasses
    }" ${options.inlineStyle} data-ad-code='${adFuncBody}' aria-label="${
      options.translatedLabel
    }"></div>`;
    } else {
        adString =
            `<div id="${request}" class="advertisement ${unit}${
        options.additionalClasses
      }" ${options.inlineStyle} aria-label="${options.translatedLabel}">` +
            `<script type="text/javascript">` +
            `var ados = ados || {};` +
            `ados.run = ados.run || [];` +
            `ados.run.push( function() {` +
            `${viewportString}` +
            `${adFuncBody}` +
            `});` +
            `</script>` +
            `</div>`;
    }

    if (options.parentClass) {
        let adTextTemplate = options.adText ?
            `<h4 class="${options.adTextClass}">${options.adText}</h4>` :
            "";

        if (placementConfig ? .stickyAd) {
            adString = `<div class="${options.parentClass}" data-start-selector="${
        placementConfig.stickyStart
      }" data-end-selector="${placementConfig.stickyEnd}}">
        ${adTextTemplate}${adString}
      </div>`;
        } else {
            adString = `<div class="${
        options.parentClass
      }">${adTextTemplate}${adString}</div>`;
        }
    }

    return adString;
};