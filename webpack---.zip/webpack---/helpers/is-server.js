module.exports = function() {
    return typeof window === "undefined";
};