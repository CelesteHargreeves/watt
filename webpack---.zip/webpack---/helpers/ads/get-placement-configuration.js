"use strict";

var isServer = require("../is-server");

/**
 * ADSX-1773
 * getPlacmentConfiguration
 *
 * @param {string} placement - The identifier for the placement you want a configuration for
 * @returns {object} - returns the entry in the sites ad configuration for the ad placement
 */

const serverConfig = () => {
    const configFilePath = "../../server/config";
    const mod = module;
    const config = mod.require(configFilePath);

    return config.application.adzerkHeaderBiddingUnitMap;
};

const config = isServer() ?
    serverConfig() :
    window.wattpad.adzerkHeaderBiddingUnitMap;

module.exports = function(placement) {
    return config[placement];
};