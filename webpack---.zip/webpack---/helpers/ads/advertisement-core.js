"use strict";

var _ = require("lodash"),
    getHardcodedAdString = require("../handlebars/get-hardcoded-ad-string"),
    isAdPlacementDisabled = require("../is-ad-placement-disabled"),
    delayAdsOnEditedContent = require("../handlebars/delay-ads-on-edited-content"),
    getPrebidAdString = require("../handlebars/get-prebid-ad-string"),
    getDisplayAdEligibility = require("../get-display-ad-eligibility"),
    getAdSize = require("../handlebars/get-ad-size"),
    canDisplayAdvertisement = require("../can-display-advertisement"),
    getAdzerkTag = require("../get-adzerk-tag"),
    getPlacementConfiguration = require("../ads/get-placement-configuration"),
    getHeaderBiddingInlineStyle = require("../handlebars/get-header-bidding-inline-style");

module.exports = function(
    unit,
    options,
    currentUser,
    root,
    translatedLabel,
    testGroups
) {
    var isAdExempt,
        storyPart,
        isPaidContentStory = false,
        shouldShowAds;

    // options
    var opts = options ? .hash ? ? null,
        placementConfig = getPlacementConfiguration(unit),
        adFree = currentUser ? .isPremium || false,
        experience = opts ? .experience ? .toLowerCase(),
        ts = opts.timestamp || Date.now(),
        storyGroup = opts.storyGroup,
        parentClass =
        (opts.parentClass || "") +
        (placementConfig ? .stickyAd ? " sticky-ad" : ""),
        adText = opts.adText || "",
        adTextClass =
        opts.adTextClass ||
        "center-text small text-uppercase light hidden-lg hidden-md",
        minViewportWidth = opts.minViewportWidth,
        additionalClasses = opts ? .additionalClasses || "",
        inlineStyle = getHeaderBiddingInlineStyle(placementConfig ? .sizes);

    if (!unit || !placementConfig || !opts) {
        return "";
    }

    // Story Landing/Reading specific key-value pairs
    if (storyGroup) {
        isAdExempt = _.get(storyGroup, "isAdExempt");

        // MON-627: no ads on paid stories
        isPaidContentStory = _.get(storyGroup, "isPaywalled", false);

        if (experience === "reading") {
            storyPart = root;
        }
    }

    // WEB-7661: Ad-Free Experience
    // Or for branded stories that should be ad free
    // Or for paid stories (no ads on any part as long as a single part is paid)
    if (!canDisplayAdvertisement(isAdExempt, isPaidContentStory, adFree)) {
        return "";
    }

    shouldShowAds = getDisplayAdEligibility(storyPart, storyGroup, testGroups);

    // Hard coded House Ads
    //
    // If this ad should not be rendered through our normal header bidding stack, then
    // it should be detected here, and a hardcoded house ad will be displayed
    if (
        isAdPlacementDisabled(unit) ||
        delayAdsOnEditedContent(testGroups, storyGroup, storyPart)
    ) {
        let [width, height] = getAdSize(placementConfig.sizes);
        return getHardcodedAdString(unit, {
            additionalClasses: additionalClasses,
            adText: adText,
            adTextClass: adTextClass,
            height: height,
            inlineStyle: inlineStyle,
            parentClass: parentClass,
            ts: ts,
            width: width
        });
    }

    if (shouldShowAds) {
        if (placementConfig["adzerkOnly"]) {
            //WEB-7887: Myworks page unit
            return getAdzerkTag(unit, currentUser, storyPart, storyGroup, {
                ts,
                experience,
                minViewportWidth,
                adText,
                adTextClass,
                parentClass,
                additionalClasses,
                inlineStyle,
                translatedLabel
            });
        } else {
            try {
                return getPrebidAdString(unit, {
                    additionalClasses: additionalClasses,
                    adText: adText,
                    adTextClass: adTextClass,
                    label: translatedLabel,
                    parentClass: parentClass,
                    shouldShowAds: shouldShowAds,
                    ts: ts,
                    ...placementConfig
                });
            } catch (error) {
                console.log("Failed to get prebid ad string");
                console.log(error);
                return "";
            }
        }
    }

    return "";
};