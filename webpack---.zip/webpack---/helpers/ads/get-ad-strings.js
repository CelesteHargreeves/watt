"use strict";

/**
 * Generates the adUnit as well as any additional classes
 * since they're based on a similar set of variables
 * @param {string} position - where the ad is located i.e. 'top', 'bottom', 'comments'
 * @param {object} options - options passed in whence this was called
 */
module.exports = function(position, options) {
    // check some vars
    let contentLength = options.source ? .attributes.length;
    let isMicroPart =
        options.source ? .attributes.isMicroPart ||
        options.source ? .attributes.pages < 2;
    let isLoggedOut =
        options.source ? .attributes.anonymousUser || wattpad.user === null;
    let isMobile = app.get("device").is.mobile;

    let adUnitString = `reading${isMicroPart ? "short" : "long"}_` +
        `${position}` +
        `${isLoggedOut ? "_loggedout" : ""}` +
        `${isMobile ? "_mweb" : ""}`; // prettier-ignore

    return {
        adUnit: adUnitString,
        classes: isMicroPart && contentLength > 1500 ? "longer-micro-part" : ""
    };
};