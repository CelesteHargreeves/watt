(function(window, app) {
    "use strict";

    app.router.add({
        notifications: ["notifications", {}]
    });
})(window, window.app);