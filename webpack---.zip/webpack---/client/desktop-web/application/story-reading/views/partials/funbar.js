import tableOfContents from "platform/story-reading/templates/table-of-contents.hbs";
(function(window, wattpad, utils, app, Monaco) {
    "use strict";
    app.add(
        "StoryReadingFunbar",
        app.views.BaseStoryReadingFunbar.extend({
            isDesktop: true,

            events: {
                "mouseenter #funbar-reading-progress": "openProgressTooltip",
                "mouseleave #funbar-reading-progress": "closeProgressTooltip",
                "tap .on-publish": "onPublish",
                "click .on-publish": "stopEvent"
            },

            initialize: function() {
                Handlebars.registerPartial(
                    "desktop.story_reading.table_of_contents",
                    tableOfContents
                );
                app.views.BaseStoryReadingFunbar.prototype.initialize.apply(
                    this,
                    arguments
                );
            },

            render: function() {
                var data = this.model.toJSON(),
                    self = this;

                this.listenTo(this.model, "reading-progress", this.updateProgress);
                this.listenTo(this.model, "change:pageNumber", this.pageChanged);

                data.showAdminPanel = false;
                data.isAdmin = false;
                data.isDesktop = this.isDesktop;

                if (wattpad.utils.currentUser().get("isSysAdmin")) {
                    data.showAdminPanel = true;
                    data.isAdmin = true;
                }

                if (wattpad.utils.currentUser().get("ambassador")) {
                    data.showAdminPanel = true;
                }

                if (
                    wattpad.utils.currentUser().get("username") ===
                    data.group.user.username
                ) {
                    data.isAuthor = true;
                    data.group.url =
                        "/myworks/" + data.group.id + "-" + utils.slugify(data.group.title);
                }

                data.isPreview = this.options ? this.options.isPreview : false;

                var blockedPart = data.blockedPart || {};
                const isPaywalled = this.model.get("group").isPaywalled;
                if (isPaywalled) {
                    data.onWalletClick = utils.showBuyCoinsModal.bind(
                        utils,
                        "reading",
                        data.group.id,
                        blockedPart.id
                    );
                }

                this.$el.html(this.template(data));
                this.initAdminPanel(this.model, "#admin-panel");
                _.defer(function() {
                    self.$("[data-toggle=tooltip]").tooltip();
                });
                return this;
            },

            stopEvent: function(evt) {
                utils.stopEvent(evt);
            },

            //For the LibraryManagement mixin
            onAddToListsReady: function($btn, storyId) {
                var btnGrp = $btn.parent(".button-group");

                btnGrp.addClass("open");
                $btn.removeClass("on-lists-add-clicked");
                $btn.addClass("on-dismiss-lists");
            },

            onDismissLists: function(evt) {
                var storyId = $(evt.currentTarget).data("story-id"),
                    btn = this.$(this.addButton + "[data-story-id='" + storyId + "']"),
                    btnGrp = btn.parent(".button-group");

                btnGrp.removeClass("open");
                btn.removeClass("on-dismiss-lists");
                btn.addClass("on-lists-add-clicked");
            },

            openProgressTooltip: function(evt) {
                this.$("#progresstooltip").tooltip("show");
            },

            closeProgressTooltip: function(evt) {
                this.$("#progresstooltip").tooltip("hide");
            },

            _timeToComplete: function(numWords, percentDone) {
                var wordsLeft = numWords * (1 - percentDone),
                    wordsPerMinute = 250,
                    timeLeft = wordsLeft / wordsPerMinute; // minutes

                return moment.duration(timeLeft, "minutes").humanize();
            },

            updateProgress: function(percent) {
                // minimum CSS width of 0.5% so the progress bar is always visible
                if (percent * 100 > 0.5) {
                    this.$("#progressbar").width(percent * 100 + "%");
                } else {
                    this.$("#progressbar").removeAttr("style");
                }

                var words = this.model.get("wordCount");
                if (words && percent !== 1) {
                    var timeLeft = wattpad.utils.trans(
                        "%s left",
                        this._timeToComplete(words, percent)
                    );
                    this.$("#progresstooltip").attr("data-original-title", timeLeft);
                } else {
                    this.$("#progresstooltip").removeAttr("data-original-title");
                }
            },

            pageChanged: function() {
                this.openProgressTooltip();
                _.delay(_.bind(this.closeProgressTooltip, this), 1000);
            },

            showPostPublishModal: function() {
                var self = this;
                var postPublishModal = new app.views.PostPublishModal({
                    model: self.model,
                    links: self.model.get("socialShareVisible") || app.currentView.socialLinks
                });
                $("#post-publish-modal")
                    .empty()
                    .append(postPublishModal.render().$el);
                postPublishModal.showModal();
            },

            onPublish: function() {
                var self = this,
                    errors = [];

                var storyModel = this.model.get("group");
                //set the textids
                storyModel.textids = _.pluck(this.model.get("group").parts, "id").join(
                    ","
                );

                this.publishModel = new app.models.StoryPartCreateModel({
                    id: this.model.get("id"),
                    authorid: utils.currentUser().get("id"),
                    title: this.model.get("title"),
                    groupid: this.model.get("group").id,
                    language: this.model.get("language"),
                    copyright: this.model.get("copyright"),
                    category1: this.model.get("group").categories[0],
                    textUrl: this.model.get("text_url"),
                    url: this.model.get("url")
                });

                var labelsFetch = [];

                this.storyLabelsModel = new app.models.StoryLabelsModel({
                    storyId: parseInt(storyModel.id)
                });

                labelsFetch = Promise.resolve(this.storyLabelsModel.fetch()).catch(
                    function() {}
                ); // Do nothing; no characters or target audience for this story

                Promise.all([
                    $.get("/apiv2/storytext?id=" + this.model.get("id") + "&output=json"),
                    labelsFetch
                ]).then(function(results) {
                    self.publishModel.set("text", results[0] ? .text);
                    self.publishModel.set("last_text_hash", results[0] ? .text_hash);

                    if (!storyModel.category ||
                        storyModel.title === "" ||
                        storyModel.title === utils.trans("Untitled Story") ||
                        storyModel.description === "" ||
                        storyModel.tags.length === 0
                    ) {
                        var publishView = new app.views.WorksItemDetails({
                            model: new app.models.StoryCreateModel(storyModel),
                            storyLabelsModel: self.storyLabelsModel || null,
                            isPublish: true,
                            partModel: self.publishModel,
                            isPreview: true
                        });
                        $("#generic-modal")
                            .find(".modal-content .modal-body")
                            .html(publishView.render().$el);
                        $("#generic-modal")
                            .addClass("publish-modal")
                            .modal("show");
                    } else {
                        Promise.resolve(self.publishModel.publish()).then(function(result) {
                            var currentUsername = utils.currentUser().get("username");

                            // if the following is true, the save xhr was likely aborted
                            if (result === undefined && errors.length === 0) {
                                return;
                            }

                            app.local.clear(self.model.resource());
                            utils.cacheBust(["Works"], [{
                                username: currentUsername
                            }]);
                            utils.cacheBust(
                                ["Works"], [{
                                    username: currentUsername,
                                    published: true
                                }]
                            );
                            $(".draft-tag").addClass("hidden");
                            $(".on-publish").addClass("hidden");
                            $(".on-write").addClass("hidden");
                            $(".preview-alert").addClass("hidden");

                            self.showPostPublishModal();
                        });
                    }
                });
            }
        })
    );

    app.mixin(app.views.StoryReadingFunbar, "StoryAdminManager");
})(window, wattpad, wattpad.utils, window.app, window.Monaco);