(function(window, app) {
    "use strict";

    // AUDI-830/822 user settings page (replacing /user_profile php page)
    app.router.add({
        "settings(/)": ["user_settings", {}]
    });
})(window, window.app);