(function(window, wattpad, app) {
    "use strict";

    app.router.on(
        "route:featured_picks",
        app.router.filter(["getTranslations", "getCategories"], function(listId) {
            var model = new app.models.ReadingList({
                id: listId
            });

            Promise.all([model.fetch()])
                .then(function() {
                    var view = new app.views.FeaturedPicks({
                        model: model
                    });

                    app.transitionTo(view, {
                        hasHeader: true,
                        hasFooter: true
                    });

                    window.te.push("event", "app", "page", null, "view", {
                        page: "featured",
                        reading_listid: listId
                    });
                })
                .catch(function(err) {
                    console.error(err);
                });
        })
    );
})(window, wattpad, window.app);