(function(window, _, $, wattpad, app) {
    "use strict";

    app.router.on(
        "route:authentication",
        app.router.filter(["getTranslations"], function(page) {
            page = page || "signup";

            let authToken = new URLSearchParams(window.location.search).get("at");

            if (wattpad.utils.isHttp()) {
                wattpad.utils.redirectToServer(window.location.href);
            } else {
                var authenticationView;

                if (page === "signup") {
                    authenticationView = new app.views.Landing({
                        model: new app.models["Auth" + page]({}),
                        page: page
                    });
                } else {
                    authenticationView = new app.views.Authentication({
                        model: new app.models["Auth" + page]({}),
                        page: page,
                        authToken: authToken
                    });
                }

                app.transitionTo(authenticationView, {
                    hideAddressBar: false,
                    hasHeader: false,
                    hideAnnouncements: true
                });
            }
        })
    );

    app.router.on(
        "route:oauth-auth",
        app.router.filter(["getTranslations"], function(page) {
            const data = JSON.parse(wattpad.utils.getParam("data"));
            const preservedVal = {
                email: data.email,
                token: data.token,
                type: data.type,
                username: data.username
            };
            const authView = new app.views.OauthAuthentication({
                model: new app.models.Authsignup({}),
                preservedVal,
                errorMsg: data.errorMsg
            });
            app.transitionTo(authView, {
                hideAddressBar: false,
                hasHeader: false,
                hideAnnouncements: true
            });
        })
    );
})(window, _, jQuery, wattpad, window.app);