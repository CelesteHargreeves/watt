(function(window, wattpad, app) {
    "use strict";

    wattpad = wattpad || (window.wattpad = {});

    app.router.on(
        "route:storyLanding",
        app.router.filter(["getTranslations", "getCategories"], function(
            storyId,
            slug,
            section,
            params
        ) {
            if (isNaN(parseInt(storyId))) {
                app.router.trigger("route:error-404", "story");
                return;
            }

            // WEB-7096 If the params is an object it contains redirectFrom, it means we need to show the toast
            if (
                typeof params === "object" &&
                (params["redirectfrom"] || params["redirectFrom"])
            ) {
                var toast = new app.views.ErrorToast({
                    message: wattpad.utils.trans(
                            "We're sorry! The page you requested no longer exists."
                        ) +
                        " " +
                        wattpad.utils.trans("So we have brought you to a related page.")
                }, {
                    type: "dismissable"
                });
                toast.render();
            }

            var model = new app.models.StoryModel({
                id: storyId,
                checkPromotionStatus: wattpad.utils.eligibleForDirectSoldAds() &&
                    !wattpad.utils.currentUser().get("isPremium"),
                zoneIds: [127423]
            });

            let modelFetch = Promise.all([
                Promise.resolve(
                    model.fetch({
                        data: {
                            include_deleted: wattpad.utils.currentUser().get("isSysAdmin") ||
                                wattpad.utils.currentUser().get("ambassador")
                        }
                    })
                ),
                Promise.resolve(
                    wattpad.utils
                    .currentUser()
                    .library()
                    .loaded()
                )
            ]);

            if (wattpad.testGroups.PAID_CONTENT) {
                modelFetch = modelFetch.then(() => {
                    if (!model.get("isPaywalled")) {
                        return;
                    }

                    const storyId = model.get("id");
                    const partIds = model.get("parts").map(p => p.id);
                    return window.store.dispatch(
                        window.app.components.actions.fetchPaidContentMetadata(
                            storyId,
                            partIds
                        )
                    );
                });
            }

            modelFetch.then(
                function() {
                    // ADS-885: Ads Pageview Event
                    if (typeof __atha !== "undefined") {
                        var id = __atha.sendPageView(
                            "storylanding",
                            parseInt(model.get("id"), 10),
                            undefined,
                            model.attributes
                        );
                        model.set("pageviewId", id);
                    }

                    var view = new app.views.StoryLanding({
                        model: model,
                        section: section
                    });
                    var title =
                        model.get("title") +
                        (model.get("user") ? " - " + model.get("user").name : "");

                    // Vietnamese is special-cased to deal with scrapers with good SEO
                    var lang = parseInt(app.get("language"), 10);
                    if (lang === 19) {
                        title =
                            "Đọc Truyện " +
                            model.get("title") +
                            " - " +
                            model.get("user").name +
                            " - Wattpad";
                    }

                    const noIndex = model.get("noIndex");
                    app.transitionTo(view, {
                        pageTitle: wattpad.utils.unsanitizeHTML(title),
                        hasHeader: true,
                        hasFooter: true,
                        noIndex: noIndex
                    });

                    const shouldSeeOnboarding = wattpad.utils.shouldSeePaidOnboarding(
                        model.get("isPaywalled")
                    );
                    if (shouldSeeOnboarding) {
                        const storyId = model.get("id");
                        wattpad.utils.showPaidOnboardingAfterDelay(storyId);
                    }

                    window.te.push("event", "story_details", null, null, "view", {
                        storyid: storyId
                    });

                    window.te.push("event", "app", "page", null, "view", {
                        page: "story_details",
                        storyid: storyId
                    });
                },
                function() {
                    //  error handling
                    params = params || {};
                    app.router.trigger("route:error-404", "story", storyId);
                }
            );
        })
    );
})(window, wattpad, window.app);