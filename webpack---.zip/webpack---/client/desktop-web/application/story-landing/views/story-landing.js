import storiesSimilar from "core/templates/collection-views/stories-similar.hbs";
import addToLibraryDropdown from "core/templates/components/add-to-library-dropdown.hbs";
import shareEmbed from "platform/components/templates/modal/share-embed.hbs";
import storyLanding from "platform/story-landing/templates/story-landing.hbs";
(function(window, wattpad, utils, app, Monaco) {
    "use strict";
    app.add(
        "StoryLanding",
        app.views.RegionManager.extend({
            template: storyLanding,

            partials: {
                "core.story_landing.story_details": function() {
                    return "";
                },
                "core.story_landing.story_parts": function() {
                    return "";
                },
                "core.collection_views.stories_similar": function() {
                    return "";
                },
                "core.signup_prompt": function() {
                    return "";
                },
                "desktop.components.item_views.user_item": function() {
                    return "";
                },
                "desktop.components.modal.share_embed": shareEmbed,
                "core.components.add_to_library_dropdown": addToLibraryDropdown
            },

            events: {
                "tap   .on-tab-nav": "onSectionNavigate",
                "click .on-tab-nav": "stopEvent",

                "tap .on-story-navigate": "onStoryNavigate",
                "click .on-story-navigate": "stopEvent",

                "tap    .on-dismiss-lists": "onDismissLists",
                "click  .on-dismiss-lists": "stopEvent",

                "tap .share-embed": "onShareEmbed",
                "click .share-embed": "stopEvent",

                "tap .on-sponsor-navigate": "onSponsorNavigate",
                "click .on-sponsor-navigate": "stopEvent",

                "tap .send-author-event": "sendAuthorClickTrackingEvent",
                "click .send-author-event": "stopEvent",

                "tap .send-story-cover-event": "sendSimilarStoryCoverTrackingEvent",
                "click .send-story-cover-event": "stopEvent"
            },

            regionTags: {
                details: "#story-details",
                content: "#tab-content",
                similar: ".similar-stories",
                promoted: ".promoted-stories",
                signup: "#authentication-panel"
            },

            id: "story-landing",

            subviews: {
                details: {
                    view: app.views.StoryDetails
                },
                similar: {
                    view: app.views.StoriesSimilar
                },
                signup: {
                    view: app.views.SignUpPrompt
                },
                promoted: {
                    view: app.views.PromotedStoryItem
                },

                parts: {
                    view: app.views.StoryParts
                }
            },

            initialize: function(options) {
                var matchMedia = window.matchMedia || window.msMatchMedia,
                    options = options || {},
                    mql;

                this.section = options.section || "parts";

                _.bindAll(this, "clearLists");

                _.each(this.partials, function(value, key, list) {
                    Handlebars.registerPartial(key, value);
                });

                //Reduce to 1 category
                //TODO: Make this code assume 1 category when platform completely kills
                //the second category
                this.model.set("categories", [
                    _.find(this.model.get("categories"), function(category) {
                        return category > 0;
                    })
                ]);

                // categoryLabels needed for social-sharing mixin
                this.model.set(
                    "categoryLabels",
                    _.reduce(
                        this.model.get("categories"),
                        function(models, cat) {
                            var search = app.get("categories").get(cat);
                            if (search) {
                                models.push({
                                    name: search.get("name"),
                                    name_english: search.get("name_english")
                                });
                            }
                            return models;
                        }, []
                    )
                );

                // listens for changes in the viewport size so that the `Details` section will never
                // be the active section in viewport sizes that do not display it.
                if (matchMedia) {
                    _.bindAll(this, "onWidthChange");
                    mql = matchMedia("( min-width: 992px )");
                    mql.addListener(this.onWidthChange);
                }

                this.listenTo(
                    this.model,
                    "reading-position-available",
                    this.onPositionAvailable
                );
                this.listenTo(
                    app,
                    "app:component:TagGridItem:click",
                    this.navigateToTagPage
                );
            },

            onPositionAvailable: function(data) {
                //Update Read/Continue Reading button
                if (
                    (data && data.part !== this.model.get("firstPartId")) ||
                    data.position > 0
                ) {
                    var storyPart = _.find(this.model.get("parts"), function(part) {
                        return part.id === data.part;
                    });
                    if (storyPart) {
                        this.$(".story-controls > .on-story-navigate")
                            .text(wattpad.utils.trans("Continue"))
                            .attr("href", wattpad.utils.formatStoryUrl(storyPart.url));
                    }
                }
            },

            navigateToTagPage: function(evt) {
                var tag = $(evt.currentTarget)
                    .text()
                    .trim(),
                    urlPath = "/stories/";

                window.te.push("event", "story_details", "tag", null, "click", {
                    storyid: this.model.get("id"),
                    tags: tag
                });

                app.router.navigate(urlPath + encodeURIComponent(tag), {
                    trigger: true
                });
            },

            setElement: function(el) {
                Monaco.View.prototype.setElement.apply(this, arguments);

                _.each(
                    this.regionTags,
                    function(regionTag) {
                        if (this.regions[regionTag] && this.regions[regionTag].view) {
                            if (this.$(regionTag).length > 0) {
                                this.regions[regionTag].view.setElement(
                                    $(this.$(regionTag + " > div"))
                                );
                            }
                        }
                    },
                    this
                );
            },

            writerPreviewHasBannedCover: function() {
                return (
                    wattpad.utils.currentUser() &&
                    this.model.get("hasBannedCover") &&
                    this.model.get("user").username ===
                    wattpad.utils.currentUser().get("username")
                );
            },

            render: function() {
                //TODO Fix double render
                var data = {},
                    self = this,
                    device = app.get("device");

                this.descCharLimit = device.is.desktop ? 170 : 130;

                data.story = this.model.toJSON();
                data.story.firstPart = _.find(data.story.parts, function(part) {
                    return part.id === data.story.firstPartId;
                });
                data.tagGridTags = {
                    tags: []
                };
                _.each(this.model.get("tags"), function(tag) {
                    data.tagGridTags.tags.push({
                        id: tag,
                        name: tag
                    });
                });

                if (data.story.promoted) {
                    //always use author name as fallback when sponsor name is not defined
                    data.story.sponsorName =
                        data.story.sponsorName || data.story.user.username;
                }

                var socialLinks = this.buildSocialShareLinksForStory(this.model);
                data.socialShareHidden = socialLinks.splice(3, 3);
                data.socialShareVisible = socialLinks;
                data.active = {};
                data.active[this.section] = true;
                data.isLogged = wattpad.utils.currentUser().authenticated();
                data.descCharLimit = this.descCharLimit;

                data.showAdminPanel =
                    wattpad.utils.currentUser().get("isSysAdmin") ||
                    wattpad.utils.currentUser().get("ambassador");
                data.isAdmin = wattpad.utils.currentUser().get("isSysAdmin");
                data.writerPreviewHasBannedCover = this.writerPreviewHasBannedCover();
                //set cookie for signupForm
                wattpad.utils.setCookie(
                    "signupFrom",
                    "story_landing",
                    0,
                    window.location.hostname.replace("www", "")
                );

                const paidContentEnabled =
                    _.get(window, "wattpad.testGroups.PAID_CONTENT") || false;
                if (paidContentEnabled && data.story.isPaywalled) {
                    const {
                        paidMetadata
                    } = window.store.getState();
                    data.story.parts = utils.markBlockedParts(
                        paidMetadata,
                        data.story.parts
                    );
                    data.story.isPaidPreview = utils.isPaidPreview(data.story.parts);
                }

                this.$el.html(this.template(data));
                this.setMain();
                this.setSection(this.section);

                //For the continue button...if we land on TOC, TOC will call this
                if (
                    wattpad.utils.currentUser().authenticated() &&
                    this.section !== "parts"
                ) {
                    this.model.syncPosition();
                }

                _.defer(function() {
                    self
                        .$(".author-info")
                        .children("small")
                        .tooltip();
                    self
                        .$(".meta")
                        .children("span")
                        .tooltip();
                    self.$(".story-details [data-toggle=tooltip]").tooltip();
                    self.initAdminPanel(self.model, "#admin-panel");
                });

                return this;
            },

            setMain: function() {
                //Story Landing Details
                //We need to clear it as we registered empty partials in the DOM
                this.$(this.regionTags.details).empty();
                var view = new this.subviews.details.view({
                    model: this.model
                });
                this.setRegion(this.regionTags.details, view.render());

                //Story Landing Similar Stories
                //We need to clear it as we registered empty partials in the DOM
                if (!this.model.get("deleted")) {
                    this.$(this.regionTags.promoted).empty();

                    this.promotedStoryView = new this.subviews.promoted.view({
                        storyId: this.model.get("id"),
                        baseStoryCategory: this.model.get("categories")[0],
                        zoneIds: [170406],
                        template: storiesSimilar,
                        fromPage: "storyLanding",
                        descCharLimit: this.descCharLimit,
                        promotedEl: ".promoted-story-panel"
                    });

                    var self = this;
                    _.defer(function() {
                        self.setRegion(
                            self.regionTags.promoted,
                            self.promotedStoryView.render()
                        );
                    });

                    this.$(this.regionTags.similar).empty();
                    view = new this.subviews.similar.view({
                        filter: "similar",
                        storyId: this.model.get("id"),
                        limit: 10,
                        showDescription: true
                    });
                    this.setRegion(this.regionTags.similar, view.render());
                }

                //Signup Prompt for logged out users
                this.$(this.regionTags.signup).empty();
                if (!wattpad.utils.currentUser().authenticated()) {
                    var firstPartId = this.model.get("firstPartId");
                    var firstStoryPart = _.find(this.model.get("parts"), function(part) {
                        return part.id === firstPartId;
                    });

                    view = new this.subviews.signup.view({
                        model: new app.models.Authsignup(),
                        subtitle: wattpad.utils.trans(
                            "Get notified when %s is updated",
                            "<strong>" +
                            wattpad.utils.sanitizeHTML(this.model.get("title")) +
                            "</strong>"
                        ),
                        nextUrlFirstPart: (firstStoryPart && firstStoryPart.url) || null,
                        libraryStoryId: this.model.get("id")
                    });
                    this.setRegion(this.regionTags.signup, view.render());
                }
            },

            setSection: function(newSection) {
                var view,
                    $pageNav = this.$("#story-tabs"),
                    url;

                $pageNav.find("nav li").removeClass("active");
                $pageNav
                    .find("nav li[data-section=" + newSection + "]")
                    .addClass("active");

                if (this.section !== newSection) {
                    this.clearRegion(this.regionTags.content);

                    url = window.location.pathname;
                    url =
                        newSection === "parts" ? url + "/parts" : url.replace("/parts", "");
                    app.router.navigate(url, {
                        trigger: false,
                        replace: true
                    });
                }

                if (
                    this.section !== newSection ||
                    !this.regions[this.regionTags.content]
                ) {
                    switch (newSection) {
                        case "parts":
                            view = new this.subviews.parts.view({
                                model: this.model
                            });
                            break;
                        case "details":
                            view = new this.subviews.details.view({
                                model: this.model
                            });
                            break;
                        default:
                            break;
                    }

                    this.setRegion(this.regionTags.content, view.render());
                    this.section = newSection;
                }
            },

            // Event Handlers
            onSectionNavigate: function(e) {
                var $target = $(e.currentTarget),
                    section = $target.parent().data("section");
                this.setSection(section);
            },

            onStoryNavigate: function(e) {
                window.te.push("event", "story_details", "story", null, "read", {
                    storyid: this.model.get("id")
                });
                this.onNavigate(e);
            },

            onWidthChange: function(mq) {
                if (mq.matches && this.section === "details") {
                    this.setSection("parts");
                }
            },

            onSponsorNavigate: function(evt) {
                var url = $(evt.target).data("clickUrl");
                $.ajax({
                    type: "GET",
                    url: url
                });
                this.onNavigate(evt);
            },

            buildSocialShareLinksForStory: function(model) {
                return [{
                    name: "embed",
                    icon: "fa-code",
                    nopopup: true,
                    label: wattpad.utils.trans("Embed Story"),
                    href: wattpad.utils.sprintf("https://embed.wattpad.com/story/%s", [
                        model.get("id")
                    ])
                }];
            },

            //For the LibraryManagement mixin
            onAddToListsReady: function($btn, storyId) {
                this.clearLists();
                var btnGrp = $btn.parents(".button-group");
                btnGrp.addClass("open");
                $btn.removeClass("on-lists-add-clicked");
                $btn.addClass("on-dismiss-lists");

                $(window.document).one("click.bs.dropdown.data-api", this.clearLists);
            },

            //Custom dropdown dismiss behaviour
            clearLists: function(event) {
                var listClicked = false;

                if (event && event.which === 3) {
                    return false;
                }

                var $el = null;
                if (event) {
                    $el = $(event.target);
                }

                var btns = $(".btn-story-lists");
                _.each(btns, function(btn) {
                    var $btn = $(btn);
                    if (!$el || $btn.parents(".button-group").find($el).length === 0) {
                        $btn.parents(".button-group").removeClass("open");
                        $btn.removeClass("on-dismiss-lists");
                        $btn.addClass("on-lists-add-clicked");
                    } else if ($el) {
                        listClicked = true;
                    }
                });

                if (listClicked) {
                    $(window.document).one("click.bs.dropdown.data-api", this.clearLists);
                }
                return true;
            },

            onDismissLists: function(event) {
                var $btn = $(event.currentTarget);

                $btn.parents(".button-group").removeClass("open");
                $btn.removeClass("on-dismiss-lists");
                $btn.addClass("on-lists-add-clicked");
            },

            onShareEmbed: function(event) {
                var modal = $("#generic-modal");
                var self = this;

                utils.stopEvent(event);

                modal
                    .find(".modal-dialog")
                    .addClass("embed")
                    .find(".modal-body")
                    .html(
                        this.partials["desktop.components.modal.share_embed"]({
                            id: this.model.get("id"),
                            close: true
                        })
                    );

                var $embedCode = modal
                    .find(".on-select")
                    .on("tap", this.onSelectEmbedUrl);

                var $iframe = modal.find("iframe");
                $iframe.attr("src", $iframe.data("href"));

                var cleanup = function() {
                    $embedCode.off("tap", self.onSelectEmbedUrl);
                    modal.off("hide.bs.modal", cleanup);
                };

                modal.modal("show").on("hide.bs.modal", cleanup);
            },

            onSelectEmbedUrl: function() {
                var range = window.document.createRange();
                range.selectNode(window.document.getElementById("embed-url"));
                window.getSelection().addRange(range);
            },

            onSocialShareSelected: function(evt) {
                window.te.push("event", "story_details", "story", null, "share", {
                    storyid: this.model.get("id"),
                    channel: $(evt.currentTarget).data("share-channel")
                });
            },

            sendAuthorClickTrackingEvent: function() {
                window.te.push("event", "story_details", "author", "", "click", {
                    storyid: this.model.get("id"),
                    username: this.model.get("user").username
                });
            },

            sendSimilarStoryCoverTrackingEvent: function(evt) {
                window.te.push(
                    "event",
                    "story_details",
                    "similar_stories",
                    "cover",
                    "click", {
                        storyid: $(evt.currentTarget).data("story-id"),
                        current_storyid: this.model.get("id")
                    }
                );
            }
        })
    );

    app.mixin(
        app.views.StoryLanding,
        "StoryInListsManagement",
        "SocialSharing",
        "StoryAdminManager"
    );
})(window, wattpad, wattpad.utils, window.app, window.Monaco);