import storyParts from "core/templates/story-landing/story-parts.hbs";
(function(window, _, wattpad, app, utils) {
    "use strict";
    app.add(
        "StoryParts",
        app.views.Base.extend({
            template: storyParts,

            className: "story-parts",

            events: {
                "tap .on-navigate-part": "onNavigatePart",
                "click .on-navigate-part": "stopEvent"
            },

            initialize: function(options) {
                this.listenTo(
                    this.model,
                    "reading-position-available",
                    this.onPositionAvailable
                );
            },

            onPositionAvailable: function(data) {
                if (
                    (data && data.part !== this.model.get("firstPartId")) ||
                    data.position > 0
                ) {
                    //Update table of contents
                    var partEntry = this.$el.find("li[data-part-id='" + data.part + "']");
                    var anchor = $(partEntry).children("a");
                    var text = wattpad.utils.trans(
                        "%s%% Read",
                        (data.position * 100).toFixed(2)
                    );

                    partEntry.addClass("active");
                    anchor.children().remove();
                    anchor.append('<small class="pull-right">' + text + "</small>");
                }
            },

            render: function() {
                var data = {};
                data.story = this.model.toJSON();
                data.story.parts = this.model.get("parts");

                const paidContentEnabled =
                    _.get(window, "wattpad.testGroups.PAID_CONTENT") || false;
                if (paidContentEnabled && data.story.isPaywalled) {
                    const {
                        paidMetadata
                    } = window.store.getState();
                    data.story.parts = utils.markBlockedParts(
                        paidMetadata,
                        data.story.parts
                    );
                }

                data.story.numParts = this.model.get("numParts");
                this.$el.html(this.template(data));

                if (wattpad.utils.currentUser().authenticated()) {
                    this.model.syncPosition();
                }
                return this;
            },

            onNavigatePart: function(e) {
                this.onNavigate(e);
            }
        })
    );
})(window, _, wattpad, window.app, wattpad.utils);