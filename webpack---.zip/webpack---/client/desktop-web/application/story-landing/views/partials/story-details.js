import storyDetails from "core/templates/story-landing/story-details.hbs";
(function(window, _, wattpad, app) {
    "use strict";
    app.add(
        "StoryDetails",
        app.views.Base.extend({
            template: storyDetails,

            className: "story-details",

            events: {
                "tap .on-ranking-navigate": "onRankingNavigate",
                "click .on-ranking-navigate": "stopEvent"
            },

            render: function() {
                var data = {
                    story: this.model.toJSON()
                };

                data.reportUrl =
                    "/help/content?message=" +
                    wattpad.utils.urlEncode("I am reporting the following content:\n") +
                    "&story_link=" +
                    wattpad.utils.urlEncode(window.location.href);

                if (data.story.sourceLink) {
                    if (
                        data.story.sourceLink.url &&
                        !data.story.sourceLink.url.match(/^[\w]{4,5}:\/\//i)
                    ) {
                        data.story.sourceLink.url = "https://" + data.story.sourceLink.url;
                    }
                    data.story.sourceLink.icon =
                        data.story.sourceLink.label.indexOf("Amazon") > -1 ?
                        "fa-buy" :
                        "fa-website";
                }

                this.$el.html(this.template(data));
                return this;
            },

            stopEvent: function(evt) {
                wattpad.utils.stopEvent(evt);
            },

            onRankingNavigate: function(evt) {
                window.te.push("event", "story_details", "tag_ranking", null, "click", {
                    storyid: this.model.get("id"),
                    tag: this.model.get("tagRankings")[0].name
                });
                this.onNavigate(evt);
            }
        })
    );
})(window, _, wattpad, window.app);