(function(window, wattpad, app, utils) {
    "use strict";

    app.router.on(
        "route:search",
        app.router.filter(["getTranslations", "getCategories"], function(
            query,
            resultType
        ) {
            query = query || "";

            const browseTopicsCollection = new app.collections.BrowseTopics();

            function navigateToView() {
                let options = {
                    query: query ? query.trim() : "",
                    limits: {
                        users: 20,
                        stories: 15
                    },
                    browseTopics: browseTopicsCollection
                };

                options.resultType = resultType || "stories";

                const view = new app.views.SearchLanding(options);

                // Sticky Ads mixin should only be for desktop Search Landing
                app.mixin(app.views.SearchLanding, "StickyAds");

                const title = utils.getSearchTitle(query);

                app.transitionTo(view, {
                    hasHeader: true,
                    hasFooter: true,
                    pageTitle: title
                });

                // If the search term is empty, we have to assume they're on the search landing page
                if (!query.length) {
                    window.te.push("event", "app", "page", null, "view", {
                        page: "search"
                    });
                } else {
                    window.te.push("event", "app", "page", null, "view", {
                        page: "search_results"
                    });
                }
            }

            // Fetch browse topics for new home experience
            Promise.resolve(browseTopicsCollection.fetch()).then(function() {
                navigateToView();
            });
        })
    );
})(window, wattpad, window.app, wattpad.utils);