(function(window, app, wattpad) {
    "use strict";

    app.router.add({
        "search(/:terms)(/:resultType)": [
            "search",
            {
                regexp: {
                    terms: /[^\?\/]+/,
                    resultType: /stories|people/
                }
            }
        ]
    });
})(window, window.app, wattpad);