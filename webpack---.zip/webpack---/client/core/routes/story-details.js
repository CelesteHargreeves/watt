const newAdminPanelEnabled = wattpad.testGroups.NEW_ADMIN_PANEL || false;

const isModerator = window && window.wattpad && !!window.wattpad.isModerator; // 1 || 0, convert to boolean for explicit check.

// this check should show new story details for everyone except
// moderators (ambassador or staff on company VPN) who are not
// in the new admin panel test group.
if (!isModerator || newAdminPanelEnabled) {
    app.router.add({
        "story/:storyid(-:slug)(/)(:section)(/)": [
            "storyDetails",
            {
                regexp: {
                    storyid: /[^\/\?#-]+/,
                    slug: /[^\/\?#]*/,
                    section: /parts/
                }
            }
        ]
    });
} else {
    app.router.add({
        "story/:storyid(-:slug)(/)(:section)(/)": [
            "storyLanding",
            {
                regexp: {
                    storyid: /[^\/\?#-]+/,
                    slug: /[^\/\?#]*/,
                    section: /parts/
                }
            }
        ]
    });
}

app.router.add({
    "story/:storyid(-:slug)/rankings(/)": [
        "storyRanking",
        {
            regexp: {
                storyid: /[^\/\?#-]+/,
                slug: /[^\/\?#]*/
            }
        }
    ]
});