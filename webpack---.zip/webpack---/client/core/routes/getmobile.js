(function(window, app) {
    "use strict";

    app.router.add({
        getmobile: ["getmobile"]
    });
})(window, window.app);