(function(window, app) {
    "use strict";

    // Wattpad Presents
    app.router.add({
        presents: ["videos_landing", {}]
    });
})(window, window.app);