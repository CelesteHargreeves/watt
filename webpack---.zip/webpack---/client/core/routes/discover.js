(function(window, app) {
    "use strict";

    app.router.add({
        stories: ["discover", {}]
    });
})(window, window.app);