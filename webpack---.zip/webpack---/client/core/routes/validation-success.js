(function(window, app) {
    "use strict";

    app.router.add({
        "user_activation/success(/)": ["userActivationSuccess", {}]
    });
})(window, window.app);