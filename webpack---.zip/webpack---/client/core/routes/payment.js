app.router.add({
    "checkout(/)": ["checkout", {}],

    "manage_payment(/)": ["managePayment", {}]
});