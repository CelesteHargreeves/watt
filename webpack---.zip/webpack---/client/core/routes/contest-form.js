(function(window, app) {
    "use strict";

    const route = `contests/${window.wattpad.wattysActiveKey}`;
    app.router.add({
        [route]: ["contest_form", {}]
    });
})(window, window.app);