(function(window, app) {
    "use strict";

    //Challenge Landing Page
    app.router.add({
        comesignup: ["retargeting_landing", {}]
    });
})(window, window.app);