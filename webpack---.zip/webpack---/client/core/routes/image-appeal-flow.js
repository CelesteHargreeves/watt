(function(window, app) {
    "use strict";

    app.router.add({
        "appeal-flow(/)": ["image_appeal", {}]
    });
})(window, window.app);