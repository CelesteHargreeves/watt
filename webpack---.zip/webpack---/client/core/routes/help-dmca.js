(function(window, app) {
    "use strict";
    app.router.add({
        "help/dmca": ["helpDmca"]
    });
})(window, window.app);