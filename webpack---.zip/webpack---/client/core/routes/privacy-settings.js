(function(window, app) {
    "use strict";

    app.router.add({
        "privacy/settings(/)": ["privacySettings"]
    });
})(window, window.app);