(function(window, _, $, wattpad, app) {
    "use strict";

    app.router.on(
        "route:catalog",
        app.router.filter(["getTranslations"], function(catalog) {
            var catalogView = new app.views.DummyReactView({
                component: "Catalog",
                componentId: "catalog",
                componentData: {
                    catalog: catalog,
                    isMobile: wattpad.utils.getDeviceType() === "mobile"
                }
            });

            app.transitionTo(catalogView, {
                hasHeader: true,
                hasFooter: true
            });
        })
    );
})(window, _, jQuery, wattpad, window.app);