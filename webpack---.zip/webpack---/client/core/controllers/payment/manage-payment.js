(function(window, _, $, wattpad, app) {
    "use strict";

    wattpad = wattpad || (window.wattpad = {});

    app.router.on(
        "route:managePayment",
        app.router.filter(["getTranslations", "requireLogin"], function(username) {
            var managePayment = new app.views.ManagePayment();

            app.transitionTo(managePayment, {
                hasHeader: true,
                hasFooter: true
            });
        })
    );
})(window, _, jQuery, wattpad, window.app);