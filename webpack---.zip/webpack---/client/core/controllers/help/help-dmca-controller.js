(function(window, wattpad, app) {
    "use strict";

    app.router.on(
        "route:helpDmca",
        app.router.filter(["getTranslations"], function() {
            if (!wattpad.testGroups.NEW_DMCA_PAGE) {
                wattpad.utils.redirectToServer("/help/DMCA");
                return;
            }

            const view = new app.views.DummyReactView({
                component: "HelpDmcaPage",
                componentId: "help-dmca-page"
            });

            app.transitionTo(view, {
                hasHeader: true,
                hasFooter: true
            });
        })
    );
})(window, wattpad, window.app);