(function(window, _, $, wattpad, app) {
    "use strict";

    app.router.on(
        "route:inbox",
        app.router.filter(["getTranslations", "requireLogin"], function(
            activeThread
        ) {
            var currentUser = wattpad.utils.currentUser();
            // Clear conversation/threads view to prevent glitchy transitions.
            var clearAction = activeThread ?
                window.app.components.actions.resetConversation() :
                window.app.components.actions.resetThreads();
            window.store.dispatch(clearAction);

            var inboxView = new app.views.DummyReactView({
                component: "Inbox",
                componentId: "inbox",
                componentData: {
                    username: currentUser.get("username"),
                    avatar: currentUser.get("avatar")
                }
            });

            app.transitionTo(inboxView, {
                hasHeader: true,
                hasFooter: true
            });
        })
    );
})(window, _, jQuery, wattpad, window.app);