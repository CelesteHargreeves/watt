import {
    setupAdListener
} from "@wattpad/client-platform-web-ads";
/*
 * This file is responsible for creating the Monaco application passing any necessary
 * options.
 * Use this file to perform any initial validation before creating the application,
 * such as API access; user credentials; etc...
 *
 */

window.mobileApp = window.mobileApp || {};
window.mobileApp.instantiate = function(window, _, Backbone, Monaco) {
    "use strict";

    /* -- APPLICATION ---------------------------------------------------- */
    // creates the application attached to window
    window.app = new Monaco.Application("mobile-web", {
        prefetched: window.prefetched,
        cachePolicy: "X-WPApp-Cache-Control"
    });

    /**
     * ADS-887: Impression Event In Prometheus
     */
    const isInAdPrometheusMetricsTestGroup = _.get(
        window,
        "wattpad.testGroups.ADS_PROMETHEUS_METRICS",
        false
    );

    const isInAdsInComment = _.get(
        window,
        "wattpad.testGroups.ADS_IN_COMMENTS",
        false
    );
    if (isInAdPrometheusMetricsTestGroup) {
        window.addEventListener(
            "DOMContentLoaded",
            function() {
                window.ados = window.ados || {};
                window.ados.events = window.ados.events || {};
                window.ados.on = function(e, fn) {
                    window.ados.events[e] = window.ados.events[e] || [];
                    return window.ados.events[e].push(fn);
                };
                window.ads = window.ads || {};

                window.ados.on("ImpressionCounted", function(msg) {
                    let nonAthaZones = [183796];
                    let msgData = msg.data;
                    let zoneId = msgData.shim.zn ? msgData.shim.zn : "unknown";
                    if (_(nonAthaZones).contains(zoneId)) {
                        return;
                    }
                    if (typeof __atha !== "undefined") {
                        let price = wattpad.utils.getAdzerkImpressionCPI(msgData.shim);
                        __atha.sendImpression(
                            msgData.div || "unknown",
                            zoneId.toString(),
                            _.get(msgData, "shim.fl", "unknown").toString(),
                            price
                        );
                    }
                });
            }, {
                once: true
            }
        );
    }
    if (isInAdsInComment) {
        setupAdListener();
    }
};
window.mobileApp.instantiate(window, window._, window.Backbone, window.Monaco);