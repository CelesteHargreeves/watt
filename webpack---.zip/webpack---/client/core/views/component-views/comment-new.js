(function(window, wattpad, utils, app, Monaco) {
    "use strict";

    app.add(
        "CommentNew",
        app.views.NewPost.extend({
            title: function() {
                return wattpad.utils.trans("Join Wattpad");
            },

            subtitle: function() {
                return wattpad.utils.trans(
                    "Sign up to vote, comment, and read stories offline."
                );
            },

            // Methods
            // -------
            onPost: function(evt) {
                var comment = $.trim(this.$("textarea").val());

                this.$(".warning").addClass("hidden");
                this.$(".post-ui button").prop("disabled", true);
                if (comment === "") {
                    this.$(".post-ui button").prop("disabled", false);
                    return; // nothing to post
                }

                if (wattpad.utils.currentUser().authenticated()) {
                    if (wattpad.utils.currentUser().get("verified_email")) {
                        this.createComment(comment);
                    } else {
                        this.onError(
                            wattpad.utils.trans("To comment, please verify your account.")
                        );
                    }
                } else {
                    this.onAuthPrompt(evt);
                }
            },

            createComment: function(commentBody) {
                var self = this;

                var comment = new app.models.CommentModel({
                    body: commentBody,
                    paragraphId: this.collection.paragraphId || null,
                    parentId: this.collection.commentId || this.collection.parentId || null,
                    isReply: this.collection.isReply || false,
                    startPosition: this.collection.startPosition || 0,
                    endPosition: this.collection.endPosition || 0,
                    partId: this.collection.partId || null,
                    storyAuthor: this.collection ? .storyAuthor || ""
                });

                var options = {
                    url: this.getUrlFromSource(comment),
                    wait: true,
                    success: this.onSuccess.bind(this),
                    error: function(model, response, options) {
                        var errorMessage;
                        if (response) {
                            if (response.responseJSON) {
                                errorMessage = response.responseJSON.error.message;
                            } else {
                                errorMessage = response.statusText;
                            }
                        } else {
                            errorMessage = wattpad.utils.trans(
                                "There was a problem posting your message, please try again later."
                            );
                        }
                        self.onError(errorMessage);
                    }
                };

                comment.save({}, options);
            },

            onSuccess: function(model) {
                this.collection.add(model, {
                    at: 0
                });
                app.local.clear("part." + this.collection.partId + ".comments");

                // Trigger custom event
                this.collection.trigger("add:new", model);

                this.$("textarea").val("");
                this.$(".post-ui button").prop("disabled", false);
                this.onTextInputBlur();
            },

            getUrlFromSource: function(comment) {
                if (this.source) {
                    if (this.source instanceof app.models.StoryPartModel) {
                        return "/v4/parts/" + this.source.get("id") + "/comments";
                    }
                }
                return comment.url();
            }
        })
    );

    app.mixin(app.views.CommentNew, "AuthPromptManagement");
})(window, wattpad, wattpad.utils, window.app, window.Monaco);