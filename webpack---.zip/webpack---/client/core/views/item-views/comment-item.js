import commentItemOptions from "core/templates/item-views/comment-item-options.hbs";
import commentItem from "core/templates/item-views/comment-item.hbs";

(function(window, _, $, wattpad, utils, app, Monaco) {
    "use strict";

    app.add(
        "CommentItem",
        app.views.Base.extend({
            // Properties
            // ----------
            template: commentItem,

            className: "comment",

            events: {
                "tap  .on-delete": "onDelete",
                "click  .on-delete": "stopEvent",

                "tap  .on-reply": "onReply",
                "click  .on-reply": "stopEvent",

                "tap  .on-mute-reply": "onMute",
                "click  .on-mute-reply": "stopEvent",

                "tap  .on-mute-comment": "onMute",
                "click  .on-mute-comment": "stopEvent",

                "tap  .on-unmute": "onUnmute",
                "click  .on-unmute": "stopEvent"
            },

            reportModalContainer: ".comment-report-modal",
            modalTitle: wattpad.utils.trans("Report a Comment"),
            requestType: "inappropriate_comments",
            isMainReportModal: false,
            conductType: "story_comment_conduct",

            initialize: function(options) {
                if (!wattpad.testGroups["NEW_COMMENTS_LIST"]) {
                    Handlebars.registerPartial(
                        "core.item_views.comment_item_options",
                        commentItemOptions
                    );
                }

                this.storyId = this.model ? .collection ? .storyId;
                this.isDeeplinkedReply = options.isDeeplinkedReply;
                this.commentLocation = this.model ? .collection ? .commentLocation;
                this.$el.attr(
                    "id",
                    this.commentLocation + "-comment-" + this.model.get("id")
                );

                this.storyAuthor =
                    this.model.get("storyAuthor") || this.model.storyAuthor || "";

                // React Report Modal props
                this.reportModalType = "comment";
                this.reportModalId = {
                    name: this.model.get("author").name,
                    location: window.location.href,
                    body: utils.sanitizeHTML(this.model.get("body")),
                    deepLink: this.model.get("deeplink")
                };
                this.onRemoveMutedComment = this.onRemoveMutedComment.bind(this);
                this.pushSentimentEvent = this.pushSentimentEvent.bind(this);

                this.listenTo(app, `app:comment:mute`, this.onRemoveMutedComment);
                this.listenTo(app, `app:comment:view-replies`, this.onReply);
                this.listenTo(this.model, "change", this.render);
            },

            // Methods
            // -------
            render: function() {
                var data = this.model.toJSON();
                data.body = utils.sanitizeHTML(data.body);

                if (wattpad.utils.currentUser().authenticated()) {
                    var isAmbassador =
                        wattpad.utils.currentUser().get("ambassador") ||
                        wattpad.utils.currentUser().get("isSysAdmin");
                    var isAuthor =
                        this.storyAuthor === wattpad.utils.currentUser().get("username");
                    var isOwner =
                        data.author.name === wattpad.utils.currentUser().get("username");
                    data.canDelete = isAmbassador || isAuthor || isOwner;
                }
                data.isCommentNotification = false;

                // Mute or Unmute user data

                // show Mute or Unmute option if user is logged in
                data.showMuteOption =
                    wattpad.utils.currentUser().get("username") &&
                    data.author.name !== wattpad.utils.currentUser().get("username");

                data.onMuteHelper = this.onMuteHelper.bind(this);

                data.canMute =
                    window.store &&
                    window.store.getState().profileData &&
                    window.store.getState().profileData.mutedUsers &&
                    !window.store
                    .getState()
                    .profileData.mutedUsers.some(
                        user => user.username == data.author.name
                    );
                data.commentItemOptionsAuthor = data.author.name;
                data.isStoryWriter =
                    this.storyAuthor === data.commentItemOptionsAuthor || false;

                data.reportModalId = {
                    name: data.author.name,
                    location: window.location.href,
                    body: data.body,
                    deepLink: data.deeplink
                };
                data.renderId = `${this.commentLocation}-${data.id}`;
                data.commentLocation = this.commentLocation;
                data.backboneModel = this.model;
                data.pushSentimentEvent = this.pushSentimentEvent;

                this.$el.html(this.template(data));

                return this;
            },

            onDelete: function(evt) {
                evt.stopPropagation();
                var paragraphId = this.model.get("paragraphId");
                if (
                    window.confirm(
                        wattpad.utils.trans("Are you sure you want to delete this comment?")
                    )
                ) {
                    /* If the deleted comment is inline (or a reply to an inline comment) it should
                     * trigger app:story:inlinecomment which updates the comment marker.
                     */
                    if (paragraphId) {
                        this.model.destroyAndUpdateMarker();
                    } else {
                        this.model.destroy();
                    }
                }
            },

            reportMoreInfo: function() {
                var self = this;
                return [{
                        key: "Comment Author",
                        val: this.model.get("author").name
                    },
                    {
                        key: "Comment Location",
                        val: window.location.href
                    },
                    {
                        key: "Comment Body",
                        val: function() {
                            return utils.sanitizeHTML(self.model.get("body"));
                        }
                    },
                    {
                        key: "Comment DeepLink",
                        val: this.model.get("deeplink")
                    }
                ];
            },

            onReply: function(
                evt,
                commentId,
                renderId,
                commentLocation,
                isReply = false
            ) {
                if (
                    this.model.get("id") !== commentId ||
                    this.commentLocation !== commentLocation
                )
                    return;
                if (isReply) {
                    const parentCommenId = this.model.get("parentId");
                    const authorName = this.model.get("author").name;
                    app ? .trigger ? .(
                        "app:comment:add-mention",
                        evt,
                        authorName,
                        parentCommenId
                    );

                    return;
                }

                var target,
                    $target,
                    onReplyButton = this.$(evt.currentTarget);

                evt.stopPropagation();
                if (!utils.currentUser().authenticated()) {
                    var $inlineComment = $(
                        "#inline-comments-modal .inline-comments-modal"
                    );
                    if ($inlineComment) {
                        $inlineComment.modal("hide");
                    }
                    var view = new app.views.SignUpPrompt({
                        model: new app.models.Authsignup(),
                        title: wattpad.utils.trans("Join Wattpad"),
                        subtitle: wattpad.utils.trans(
                            "Be part of a global community of readers and writers, all connected through the power of story."
                        ),
                        nextUrl: window.location.href
                    });
                    $("#generic-modal .modal-content").addClass("auth-modal");
                    $("#generic-modal .modal-body").html(view.render().$el);
                    $("#generic-modal").modal("show");
                    return;
                } else if (!utils.currentUser().get("verified_email")) {
                    var $inlineComment = $(
                        "#inline-comments-modal .inline-comments-modal"
                    );
                    if ($inlineComment) {
                        $inlineComment.modal("hide");
                    }
                    utils.showPleaseVerifyModal();
                    return;
                }

                if (!this.model.get("isReply")) {
                    target = `#replies-${renderId}`;
                    $target = this.$(target);

                    //Spam prevention
                    if ($target.hasClass("collapsing")) {
                        return;

                        //Collapse the box
                    } else if ($target.hasClass("collapse") && $target.hasClass("in")) {
                        $target.collapse("hide");
                        onReplyButton.blur();
                    } else {
                        onReplyButton.attr("disabled", true);
                        var collection = this.model.replies();
                        //Leave the view empty to add new things into it
                        var repliesView = new app.views.Comments({
                            collection: collection,
                            chronological: true,
                            enablePosts: wattpad.utils.currentUser().authenticated(),
                            placeholder: wattpad.utils.trans("Reply to this conversation"),
                            commentIdToHighlight: this.model.commentIdToHighlight,
                            model: this.model
                        });

                        this.listenToOnce(repliesView, "render:done", function() {
                            //Show the box once the replies come back
                            $target.collapse("show");
                            if (collection.length === 0) {
                                $target.find("textarea").focus();
                            }

                            //Remove the view when the box gets hidden
                            $target.one("hidden.bs.collapse", function() {
                                collection.off("add:new");
                                collection.off("remove");
                                repliesView.remove();
                                collection.reset(); //kill the collection and the cache
                                app.local.clear(collection.resource());
                            });

                            this.listenTo(collection, "add:new", function() {
                                this.model.trigger("replyCount:add");
                            });
                            this.listenTo(collection, "remove", function() {
                                this.model.trigger("replyCount:sub");
                            });
                            onReplyButton.attr("disabled", false);
                        });
                        $target.append(repliesView.render().$el);
                    }
                }
            },

            //This function handles any sort of auto-expansion for any collapse
            //elements associated with it
            expand: function() {
                this.$el
                    .children(".component-wrapper")
                    .children("footer")
                    .children(".on-reply")
                    .trigger("tap");
            },

            // this method takes care of rendering the Mute/Unmute Modal
            // depending on the modalType ("mute" or "unmute")
            onMuteHelper: function(modalType, username) {
                var view = new app.views.MuteModal({
                    modalType: modalType,
                    username: username
                });

                var $inlineComment = $("#inline-comments-modal .inline-comments-modal");
                if ($inlineComment) {
                    $inlineComment.modal("hide");
                }

                $("#generic-modal .modal-body").html(view.render().$el);
                $("#generic-modal .modal-content").addClass("mute-modal-wrapper");
                $("#generic-modal").modal({});

                this.listenTo(view, `${modalType}:done`, this.render);
            },

            onMute: function(evt) {
                const username = this.$(evt.currentTarget).attr("data-username");
                this.onMuteHelper("mute", username);
            },

            onUnmute: function(evt) {
                const username = this.$(evt.currentTarget).attr("data-username");
                this.onMuteHelper("unmute", username);
            },

            hideComment: function() {
                var fade = {
                    opacity: 0,
                    transition: "opacity 0.5s"
                };
                this.$el.css(fade).slideUp(800);
            },

            onRemoveMutedComment: function(data) {
                var numReplies = this.model.get("numReplies");
                var commentAuthor = this.model.get("author").name;
                var currUser = wattpad.utils.currentUser().get("username");
                var commentMessage = this.model.get("body");

                if (!data) {
                    return;
                }
                // hide comments from current user if they @ muted user
                else if (
                    commentAuthor === currUser &&
                    commentMessage.includes(`@${data.username}`)
                ) {
                    this.hideComment();
                }
                // return if commentAuthor is not the muted user and comment has 0 replies
                // do not need to hide or re-fetch comment
                else if (data.username !== commentAuthor && numReplies == 0) {
                    return;
                } else if (data.username === commentAuthor) {
                    this.hideComment();
                }
                // refetch comment info if comment has replies; need to update reply
                // count in case muted user wrote any replies that need to be hidden
                else {
                    this.model.fetch();
                }

                // TODO: refetch inline commment info to update inline comment counts
                // after muted user's comments have been hidden
            },

            pushSentimentEvent: function(action) {
                let eventData = {
                    page: "comment",
                    storyid: parseInt(this.storyId),
                    partid: parseInt(this.model.get("partId")),
                    commentid: this.model.get("id"),
                    entity_type: "comment",
                    sentiment_type: "like"
                };

                if (this.model.get("paragraphId")) {
                    eventData = {
                        ...eventData,
                        paragraph_id: this.model.get("paragraphId")
                    };
                }

                window.te.push("event", "sentiment", null, null, action, eventData);
            }
        })
    );

    app.mixin(
        app.views.CommentItem,
        "InputCounterManagement",
        "ReportManagement",
        "ReportConduct"
    );
})(window, _, jQuery, wattpad, wattpad.utils, window.app, window.Monaco);