import showMore from "core/templates/mixins/show-more.hbs";
import inlineCommentsModal from "core/templates/collection-views/inline-comments-modal.hbs";
import getAdStrings from "../../../../helpers/ads/get-ad-strings";
(function(window, _, $, wattpad, utils, app) {
    "use strict";

    app.add(
        "InlineCommentsModal",
        app.views.IncrementalList.extend({
            className: "inline-comments-modal modal fade",

            template: inlineCommentsModal,

            events: _.extend(app.views.IncrementalList.prototype.events, {
                "tap .on-return-all-comments": "onReturnToAllComments",
                "click .on-return-all-comments": "stopEvent",
                "shown.bs.modal": "pushOpenCommentViewEvent",
                "hidden.bs.modal": "pushCloseCommentViewEvent"
            }),

            itemView: app.views.CommentItem,

            containerId: "#inline-comments",

            initialize: function(options) {
                options = options || {};

                this.partRating = options.source.get("rating") || null;
                this.chronological = false;
                this.commentIdToHighlight = options.commentIdToHighlight;
                this.isDeepLinkedComment = _.get(
                    options.collection.models,
                    "[0].isDeepLink"
                );

                Handlebars.registerPartial("core.mixins.show_more", showMore);
            },

            showModal: function() {
                this.$el.modal("show");
            },

            onReturnToAllComments: function() {
                this.collection.reset();
                this.$(".single-comment-warning").remove();
                this.$(".comments_ad_mweb").remove();
                this.collection.fetchNextSet();
            },

            getTemplateData: function() {
                return {
                    paragraphText: this.options.collection.paragraphText,
                    storyGroup: this.options.source.get("group"),
                    storyPart: this.options.source.toJSON(),
                    isDeepLinkView: this.isDeepLinkedComment,
                    commentLocation: "paragraph"
                };
            },

            render: function() {
                var self = this;
                app.views.IncrementalList.prototype.render.apply(this, arguments);
                if (!this.isDeepLinkedComment) {
                    _.defer(function() {
                        var addCommentView = new app.views.CommentNew({
                            collection: self.collection,
                            placeholder: wattpad.utils.trans("Leave a comment"),
                            source: self.source
                        });
                        self
                            .$(".post-comment")
                            .empty()
                            .append(addCommentView.render().$el);
                    });
                }

                if (this.collection.length === 0) {
                    var {
                        adUnit,
                        additionalClasses
                    } = getAdStrings(
                        "comments",
                        self.options
                    );

                    self.$(".post-comment").after(
                        wattpad.utils.advertisement({
                            data: {
                                root: self.options.source.toJSON()
                            },
                            hash: {
                                unit: adUnit,
                                experience: "reading",
                                lazy: true,
                                storyGroup: self.options.source.toJSON().group,
                                parentClass: "comments_ad_mweb",
                                additionalClasses: additionalClasses
                            }
                        })
                    );
                    setTimeout(function() {
                        window.dispatchEvent(
                            new CustomEvent("ad-available", {
                                bubbles: true
                            })
                        );
                    }, 100);
                }

                return this;
            },

            /*
             * This appends the posted comment to the top of the comments section (in the modal) to take into account the reverse ordering.
             * Copied from collection-views/comments.js.
             */
            renderItem: function(model, $container) {
                var index = this.collection.indexOf(model);

                // Set append direction
                if (index === 0) {
                    this.direction = this.chronological ?
                        this.directions.down :
                        this.directions.up;
                }
                app.views.IncrementalList.prototype.renderItem.apply(this, arguments);

                this.resetDirection();

                if (
                    model.get("id") === this.commentIdToHighlight &&
                    this.model.isDeepLink
                ) {
                    var commentItem = this.$el.find(
                        "#comment-" + this.commentIdToHighlight
                    );
                    if (commentItem) {
                        commentItem.addClass("highlight");
                    }
                }

                var {
                    adUnit,
                    additionalClasses
                } = getAdStrings(
                    "comments",
                    this.options
                );

                let insertPosition;
                let count = this.collection.length;

                if (index === count - 1) {
                    // fires at the end of a batch
                    let rem = count - self.lastCommentCount; // # comments in the last batch
                    self.lastCommentCount = count;

                    if (count <= 2) {
                        insertPosition = this.collection.length - 1;
                    } else if (
                        index % 10 === 1 || // at *1 index i.e. 11, 21, etc
                        (count % 10 !== 0 && rem > 6)
                    ) {
                        // last batch & has 6+ comments
                        insertPosition = count - 1;
                    }
                } else {
                    // fires per comment item
                    if (index % 10 === 1) {
                        insertPosition = index;
                    }
                }

                if (insertPosition !== undefined) {
                    this.$el
                        .find(".comment")
                        .eq(insertPosition)
                        .after(
                            wattpad.utils.advertisement({
                                data: {
                                    root: this.options.source.toJSON()
                                },
                                hash: {
                                    unit: adUnit,
                                    experience: "reading",
                                    storyGroup: this.options.source.toJSON().group,
                                    parentClass: "comments_ad_mweb",
                                    additionalClasses: additionalClasses
                                }
                            })
                        );
                    setTimeout(function() {
                        window.dispatchEvent(
                            new CustomEvent("ad-available", {
                                bubbles: true
                            })
                        );
                    }, 100);
                }
            },

            resetDirection: function() {
                this.direction = this.chronological ?
                    this.directions.up :
                    this.directions.down;
            },

            pushOpenCommentViewEvent: function() {
                this.pushCommentViewEvent("view");
            },

            pushCloseCommentViewEvent: function() {
                this.pushCommentViewEvent("close");
            },

            pushCommentViewEvent: function(action) {
                window.te.push("event", "comments", null, null, action, {
                    page: "comment",
                    storyid: parseInt(this.collection.storyId),
                    partid: parseInt(this.collection.partId),
                    paragraph_id: this.collection.paragraphId
                });
            }
        })
    );
})(window, _, jQuery, wattpad, wattpad.utils, window.app);