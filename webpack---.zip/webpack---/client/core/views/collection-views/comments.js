import commentsReverse from "core/templates/collection-views/comments-reverse.hbs";
import comments from "core/templates/collection-views/comments.hbs";
import getAdStrings from "../../../../helpers/ads/get-ad-strings";

(function(window, _, wattpad, app) {
    "use strict";

    const INITIAL_FETCH_COMMENT_COUNT = 2;

    app.add(
        "Comments",
        app.views.IncrementalList.extend({
            template: null,

            className: "comments",

            commentTimer: 0,
            commentAdId: null,

            itemView: app.views.CommentItem,

            events: _.extend(app.views.IncrementalList.prototype.events, {
                "tap .on-add-mention": "onAddMention",
                "click .on-add-mention": "stopEvent",

                "tap .on-return-all-comments": "onReturnToAllComments",
                "click .on-return-all-comments": "stopEvent"
            }),

            initialize: function(options) {
                //Assumes collection will be empty as we will fetch on it
                //will sort in reverse chronological order
                //reverse flag indicates 'reverse chronological order ( newest on the top of the list )
                options = options || {};

                this.chronological = options.chronological || false;
                this.commentIdToHighlight = options.commentIdToHighlight;

                this.enablePosts = options.enablePosts || false;

                this.lastCommentCount = 2; // number of comments so far (unused if total comment < 2)
                this.refreshDelay = 30; // number of seconds between refresh
                this.refreshRemaining = 30; // remaining number of refresh that should happen
                this.commentLocation = this.collection.commentLocation;

                // store the id of the parent commen of the replies thread.
                this.parentCommentId = options.model ? .get("id");
                this.commentLocation = this.collection.commentLocation;

                if (this.chronological) {
                    this.template = comments;
                } else {
                    this.template = commentsReverse;
                }

                this.resetDirection();

                if (this.enablePosts) {
                    this.newReplyView = new app.views.CommentNew({
                        collection: this.collection,
                        placeholder: options.placeholder || wattpad.utils.trans("Leave a comment"),
                        source: options.source
                    });
                }
                this.listenTo(app, "app:comment:add-mention", this.onAddMention);
            },

            getTemplateData: function() {
                var data = {
                    hasComments: this.collection.length > 0 || this.enablePosts,
                    device: app.get("device"),
                    isDeepLinkView: this.collection.length > 0 && this.collection.first().isDeepLink,
                    commentLocation: this.commentLocation
                };
                data["commentLocation"] = this.commentLocation;
                return data;
            },

            render: function() {
                var self = this;
                const options = {
                    limit: INITIAL_FETCH_COMMENT_COUNT
                };

                Promise.resolve(this.collection.fetchNextSet(options))
                    .then(function() {
                        self.renderView();
                        if (
                            app.get("device").is.desktop &&
                            self.options.source &&
                            self.collection.length >= 2
                        ) {
                            var {
                                adUnit,
                                additionalClasses
                            } = getAdStrings(
                                "comments",
                                self.options
                            );
                            $(".comments.right-rail .reading-widget").html(
                                wattpad.utils.advertisement({
                                    data: {
                                        root: self.options.source ? .toJSON()
                                    },
                                    hash: {
                                        unit: adUnit,
                                        experience: "reading",
                                        lazy: true,
                                        storyGroup: self.options.source ? .toJSON().group,
                                        additionalClasses: additionalClasses
                                    }
                                })
                            );
                            window.dispatchEvent(
                                new CustomEvent("ad-available", {
                                    bubbles: true
                                })
                            );

                            // refresh timer
                            self.commentAdId = $(".comments-ad-unit .advertisement")[0] ? .id;
                            if (self.commentAdId) {
                                self.startRefreshTimer();
                            }
                        }
                    })["catch"](function() {
                        self.renderView();
                    });
                return this;
            },

            startRefreshTimer: function(adId) {
                var self = this;

                self.refreshTimerId = window.setTimeout(function refreshTick() {
                    if (
                        document.hasFocus() &&
                        document.visibilityState === "visible" &&
                        app.get("device").is.desktop &&
                        !!$("#comments").length &&
                        ($(".comments-ad-unit")[0].getBoundingClientRect().bottom <
                            window.innerHeight && // ad is 100% in viewport from the bottom
                            $(".comments-ad-unit")[0].getBoundingClientRect().top >= 0) // ad still ~50% visible when scrolled to bottom ()
                    ) {
                        self.commentTimer += 5;

                        if (
                            self.commentTimer >= self.refreshDelay &&
                            self.refreshRemaining > 0
                        ) {
                            console.log("refreshing ad");
                            let newAdId = wattpad.utils.refreshAd(
                                $(".comments-ad-unit .advertisement")[0].id
                            );
                            self.commentAdId = newAdId;
                            self.commentTimer = 0;
                            self.refreshRemaining--;
                        }
                    }

                    if (!!$(".comments-ad-unit .advertisement").length &&
                        $(".comments-ad-unit .advertisement")[0].id === self.commentAdId &&
                        self.refreshRemaining > 0
                    ) {
                        // only setup next tick if it's still the same ad and hasn't reach max refresh count
                        self.refreshTimerId = setTimeout(refreshTick, 5000);
                    }
                }, 5000);
            },

            renderView: function() {
                app.views.IncrementalList.prototype.render.apply(this, arguments);

                if (this.enablePosts) {
                    this.$(".post-comment")
                        .empty()
                        .append(this.newReplyView.render().$el);
                }

                //Make the new view
                this.trigger("render:done");
                return this;
            },

            //override renderItem to take into account the chronological (and reverse) ordering
            renderItem: function(model, $container) {
                var index = this.collection.indexOf(model);

                //Set append direction
                if (index === 0) {
                    this.direction = this.chronological ?
                        this.directions.down :
                        this.directions.up;
                }
                app.views.IncrementalList.prototype.renderItem.apply(this, arguments);

                this.resetDirection();

                if (
                    model.get("id") === this.commentIdToHighlight &&
                    this.model.isDeepLink
                ) {
                    var commentItem = this.$el.find(
                        "#comment-" + this.commentIdToHighlight
                    );
                    if (commentItem) {
                        commentItem.addClass("highlight");
                    }
                }

                if (app.get("device").is.mobile && !this.collection.isReply) {
                    var {
                        adUnit,
                        additionalClasses
                    } = getAdStrings(
                        "comments",
                        this.options
                    );

                    let insertPosition,
                        count = this.collection.length;

                    if (index === count - 1) {
                        // fires at the end of a batch
                        let rem = count - this.lastCommentCount; // # comments in the last batch
                        this.lastCommentCount = count;

                        if (count <= 2) {
                            insertPosition = this.collection.length - 1;
                        } else if (
                            index % 10 === 1 || // at *1 index i.e. 11, 21, etc
                            (count % 10 !== 2 && rem > 6)
                        ) {
                            // last batch & has 6+ comments
                            insertPosition = count - 1;
                        }
                    } else {
                        // fires per comment item
                        if (index === 1) {
                            insertPosition = index;
                        } else if (index % 10 === 1) {
                            insertPosition = index;
                        }
                    }

                    if (insertPosition !== undefined) {
                        this.$el
                            .find(".comment")
                            .eq(insertPosition)
                            .after(
                                wattpad.utils.advertisement({
                                    data: {
                                        root: this.options.source ? .toJSON()
                                    },
                                    hash: {
                                        unit: adUnit,
                                        experience: "reading",
                                        storyGroup: this.options.source ? .toJSON().group,
                                        additionalClasses: additionalClasses,
                                        parentClass: "comments_ad_mweb"
                                    }
                                })
                            );
                        window.dispatchEvent(
                            new CustomEvent("ad-available", {
                                bubbles: true
                            })
                        );
                    }
                }
            },

            resetDirection: function() {
                //Reset to normal
                this.direction = this.chronological ?
                    this.directions.up :
                    this.directions.down;
            },

            onAddMention: function(evt, authorName, parentCommentId) {
                if (parentCommentId !== this.parentCommentId) {
                    return;
                }

                wattpad.utils.stopEvent(evt); //stop the top level reply buttons from getting fired

                if (this.newReplyView) {
                    this.newReplyView.addMention(authorName);
                }
            },

            onReturnToAllComments: function() {
                this.collection.reset();
                this.$(".single-comment-warning").remove();
                this.collection.fetchNextSet();
            }
        })
    );
})(window, _, wattpad, window.app);