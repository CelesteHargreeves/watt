import partTextContainer from "core/templates/story-reading/part-text-container.hbs";
import pictureViewer from "core/templates/story-reading/picture-viewer.hbs";
import partSimilar from "core/templates/story-reading/part-similar.hbs";
import partRestart from "core/templates/story-reading/part-restart.hbs";
import partRecommendations from "core/templates/story-reading/part-recommendations.hbs";
import partNavigation from "core/templates/story-reading/part-navigation.hbs";
import partHeaderNew from "core/templates/story-reading/part-header-new.hbs";
import partFooterNew from "core/templates/story-reading/part-footer-new.hbs";
import partContainerNew from "core/templates/story-reading/part-container-new.hbs";
import partComments from "core/templates/story-reading/part-comments.hbs";
import partActions from "core/templates/story-reading/part-actions.hbs";
import commentMarker from "core/templates/story-reading/comment-marker.hbs";
import bannedImageMessaging from "core/templates/banned-image-messaging.hbs";
(function(window, wattpad, utils, app, Monaco) {
    "use strict";
    app.add(
        "CoreStoryReading",
        app.views.RegionManager.extend({
            template: function() {
                return "";
            },

            partials: {
                "core.story_reading.comment-marker": commentMarker,
                "core.story_reading.funbar": function() {
                    return "";
                },
                "core.story_reading.media_banner": function() {
                    return "";
                },
                "core.story_reading.part_actions": partActions,
                "core.story_reading.part_comments": partComments,
                "core.story_reading.part_container_new": partContainerNew,
                "core.story_reading.part_footer_new": partFooterNew,
                "core.story_reading.part_header_new": partHeaderNew,
                "core.story_reading.part_navigation": partNavigation,
                "core.story_reading.part_recommendations": partRecommendations,
                "core.story_reading.part_restart": partRestart,
                "core.story_reading.part_similar": partSimilar,
                "core.story_reading.picture_viewer": pictureViewer,
                "core.story_reading.part_text_container": partTextContainer,
                "core.banned_image_messaging": bannedImageMessaging
            },

            regions: {},

            bannerSignup: true,

            isDesktop: null,
            id: "story-reading",
            voteButton: ".actions > .btn-vote",

            subviews: {
                funbar: app.views.StoryReadingFunbar,
                media: app.views.MediaBanner,
                comments: app.views.Comments,
                bottomBanner: app.views.BottomBanner
            },

            regionTags: {
                funbar: "#funbar-container",
                media: "#media-container",
                comments: "#comments",
                bottomBanner: "#bottom-banner-container"
            },

            events: {
                "tap   .share-embed": "onShareEmbed",
                "click .share-embed": "stopEvent",

                "tap    .on-dismiss-lists": "onDismissLists",
                "click  .on-dismiss-lists": "stopEvent",

                "tap   .on-send": "onSendToFriend",
                "click .on-send": "stopEvent",

                "tap   .on-inline-comments-modal": "showInlineCommentsModal",
                "click .on-inline-comments-modal": "stopEvent",

                "keyup .send-input": "onValidateSend",

                "tap    .on-load-more-page": "onLoadNextPage",
                "click  .on-load-more-page": "stopEvent",

                "tap .share-post-to-profile": "showPostToProfileModal",
                "click .share-post-to-profile": "stopEvent"
            },

            initialize: function(options) {
                var self = this;

                _.each(this.partials, function(value, key) {
                    Handlebars.registerPartial(key, value);
                });

                _.bindAll(
                    this,
                    "buyPaidContent",
                    "showStoryPaywallModal",
                    "onBuyCoins"
                );

                this.scrollState = {
                    part: {}
                };

                // Need this object to be unique per object, so instantiate it here
                this.sync = {
                    enabled: true,
                    last: 0,
                    part: 0
                };

                if (wattpad.utils.currentUser().authenticated()) {
                    this.listenTo(this.model, "reading-position-available", function(
                        percent
                    ) {
                        self.sync = {
                            enabled: true,
                            last: percent
                        };
                    });
                    this.listenTo(app, "app:story:vote", this.onUpdateVote);
                    // Updates comment count markers when inline comments are added and removed.
                    this.listenTo(
                        app,
                        "app:story:inlinecomment",
                        this.fetchCommentCounts
                    );
                    // Update comment count markers when a user has been muted
                    this.listenTo(app, "app:comment:mute", function() {
                        this.fetchCommentCounts();
                    });
                    this.model.syncPosition();
                } else {
                    this.sync.enabled = false;
                }

                if (options.deepLinkModel) {
                    this.deepLinkModel = options.deepLinkModel;
                    this.listenTo(app, "app:comment:deepLink", this.deepLinkToComment);
                }
            },

            showPostToProfileModal: function(e) {
                var self = this,
                    $genericModal = $("#generic-modal");

                utils.stopEvent(e);

                if (!wattpad.utils.currentUser().authenticated()) {
                    this.onAuthPrompt(e);
                    return;
                } else if (!wattpad.utils.currentUser().get("verified_email")) {
                    utils.showPleaseVerifyModal();
                    return;
                } else {
                    var postToProfileModal = new app.views.PostToProfileModal({
                        model: this.model,
                        target: utils.currentUser().get("username")
                    });
                    $genericModal.empty().append(postToProfileModal.render().$el);
                    $genericModal.modal("show");
                }
            },

            render: function() {
                var self = this;
                this.model.set("isDeepLinkView", !!this.options.deepLinkModel);

                if (!wattpad.utils.isOperaMini) {
                    $(window).on("scroll.screen_" + this.cid, function(e) {
                        self.delegateScrollEvent(e);
                    });
                }

                _.defer(function() {
                    /*
                     * Rendering for Inline Comments
                     */
                    if (self.deepLinkModel) {
                        app.trigger("app:comment:deepLink");
                    }
                    self.model.getCommentCountByParagraph().then(function() {
                        /*
                         * Render only commentCounts for the paragraphs within the main story text page
                         * (and not for for <p> tags inside the inline comments modal)
                         */
                        self.renderCommentCounts(
                            self.$(".panel.panel-reading > pre p[data-p-id]")
                        );
                    });
                    utils.resizeImages(
                        self.$(".panel-reading pre [data-image-layout=one-horizontal]"),
                        self.$(".panel-reading pre").width()
                    );
                    self.initializeVideoTracking();

                    var isWriterPreview = self.isWriterPreview();

                    if (isWriterPreview) {
                        self.setImageModerationNotices();
                    }
                });

                this.addCopyListener();
                return this;
            },

            deepLinkToComment: function() {
                var paragraphId = this.deepLinkModel.get("paragraphId");
                var paragraphIsVisible =
                    this.getParagraphById(paragraphId).length !== 0;
                var isOrphanedComment =
                    paragraphId &&
                    !paragraphIsVisible &&
                    this.model.get("pageNumber") + 1 >= this.model.get("pages");

                if (paragraphId && !isOrphanedComment) {
                    /*
                     * Initializes InlineComments collection with the specific deeplinked CommentModel
                     * and opens the InlineComments Modal with that comment.
                     */
                    try {
                        /*
                         * InlineComments throws an exception if the deeplinked inline comment is referring to a
                         * paragraph of story text that is unavailable, i.e., on /page/4.
                         */
                        var collection = new app.collections.InlineComments(
                            [this.deepLinkModel], {
                                paragraphId: paragraphId,
                                partId: this.model.get("id"),
                                storyPart: this.model,
                                limit: 10,
                                commentId: this.deepLinkModel.get("id"),
                                storyId: this.model.get("group") ? .id
                            }
                        );
                        var inlineCommentsModal = new app.views.InlineCommentsModal({
                            source: this.model,
                            collection: collection,
                            model: this.deepLinkModel,
                            commentIdToHighlight: this.deepLinkModel.commentIdToHighlight
                        });
                        this.$("#inline-comments-modal")
                            .empty()
                            .append(inlineCommentsModal.render().$el);
                        inlineCommentsModal.showModal();

                        /*
                         * If the deeplink is a reply to a comment, it renders the parent comment, expands the replies to it, and highlights
                         * the specific reply based on its replyID.
                         */

                        if (this.deepLinkModel.isDeeplinkedReply) {
                            _.toArray(inlineCommentsModal.viewPointers)[0].expand();
                        }
                        this.stopListening(
                            app,
                            "app:comment:deepLink",
                            this.deepLinkToComment
                        );
                    } catch (e) {
                        /*
                         * If a deeplinked inline comment is on another page of the story part (i.e. /page/3) that hasn't rendered yet, then we
                         * scroll down the page and trigger loading another page. This continues until the paragraph renders on the page.
                         */
                        this.$("footer")[0].scrollIntoView(true);
                        this.$el.find(".on-load-more-page").trigger("tap");
                    }
                } else {
                    var collection = new app.collections.StoryPartComments(
                        [this.deepLinkModel], {
                            storyAuthor: this.model.get("group") ?
                                this.model.get("group").user.username :
                                "",
                            partId: this.model.get("id"),
                            limit: 10,
                            storyId: this.model.get("group") ? .id
                        }
                    );

                    var view = new app.views.Comments({
                        collection: collection,
                        enablePosts: wattpad.utils.currentUser().authenticated(),
                        source: this.model,
                        model: this.deepLinkModel,
                        commentIdToHighlight: this.deepLinkModel.commentIdToHighlight
                    });

                    this.$(this.regionTags.comments).empty();
                    this.setRegion(this.regionTags.comments, view.renderView());
                    this.$(view.$el[0])
                        .find(".collection")[0]
                        .scrollIntoView(true);

                    /*
                     * If the deeplink is a reply to a comment, it renders the parent comment, expands the replies to it, and highlights
                     * the specific reply based on its replyID.
                     */
                    if (this.deepLinkModel.isDeeplinkedReply) {
                        _.toArray(view.viewPointers)[0].expand();
                    }

                    this.lockScrollUpdate();
                    this.stopListening(
                        app,
                        "app:comment:deepLink",
                        this.deepLinkToComment
                    );
                }
            },

            getParagraphById: function(paraId) {
                return this.$(
                    ".panel.panel-reading > pre > p[data-p-id=" + paraId + "]"
                );
            },

            /*
             * Add event listener to disallow copy on selection containing any story content.
             * Should return false to prevent copying.
             */
            addCopyListener: function() {
                $(window).on("copy.screen_" + this.cid, function() {
                    var storyContentNode = $(".part-content")[0];
                    var inlineCommentTextNode = $(
                        ".inline-comments-modal .paragraph-text"
                    )[0];
                    var disallowedNodes = [storyContentNode, inlineCommentTextNode];
                    var allowCopy = !_.some(disallowedNodes, function(node) {
                        return node && window.getSelection().containsNode(node, true);
                    });
                    if (!allowCopy) {
                        return false;
                    }
                });
            },

            /*
             * Fetches comment counts for the story part and renders commentCount markers.
             * If paragraphId is provided, it will only update a single commentCount marker for that paragraph.
             */
            fetchCommentCounts: function(paragraphId) {
                var self = this;
                var paragraphElements = paragraphId ?
                    this.getParagraphById(paragraphId) :
                    this.$(".panel.panel-reading > pre p[data-p-id]");
                if (paragraphElements.length) {
                    this.model.getCommentCountByParagraph().then(function() {
                        self.renderCommentCounts(paragraphElements);
                    });
                }
            },

            /*
             * Takes an array of paragraph elements and appends a commentCount marker for each
             * (or a hidden one if no comments) on initialize & page scroll.
             */
            renderCommentCounts: function(paragraphs) {
                var self = this;
                var paragraphCommentCounts = self.model.get("paragraphs");
                const partTitle = self.model.get("title");
                const partId = self.model.get("id");
                const storyAuthor = self.model.get("group") ? .user.username;
                const storyId = self.model.get("group") ? .id;
                /*
                 * Don't render comment counts until we have already fetched paragraph/comment
                 * metadata via getCommentCountByParagraph.
                 */
                if (paragraphCommentCounts) {
                    _.each(paragraphs, function(paragraph) {
                        var $paragraph = $(paragraph);
                        var paragraphId = $paragraph.data("p-id");

                        var paragraphBody;
                        _.each(self.model.loadedPages, loadedPage => {
                            paragraphBody = loadedPage.getParagraphById(paragraphId);
                            if (paragraphBody) {
                                paragraphBody = Handlebars.helpers.parseEmbeddedMedia(
                                    paragraphBody,
                                    460
                                );
                                return false;
                            }
                        });

                        var commentObj = _.find(paragraphCommentCounts, function(obj) {
                            return obj.id === paragraphId;
                        });
                        self.renderCommentMarker(
                            $paragraph,
                            commentObj ? commentObj.commentCount : 0,
                            paragraphId,
                            partId,
                            partTitle,
                            paragraphBody,
                            storyAuthor,
                            storyId
                        );
                    });
                }
            },

            // Updates the comment count on the comment marker for each paragraph.
            renderCommentMarker: function(
                paragraph,
                commentCount,
                paragraphId,
                partId,
                partTitle,
                paragraphBody,
                storyAuthor,
                storyId
            ) {
                var self = this;
                var $paragraph = $(paragraph);
                var $commentMarker = self.partials["core.story_reading.comment-marker"];
                $paragraph.children(".comment-marker").remove();
                $paragraph.append(
                    $commentMarker({
                        commentCount,
                        paragraphId,
                        partTitle,
                        partId,
                        paragraphBody,
                        storyAuthor,
                        storyId
                    })
                );
            },

            showInlineCommentsModal: _.debounce(function(e) {
                var self = this;
                var paragraphId = $(e.target)
                    .closest(".on-inline-comments-modal")
                    .parent()
                    .data("p-id");
                var collection = new app.collections.InlineComments([], {
                    paragraphId: paragraphId,
                    storyPart: self.model,
                    limit: 10,
                    storyId: this.model.get("group") ? .id
                });

                Promise.resolve(collection.fetchNextSet()).then(function() {
                    var inlineCommentsModal = new app.views.InlineCommentsModal({
                        source: self.model,
                        collection: collection
                    });

                    self
                        .$("#inline-comments-modal")
                        .empty()
                        .append(inlineCommentsModal.render().$el);
                    inlineCommentsModal.showModal();
                });

                // Send tracking info
                window.te.push("event", "reading", "comment", "inline", "click", {
                    storyid: this.model.get("group").id,
                    partid: this.model.get("id"),
                    paragraphid: paragraphId
                });
            }, 800),

            initializeVideoTracking: function() {
                var self = this;

                // This method is called automatically after the Youtube iFrame API has loaded
                window.onYouTubeIframeAPIReady = function() {
                    self.initializeEmbeddedIframes();
                };

                // If the Youtube iFrame hasn't been loaded yet, load it now
                if (!window.YT) {
                    window.YTConfig = {
                        host: "https://www.youtube-nocookie.com"
                    };
                    var tag = document.createElement("script");
                    tag.src = "https://www.youtube.com/iframe_api";
                    var firstScriptTag = document.getElementsByTagName("script")[0];
                    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
                }
            },

            initializeEmbeddedIframes: function() {
                var self = this;
                // only run if the Youtube iFrame API has been initialized
                if (window.YT) {
                    $("[data-media-type=video] iframe")
                        .not(".initialized")
                        .each(function(index, element) {
                            var player = new YT.Player(element, {
                                events: {
                                    onStateChange: function(data) {
                                        self.trackVideoState(element, data);
                                    }
                                }
                            });
                            $(element).addClass("initialized");
                        });
                }
            },

            trackVideoState: function(videoElement, videoStateData) {
                var video = $(videoElement);
                if (
                    videoStateData.data === YT.PlayerState.PLAYING &&
                    !video.data("playTracked")
                ) {
                    window.te.push("event", "reading", "media", "video", "play", {
                        partid: this.model.get("id"),
                        videoid: video.data("videoId")
                    });
                    video.data("playTracked", 1);
                } else if (videoStateData.data === YT.PlayerState.ENDED) {
                    window.te.push("event", "reading", "media", "video", "finished", {
                        partid: this.model.get("id"),
                        videoid: video.data("videoId")
                    });
                    video.data("playTracked", 0);
                }
            },

            remove: function() {
                this.ignoreEvents = true;
                $(window).off("scroll.screen_" + this.cid);
                $(window).off("copy.screen_" + this.cid);
                $(".panel-reading p img").off("error");
                //remove shadow banner
                $(".shadow-verify").remove();
                app.views.RegionManager.prototype.remove.apply(this, arguments);
                $("body").removeAttr("ondragstart onselectstart unselectable");
            },

            setRegions: function(currentPartIsBlocked = false) {
                var isPreview = this.options ? this.options.isPreview : false;
                this.$(this.regionTags.funbar).empty();

                var view = new this.subviews.funbar({
                    model: this.model,
                    isPreview: isPreview
                });
                this.setRegion(this.regionTags.funbar, view.render());
                var media = this.model.get("media");
                if (!media) {
                    media = [];
                    if (this.model.get("videoId")) {
                        media.push({
                            video: true,
                            ref: this.model.get("videoId")
                        });
                    }
                    if (this.model.get("photoUrl")) {
                        media.push({
                            photo: true,
                            ref: this.model.get("photoUrl")
                        });
                    }
                }
                // Set media to null, so prefetched story detail won't show on CSR.
                this.model.set("media", null);
                this.$(this.regionTags.media).empty();
                var isWriterPreview = this.isWriterPreview();

                view = new this.subviews.media({
                    model: this.model,
                    media: media,
                    bgCover: this.model.get("group").cover,
                    socialLinks: this.socialLinks,
                    isWriterPreview: isWriterPreview
                });
                this.setRegion(this.regionTags.media, view.render());

                //Show bottom banner when all conditions satisfied:
                //desktop, loggout user, not AdExempt, not force signup exempt, and
                //haven't dismissed the banner in current session.
                if (
                    app.get("device").is.desktop &&
                    !wattpad.utils.currentUser().authenticated() &&
                    !this.model.get("group").isAdExempt &&
                    !wattpad.utils.getCookie("dB")
                ) {
                    this.$(this.regionTags.bottomBanner).empty();
                    var view = new this.subviews.bottomBanner({
                        image: this.model.get("group").cover,
                        title: this.model.get("group").title,
                        showBottomBanner: true,
                        dismissibleBanner: true
                    });
                    this.setRegion(this.regionTags.bottomBanner, view.render());
                }
                // Comments aren't shown if we're forcing signup and you're logged out,
                // so they shouldn't be fetched then either.
                if (
                    (this.bannerSignup ||
                        wattpad.utils.currentUser().authenticated() ||
                        this.model.get("group").isAdExempt) &&
                    !currentPartIsBlocked
                ) {
                    if (this.deepLinkModel) {
                        /*
                         * If the story reading view is linked to a deeplinked comment, don't render all story part comments.
                         */
                        return;
                    }

                    if (wattpad.testGroups.NEW_COMMENTS_LIST) {
                        /* If the FF is enabled the comments are rendering by React[StoryPartComments] */
                        return;
                    }

                    var collection = new app.collections.StoryPartComments([], {
                        storyAuthor: this.model.get("group") ?
                            this.model.get("group").user.username :
                            "",
                        partId: this.model.get("id"),
                        limit: 10,
                        initialLimit: 2,
                        storyId: this.model.get("group") ? .id
                    });

                    this.$(this.regionTags.comments).empty();

                    view = new app.views.Comments({
                        collection: collection,
                        enablePosts: wattpad.utils.currentUser().authenticated(),
                        source: this.model
                    });

                    this.setRegion(this.regionTags.comments, view.render());
                }
            },

            onUpdateVote: function(data) {
                // runs on app.trigger app:story:vote event
                if (!data || data.storyId !== this.model.get("id")) {
                    return;
                }
                if (data.voted) {
                    this.voteSelected();
                } else {
                    this.voteDeselected();
                }
                this.updateMeta(data.voteCount);
            },

            voteSelected: function() {
                var newIcon = wattpad.utils.iconify("fa-vote", 16, "wp-base-1"),
                    newText = wattpad.utils.trans("Voted");
                this.$(".actions > .on-vote").html(newIcon + " " + newText);
            },

            voteDeselected: function() {
                var newIcon = wattpad.utils.iconify("fa-vote", 16, "wp-neutral-2"),
                    newText = wattpad.utils.trans("Vote");
                this.$(".actions > .on-vote").html(newIcon + " " + newText);
            },

            updateMeta: function(voteCount) {
                this.$(".story-stats > .reads").html(
                    wattpad.utils.iconify("fa-view", 14, "wp-neutral-2") +
                    " " +
                    this.model.get("readCount")
                );
                this.$(".story-stats > .votes").html(
                    wattpad.utils.iconify("fa-vote", 14, "wp-neutral-2") +
                    " " +
                    (voteCount ? voteCount : this.model.get("voteCount"))
                );
                this.$(".story-stats > .comments").html(
                    wattpad.utils.iconify("fa-comment", 14, "wp-neutral-2") +
                    " " +
                    this.model.get("commentCount")
                );
            },

            // Return isBigPart for DW users
            getIsBigPart: function() {
                return this.model.get("pages") >= 12;
            },

            onLoadNextPage: function(event) {
                this.unlockScrollUpdate();
                var page = parseInt(
                    $(event.currentTarget)
                    .attr("href")
                    .match(/page\/([0-9]+)$/)[1],
                    10
                );
                this.loadNextPage(page);
            },

            loadNextPage: function(pageNumber) {
                if (pageNumber > this.model.get("pages")) {
                    this.$(".load-more-page").addClass("hidden");
                    this.$(".next-part").removeClass("hidden");
                    return;
                }

                var self = this,
                    activePart = this.scrollState.part[this.scrollState.part.active.id],
                    lastPage = activePart.page.last.$el,
                    device = app.get("device"),
                    textPartial = self.partials["core.story_reading.part_text_container"];

                this.model.getPage(pageNumber).then(function(page) {
                    if (!page.get("text") &&
                        (!page.get("paragraphs") || _.isEmpty(page.get("paragraphs")))
                    ) {
                        if (pageNumber <= self.model.get("pages")) {
                            self.$(".load-more-page").removeClass("hidden");
                            self.$(".next-part").addClass("hidden");
                        }
                        return;
                    }

                    var nextPageVariables = {
                        id: self.model.get("id"),
                        pages: self.model.get("pages"),
                        group: self.model.get("group"),
                        text: page.get("text"),
                        pageNumber: pageNumber,
                        firstPage: pageNumber === 1,
                        lastPage: pageNumber >= self.model.get("pages"),
                        isMicroPart: self.model.get("pages") < 2,
                        isSmallPart: self.model.get("pages") >= 2 && self.model.get("pages") < 5,
                        isMediumPart: self.model.get("pages") >= 5 && self.model.get("pages") < 12,
                        isBigPart: self.getIsBigPart(),
                        isHeightZero: true
                    };

                    var $nextPage = $(
                        textPartial(_.extend({}, self.model.toJSON(), nextPageVariables))
                    );

                    self
                        .$(".on-load-more-page")
                        .attr("href", activePart.url + "/page/" + (pageNumber + 1));

                    if (lastPage.next(".mobile-cta").length) {
                        lastPage = lastPage.next(".mobile-cta");
                    }

                    lastPage.after($nextPage.removeClass("height-zero"));

                    // fire ad event after appending next page
                    window.dispatchEvent(
                        new CustomEvent("ad-available", {
                            bubbles: true
                        })
                    );

                    /*
                     * Fetch inline comment counts & open Inline Comments Modal for the next page
                     */

                    self.renderCommentCounts(
                        $nextPage.find(".panel.panel-reading > pre p[data-p-id]")
                    );

                    var isEmptyModal = self.$("#inline-comments-modal").is(":empty");
                    if (self.deepLinkModel && isEmptyModal) {
                        self.deepLinkToComment();
                    }

                    self.initializeEmbeddedIframes();
                    // Setting up a watch for campfire image loading errors.
                    $(".panel-reading p img").on(
                        "error",
                        _.bind(self.onImageLoadError, self)
                    );
                });
            },

            setElement: function() {
                Monaco.View.prototype.setElement.apply(this, arguments);

                _.each(
                    this.regionTags,
                    function(regionTag) {
                        if (this.regions[regionTag] && this.regions[regionTag].view) {
                            if (this.$(regionTag).length > 0) {
                                this.regions[regionTag].view.setElement(
                                    $(this.$(regionTag + " > div"))
                                );
                                if (
                                    regionTag === this.regionTags.media &&
                                    this.regions[regionTag].view.media.length > 1
                                ) {
                                    this.regions[regionTag].view.showNextArrow();
                                }
                            }
                        }
                    },
                    this
                );
            },

            getImageModerationStatus: function(imageUrl) {
                return Promise.resolve(
                        $.ajax({
                            type: "GET",
                            url: "/v5/image_moderation/result?image_url=" + imageUrl
                        })
                    )
                    .then(function(response) {
                        return response.result;
                    })
                    .catch(function(error) {
                        return (
                            "Error fetching image moderation result:" + error.responseText
                        );
                    });
            },

            isWriterPreview: function() {
                return (
                    wattpad.utils.currentUser() &&
                    this.model.get("group").user.username ===
                    wattpad.utils.currentUser().get("username")
                );
            },

            setImageModerationNotices: function() {
                // select all images inline in text
                // send image url to v5 for moderation status
                // if status is banned. then show image rejection overlay
                var self = this;
                $("[data-image-layout=one-horizontal]").each(function(
                    index,
                    parentElement
                ) {
                    var $imageParent = $(parentElement),
                        imageSrc = $(parentElement)
                        .find("img")
                        .attr("src")
                        .split("?")[0]; //without the query params

                    self
                        .getImageModerationStatus(imageSrc)
                        .then(function(result) {
                            if (result !== "banned") {
                                return;
                            }
                            var groupId = self.model.storyId,
                                partId = self.model.partId;

                            $imageParent
                                .addClass("banned")
                                .find(".banned-overlay")
                                .removeClass("hidden");

                            $imageParent
                                .find(".banned-messaging")
                                .removeClass("hide")
                                .append(
                                    self.partials["core.banned_image_messaging"]({
                                        id: $imageParent.data("p-id"),
                                        src: imageSrc,
                                        groupId: groupId,
                                        partId: partId
                                    })
                                );
                        })
                        .catch(function(error) {
                            console.error(error);
                        });
                });
            },

            onPageScroll: function() {
                if (this.ignoreEvents) {
                    return;
                }
                this.updateScrollState();
            },

            delegateScrollEvent: _.throttle(function() {
                this.onPageScroll();
            }, 200),

            // Similar to lockScrollUpdate, but not meant to be used in a pair with
            // unlockScrollUpdate; this is a one-way transition.
            stopScrollUpdate: function() {
                this.ignoreEvents = true;
                $(window).off("scroll.screen_" + this.cid);
            },

            lockScrollUpdate: function() {
                this.ignoreEvents = true;
                $(window).off("scroll.screen_" + this.cid);

                var activePart = this.scrollState.part[this.scrollState.part.active.id];
                if (activePart.page.last.number < this.model.get("pages")) {
                    this.$(".load-more-page").removeClass("hidden");
                }
            },

            unlockScrollUpdate: function(evt) {
                var self = this;
                this.ignoreEvents = false;
                $(window).on("scroll.screen_" + this.cid, function(e) {
                    self.delegateScrollEvent(e);
                });

                this.onPageScroll();
            },

            _calculatePercentageRead: function($activePage) {
                // First, calculate the percentage of the pages we've read.
                var pageNum = $activePage.data("page-number");
                var numPages = this.model.get("pages");
                var $readingPanel = $activePage.find(".panel-reading");
                var percentage = (pageNum - 1) / this.model.get("pages") || 0;

                const readingPanelOffset = $readingPanel.offset();
                // In some cases, e.g. on a paywalled part, there is no
                // reading panel, so count it as not read.
                if (!$readingPanel.offset()) {
                    return 0;
                }

                // Then, add the percentage of this page we've read.
                var diff = window.scrollY - readingPanelOffset.top;
                var pagePercent = $readingPanel.height() ?
                    diff / $readingPanel.height() :
                    0;
                percentage += pagePercent / numPages || 0;

                // We need to clamp to [0, 100%].
                return Math.min(1, Math.max(0, percentage));
            },

            updateScrollState: function(fromController) {
                fromController = fromController || false;

                var $activePart, $activePage, $parts, $pages;

                $parts = this.$(".story-part"); // Get all parts
                $activePart = this.findViewable($parts); // Get active part

                $pages = $activePart.find(".page"); // Get pages within active part
                $activePage = this.findViewable($pages); // Get active page

                if (
                    _.isEmpty(this.scrollState.part) ||
                    this.scrollState.part.active.id !== $activePart.data("part-id")
                ) {
                    this.scrollState.part = {
                        count: $parts.length,
                        active: {
                            id: $activePart.data("part-id")
                        }
                    };
                }

                this.model.trigger(
                    "reading-progress",
                    this._calculatePercentageRead($activePage)
                );

                if (!this.scrollState.part[$activePart.data("part-id")] ||
                    this.scrollState.part[$activePart.data("part-id")].page.active !==
                    $activePage.data("page-number")
                ) {
                    this.scrollState.part[$activePart.data("part-id")] = {
                        url: $activePart.data("part-url"),
                        page: {
                            count: $pages.length,
                            active: $activePage.data("page-number"),
                            first: $pages.first().data("page-number"),
                            last: {
                                number: $pages.last().data("page-number"),
                                $el: $pages.last()
                            }
                        }
                    };

                    this.model.set(
                        "pageNumber",
                        this.scrollState.part[$activePart.data("part-id")].page.active
                    );

                    this.updateUrl();
                    this.updateTitle();
                    if (!fromController) {
                        wattpad.utils.pushEvent({}, "virtualPageview");
                    }

                    this.updateSyncPosition();
                    this.updatePageContent();
                    if ($activePage.data("page-number") !== 1) {
                        this.sendReadingEvent();
                    }
                }
            },

            updateUrl: function() {
                if (!wattpad.utils.supportPushState()) {
                    return;
                }

                var url = "",
                    activePart = this.scrollState.part[this.scrollState.part.active.id],
                    activePage = activePart.page.active,
                    commentIndex = window.location.href.indexOf("/comment");

                // Extract and build URL
                url += wattpad.utils.formatStoryUrl(activePart.url);
                url += activePage > 1 ? "/page/" + activePage : "";
                url +=
                    commentIndex !== -1 ? window.location.href.slice(commentIndex) : "";
                url += window.location.search;

                if (app.get("device").is.desktop) {
                    var pageData = this.model.toJSON();
                    app.trigger("checkRefreshingAds", pageData);
                }
                // Execute url change
                app.router.navigate(url, {
                    trigger: false,
                    replace: true
                });
            },

            updateTitle: function() {
                var storyGroupTitle = this.model.get("group").title,
                    storyPartTitle = this.model.get("title"),
                    activePart = this.scrollState.part[this.scrollState.part.active.id],
                    activePage = activePart.page.active;

                var docTitle = storyGroupTitle;
                docTitle +=
                    storyGroupTitle !== storyPartTitle ? " - " + storyPartTitle : "";
                if (activePage > 1) {
                    docTitle += " - " + wattpad.utils.trans("Page") + " " + activePage;
                }

                var title;

                // Vietnamese is special-cased to deal with scrapers with good SEO
                var lang = parseInt(app.get("language"), 10);
                if (lang === 19) {
                    title =
                        "Đọc Truyện " +
                        docTitle +
                        " - " +
                        this.model.get("group").user.name +
                        " - Wattpad";
                } else {
                    title = docTitle;
                }

                wattpad.utils.setTitle(title);
            },

            updatePageContent: function() {
                //TODO: Add content while scrolling
                var activePart = this.scrollState.part[this.scrollState.part.active.id],
                    activePage = activePart.page.active;

                //Check for next page
                if (
                    activePage <= this.model.get("pages") &&
                    activePart.page.last.number === activePage
                ) {
                    this.loadNextPage(parseInt(activePage, 10) + 1);
                }
            },

            _calculateSyncPosition: function() {
                var activePage = this.scrollState.part[this.scrollState.part.active.id]
                    .page.active,
                    percentage = activePage / this.model.get("pages") || 0;

                return Number(Math.round(percentage + "e3") + "e-3"); //round to 3 decimal places
            },

            updateSyncPosition: function() {
                var currentPercentRead = 0;

                //Disable entire method when syncing is not enabled
                if (this.sync.enabled) {
                    currentPercentRead = this._calculateSyncPosition();

                    //Only sync if we are further in the story
                    if (currentPercentRead > this.sync.last) {
                        this.sync.last = currentPercentRead;
                        this.model.syncPosition(currentPercentRead);

                        //Disable syncing when we have finished
                        if (currentPercentRead === 1) {
                            this.sync.enabled = false;
                        }
                    }
                }
            },

            sendReadingEvent: function() {
                var group = this.model.get("group"),
                    publishedParts = utils.publishedPartsInStory(group);

                window.te.push("event", "reading", "progress", null, "next_page", {
                    storyid: group.id,
                    partid: this.model.get("id"),
                    read_percent: this._calculateSyncPosition(),
                    published_parts: publishedParts.length
                });
            },

            findViewable: function($vector) {
                var result = $($vector[0]), // Default to first element in vector
                    threshold = window.innerHeight / 2 + window.scrollY; // Our threshold is 1/2 down the screen

                // Only 1 element, or screen not scrolled
                if ($vector.length < 2 || window.scrollY === 0) {
                    return result;
                }

                // Iterate through all the elements in the vector
                $vector.each(function(index) {
                    var $current = $(this),
                        $next = $vector[index + 1] ? $($vector[index + 1]) : null; // Next element in the vector

                    result = $current;

                    if (result.height() === 0) {
                        // If the next element is below our threshold, stop iterating and return the current element
                        if (
                            $next &&
                            $next.find(".panel-reading").offset().top > threshold
                        ) {
                            return false;
                        }
                    }

                    // If the next element is below our threshold, stop iterating and return the current element
                    if ($next && $next.offset().top > threshold) {
                        return false;
                    }
                });

                return result;
            },

            //For the LibraryManagement mixin...we implement this here because it's shared
            //and there's a requirement that mixins be mixed into the extended children
            onAddedToLibrary: function(storyId) {
                var $buttons = this.$(
                    this.libraryButton + "[data-story-id='" + storyId + "']"
                );
                $buttons
                    .children(".fa")
                    .addClass("fa-check")
                    .removeClass("fa-plus");
                $buttons
                    .children(".btn-library-text")
                    .html(wattpad.utils.trans("In Library"));
            },

            onRemovedFromLibrary: function(storyId) {
                var $buttons = this.$(
                    this.libraryButton + "[data-story-id='" + storyId + "']"
                );
                $buttons
                    .children(".fa")
                    .removeClass("fa-check")
                    .addClass("fa-plus");
                $buttons
                    .children(".btn-library-text")
                    .html(wattpad.utils.trans("Add to Library"));
            },

            onSocialShareSelected: function(evt) {
                wattpad.utils.pushEvent({
                    category: "reading",
                    action: $(evt.currentTarget).data("gtm-action"),
                    label: this.model.get("id")
                });

                window.te.push("event", "reading", "story", null, "share", {
                    storyid: this.model.get("group").id,
                    partid: this.model.get("id"),
                    channel: $(evt.currentTarget).data("share-channel")
                });
            },

            getDeepLinkPage: function() {
                return "story-reading";
            },

            onSendToFriend: function(evt) {
                var value = this.$(".send-input")
                    .val()
                    .trim();
                var $button = $(".on-send").attr("disabled", "disabled");
                $button.text(utils.trans("Sending"));
                Promise.resolve(
                        $.ajax({
                            type: "POST",
                            url: "/v4/stories/" +
                                this.model.get("group").id +
                                "/parts/" +
                                this.model.get("id") +
                                "/share",
                            data: {
                                target: value
                            }
                        })
                    )
                    .then(function() {
                        $(".on-send").removeAttr("disabled");
                        $button.text(utils.trans("Sent"));
                        _.delay(function() {
                            $button.text(utils.trans("Send to Friend"));
                        }, 5000);
                    })["catch"](function(resp) {
                        // todo: error message
                        $(".on-send").removeAttr("disabled");
                        window.alert(wattpad.utils.trans(resp));
                    });
            },

            onValidateSend: function(evt) {
                var value = $(evt.currentTarget).val();

                if (!!value.match(/[0-9-\(\)+]{10,}/) ||
                    value.match(/[^<>"']+@[^<>"']+\.[^<>"']{2,}/)
                ) {
                    $(".on-send").removeAttr("disabled");
                } else {
                    $(".on-send").attr("disabled", "disabled");
                }
            },

            onImageLoadError: function(evt) {
                window.te.push("event", "reading", "media", null, "empty", {
                    storyid: this.model.get("group").id,
                    partid: this.model.get("id"),
                    image_url: evt.currentTarget.getAttribute("src"),
                    user_agent: wattpad.utils.getUserAgent(100)
                });
            },

            onShowFullSizeImage: function(evt) {
                if (
                    $(evt.currentTarget)
                    .parent()
                    .parent()
                    .hasClass("author")
                ) {
                    return;
                }

                var viewerContents = $(evt.currentTarget)
                    .removeAttr("width height")
                    .addClass("zoomed-image")[0].outerHTML;

                var pictureViewer = new app.views.PictureViewer({
                    contents: viewerContents,
                    paragraph: $(evt.currentTarget).closest("p"),
                    mediaShare: this.mediaShare,
                    partModel: this.model
                });

                var modalContents = pictureViewer.render().$el.html();

                if ($("#picture-viewer").length === 0) {
                    $("#modals").append(modalContents);
                } else {
                    $("#picture-viewer").replaceWith(modalContents);
                }

                pictureViewer.setElement($("#picture-viewer"));

                window.te.push("event", "reading", "media", null, "expand", {
                    partid: this.model.get("id")
                });

                $("#picture-viewer").modal();
                $(".modal-backdrop").addClass("black");
            },

            onFullSizeBanner: function(evt) {
                var viewerContents = $(evt.currentTarget)
                    .html()
                    .trim(),
                    replaceWith =
                    "h=" + $(window).height() + "&amp;w=" + $(window).width() + "&amp;";

                viewerContents = viewerContents.replace(
                    /h=\d+&amp;w=\d+&amp;/,
                    replaceWith
                );

                var pictureViewer = new app.views.PictureViewer({
                    contents: viewerContents,
                    paragraph: $(evt.currentTarget).closest("p")
                });

                var modalContents = pictureViewer.render().$el.html();

                if ($("#picture-viewer").length === 0) {
                    $("#modals").append(modalContents);
                } else {
                    $("#picture-viewer").replaceWith(modalContents);
                }

                pictureViewer.setElement($("#picture-viewer"));

                window.te.push("event", "reading", "media", null, "expand", {
                    partid: this.model.get("id")
                });

                $("#picture-viewer").modal();
                $(".modal-backdrop").addClass("black");
            },

            trackPurchaseFailed: function(storyId, partId, price, partIndex) {
                var wallet = window.store.getState().wallet;

                window.te.push("event", "paywall", "purchase", null, "failed", {
                    page: "reading",
                    storyid: storyId,
                    partid: partId,
                    cost: price,
                    starting_balance: wallet.amount,
                    part_index: partIndex
                });
            },

            buyPaidContent: function(price, storyId, partId, partIndex) {
                var wallet = window.store.getState().wallet,
                    currencyId = wallet.id,
                    startingBalance = wallet.amount;

                window.te.push("event", "paywall", "purchase", null, "start", {
                    page: "reading",
                    storyid: storyId,
                    partid: partId,
                    cost: price,
                    starting_balance: startingBalance,
                    part_index: partIndex
                });

                var parts = this.model.get("group").parts || [];
                var partIds = _.pluck(parts, "id");
                return utils
                    .buyPaidContent(currencyId, storyId, partId)
                    .then(
                        function() {
                            // Use the balance at the start of purchase, not the
                            // post-purchase balance, for the event.
                            window.te.push("event", "paywall", "purchase", null, "complete", {
                                page: "reading",
                                storyid: storyId,
                                partid: partId,
                                cost: price,
                                starting_balance: startingBalance,
                                part_index: partIndex
                            });

                            // Cache bust everything
                            return utils.cacheBustPaidMetadata(storyId, partIds);
                        }.bind(this)
                    )
                    .catch(
                        function(err) {
                            this.trackPurchaseFailed(storyId, partId, price, partIndex);

                            utils.showToast(err);

                            // Purchase should have been prevented before the API call if balance too low
                            // Wallet is probably out of sync
                            window.store.dispatch(
                                window.app.components.actions.fetchWalletBalance(
                                    wattpad.user.username,
                                    true
                                )
                            );

                            throw err;
                        }.bind(this)
                    );
            },

            onBuyCoins: function(blockedPart) {
                $("#generic-modal").modal("hide");

                var story = this.model.get("group");
                setTimeout(
                    function() {
                        utils.showBuyCoinsModal(
                            "reading",
                            story.id,
                            blockedPart.id,
                            wattpad.utils.getAppLink("story-reading", this.model)
                        );
                    }.bind(this),
                    500
                );
            },

            showStoryPaywallModal: function(blockedPart) {
                const group = this.model.get("group");

                window.te.push("event", "paywall", "author", null, "view", {
                    page: "reading",
                    storyid: parseInt(group.id, 10),
                    partid: blockedPart.id,
                    author: group.user.name,
                    part_index: utils.getIndexForPartId(blockedPart.id, group)
                });

                var storyPaywallModal = new app.views.DummyReactView({
                    component: "StoryPaywallModal",
                    componentId: group.id,
                    componentData: {
                        group: group,
                        authorMessage: group.user.authorMessage,
                        onBuyCoins: () => this.onBuyCoins(blockedPart)
                    }
                });
                storyPaywallModal.render();

                $("#generic-modal .modal-body").html(storyPaywallModal.$el);
                $("#generic-modal").modal("show");
            },

            processPaidMetadata: function(data, paidMetadata) {
                // Process and set values for paid metadata, for easy use in
                // the reader template.
                const {
                    id: partId,
                    group: {
                        parts,
                        id: storyId
                    }
                } = data;

                // Normalize parts (first so isBlocked can be used below)
                data.group.parts = parts.map(part => {
                    var partMetadata = paidMetadata.parts[part.id];
                    if (!partMetadata) return part;

                    part.paywalled = partMetadata.paywalled;
                    part.isBlocked = partMetadata.paywalled && !partMetadata.has_access;
                    part.blockedMessage = partMetadata.author_message;

                    // Could include multiple currencies - default to first
                    const priceObj = _.first(partMetadata.price);
                    if (priceObj) {
                        part.price = priceObj.amount;
                    }

                    return part;
                });

                // Process top-level fields
                const priceMetadata = _.first(paidMetadata.stories[storyId].price);
                if (priceMetadata) {
                    data.storyPrice = priceMetadata.amount;
                }

                data.remainingBlockedParts = _.filter(parts, function(part) {
                    return part.isBlocked;
                }).length;

                const currentIndex = _.findIndex(parts, {
                    id: partId
                });
                const currentPart = parts[currentIndex];
                let nextPart;
                if (currentIndex < parts.length - 1) {
                    nextPart = parts[currentIndex + 1];
                }

                data.freePartsUntilPaywall = utils.numPartsBetweenCurrentAndPaywall(
                    parts,
                    currentPart
                );

                data.isPaidPreview = utils.isPaidPreview(parts);

                data.currentPartIsBlocked = currentPart.isBlocked;

                data.blockedPart = data.currentPartIsBlocked ? currentPart : nextPart;

                // Add event handlers
                data.buyPaidContent = this.buyPaidContent;
                data.showStoryPaywallModal = () =>
                    this.showStoryPaywallModal(data.blockedPart);
            }
        })
    );
})(window, wattpad, wattpad.utils, window.app, window.Monaco);