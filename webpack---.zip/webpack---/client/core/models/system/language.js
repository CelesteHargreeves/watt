(function(window, _, Monaco, wattpad, app) {
    "use strict";

    app.add("Language", Monaco.Model.extend());
})(window, _, Monaco, wattpad, window.app);