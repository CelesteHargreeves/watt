(function(window, _, wattpad, utils, app) {
    "use strict";

    app.add("Signup", Monaco.Model.extend({}));

    app.mixin(app.models.Signup, "ValidationModel", "SignupModel");
})(window, _, wattpad, wattpad.utils, window.app);