(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "BonusChapterTypeModel",
        app.models.BaseModel.extend({
            fetch: function(options) {
                var self = this;
                options = options || {};

                const storyId = self.attributes.storyId;
                const bonusParts = {};

                return Promise.resolve(
                        $.ajax({
                            type: "GET",
                            url: `/v5/bonus-content/paywall/${storyId}/parts/paid`
                        })
                    )
                    .then(bonusTypeParts => {
                        bonusTypeParts.forEach(part => {
                            if (part.is_free_part) return;

                            bonusParts[part.part_id] = {
                                bonusType: part.bonus_type || 0,
                                bonusTypeName: wattpad.utils.bonusChapterTypeName(
                                    part.bonus_type || 0
                                ),
                                releaseDate: part.release_date ? part.release_date * 1000 : 0
                            };
                        });

                        return bonusParts;
                    })
                    .catch(() => bonusParts);
            }
        })
    );
})(window, _, wattpad, window.app);