(function(window, _, wattpad, utils, app) {
    "use strict";

    app.add("GetMobile", Monaco.Model.extend({}));

    app.mixin(app.models.GetMobile, "ValidationModel", "GetMobileValRules");
})(window, _, wattpad, wattpad.utils, window.app);