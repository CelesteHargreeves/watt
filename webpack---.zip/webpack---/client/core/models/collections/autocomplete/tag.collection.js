(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "AutocompleteTag",
        Monaco.Collection.extend({
            resource: function() {
                return (
                    "autocomplete:tag" + (this.searchTerm ? ":" + this.searchTerm : "")
                );
            },

            url: function() {
                return "/api/v3/autocomplete/tag?term=" + this.searchTerm;
            },

            parse: function(resp) {
                return _.map(resp, function(item) {
                    return {
                        label: item
                    };
                });
            },

            cacheLocal: false
        })
    );
})(window, _, wattpad, window.app);