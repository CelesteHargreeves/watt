import {
    fetchComments,
    CommentsNamespaces
} from "@wattpad/client-platform-comments";

(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "StoryPartComments",
        app.collections.IncrementalFetchNextUrl.extend({
            // Properties
            model: app.models.CommentModel,

            arrayKey: "comments",

            // AUDI-4895: Disable comments cache for trust team only
            cacheLocal: !wattpad.testGroups.DISABLE_COMMENT_CACHE,
            cacheExpire: 5,

            fields: [{
                    comments: [
                        "id",
                        "body",
                        "createDate",
                        "isOffensive",
                        "parentId",
                        "numReplies",
                        {
                            author: ["name", "avatar"]
                        }
                    ]
                },
                "total"
            ],

            partId: null,

            defaultUrl: function() {
                return "/v4/parts/" + this.partId + "/comments";
            },

            resource: function() {
                return "part." + this.partId + ".comments";
            },

            parse: function(response) {
                response = app.collections.IncrementalFetchNextUrl.prototype.parse.apply(
                    this,
                    arguments
                );

                // TEMPORARY FIX:
                // comment requests need to be authenticated for blocking purposes.
                // api.wattpad.com requests are not currently sending auth cookies, so
                // we want to strip the host and hit the relative path until PIE-3001
                // is addressed, forcing the browser to hit www.wattpad.com
                if (this.nextUrl && this.nextUrl.startsWith("https://api.wattpad")) {
                    let hostRegex = /https:\/\/\w+.\w+.(com|dev-prod)/;
                    this.nextUrl = this.nextUrl.replace(hostRegex, "");
                }

                if (this.initialParse && this.nextUrl) {
                    this.initialParse = false;
                    this.nextUrl = this.nextUrl.replace(
                        "limit=" + this.limit,
                        "limit=" + this.normalLimit
                    );
                    this.limit = this.normalLimit;
                }
                return response;
            },

            initialize: function(collection, options) {
                app.collections.IncrementalFetch.prototype.initialize.apply(
                    this,
                    arguments
                );
                options = options || {};
                if (
                    typeof options.partId === "undefined" ||
                    options.partId.toString().trim() === ""
                ) {
                    throw new Error(
                        "A StoryPartComments collection requires a partId to be passed to the options hash on init"
                    );
                }
                this.partId = options.partId;
                this.storyAuthor = options.storyAuthor || "";
                this.limit = options.limit;
                this.commentLocation = "story-part";
                this.storyId = options.storyId;
                this.afterComment = null;
                this.hasMoreComments = false;

                if (options.initialLimit) {
                    this.normalLimit = this.limit;
                    this.limit = options.initialLimit;
                    this.initialParse = true;
                }
            },

            //Override collection prepareModel to inject username into our models
            _prepareModel: function(attrs, options) {
                if (!attrs.storyAuthor && this.storyAuthor) {
                    attrs.storyAuthor = this.storyAuthor;
                }
                return app.collections.IncrementalFetch.prototype._prepareModel.apply(
                    this,
                    arguments
                );
            },

            fetchNextSet: function(options) {
                const resource = {
                    namespace: CommentsNamespaces.PARTS,
                    partId: this.partId.toString()
                };
                return fetchComments(resource, this.afterComment, options ? .limit)
                    .then(data => {
                        const {
                            hasMore,
                            comments,
                            after
                        } = data;
                        this.add(comments);
                        this.hasMoreComments = hasMore;
                        this.afterComment = after;
                        this.trigger("fetchNext:done");
                    })
                    .catch(() => {
                        wattpad.utils.showToast(
                            wattpad.utils.trans("Something went wrong. Please try again"), {
                                type: "dismissable"
                            }
                        );
                    });
            },

            hasMore: function() {
                /*
                 * We don't want to show the "Show More" option if it is a deeplinked comment.
                 * Instead, the user should click the "Return to all comments".
                 */
                if (this.models.length === 1 && this.models[0].isDeepLink) {
                    return false;
                } else {
                    return this.hasMoreComments;
                }
            }
        })
    );
})(window, _, wattpad, window.app);