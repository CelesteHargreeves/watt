(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "DiscoverModuleLists",
        app.collections.BaseCollection.extend({
            model: app.models.DiscoverModuleListItem,

            arrayKey: "lists"
        })
    );
})(window, _, wattpad, window.app);