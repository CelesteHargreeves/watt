(function(window, _, wattpad, app) {
    "use strict";

    app.add("Followers", app.collections.Base.extend({}));
})(window, _, wattpad, window.app);