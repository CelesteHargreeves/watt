import {
    fetchComments,
    CommentsNamespaces
} from "@wattpad/client-platform-comments";
(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "CommentReplies",
        app.collections.IncrementalFetchNextUrl.extend({
            // Properties
            model: app.models.CommentModel,

            arrayKey: "replies",

            // AUDI-4895: Disable comments cache for trust team only
            cacheLocal: !wattpad.testGroups.DISABLE_COMMENT_CACHE,
            cacheExpire: 5,

            fields: [{
                    replies: [
                        "id",
                        "body",
                        "partId",
                        "createDate",
                        "isOffensive",
                        "isReply",
                        "parentId",
                        {
                            author: ["name", "avatar"]
                        }
                    ]
                },
                "total"
            ],

            parentId: null,

            defaultUrl: function() {
                return "/v4/comments/" + this.parentId + "/replies";
            },

            resource: function() {
                return "comments." + this.parentId + ".replies";
            },

            initialize: function(collection, options) {
                app.collections.IncrementalFetch.prototype.initialize.apply(
                    this,
                    arguments
                );
                options = options || {};
                if (
                    typeof options.parentId === "undefined" ||
                    options.parentId.toString().trim() === ""
                ) {
                    throw new Error(
                        "A CommentReplies collection requires a parentId to be passed to the options hash on init"
                    );
                }
                this.limit = options.limit || 10;
                this.parentId = options.parentId;
                this.storyAuthor = options.storyAuthor;
                this.partId = options.partId;
                this.isReply = options.isReply || true;
                this.paragraphId = options.paragraphId;
                this.commentLocation = `${options.commentLocation}-replies`;
                this.storyId = options.storyId;
                this.afterComment = null;
                this.hasMoreComments = false;

                /*
                 * Adding or deleting a reply to an inline comment should trigger
                 * app:story:inlinecomment, which should re-render the comment marker for that
                 * specific paragraph. See fetchCommentCounts in core/views/story-reading.js.
                 */
                if (options.paragraphId) {
                    this.on(
                        "sync",
                        function() {
                            app.trigger("app:story:inlinecomment", options.paragraphId);
                        },
                        this
                    );
                }
            },

            fetchNextSet: function(options) {
                const resource = {
                    namespace: CommentsNamespaces.COMMENTS,
                    commentId: this.parentId
                };
                return fetchComments(resource, this.afterComment)
                    .then(data => {
                        const {
                            hasMore,
                            comments,
                            after
                        } = data;
                        this.add(comments);
                        this.hasMoreComments = hasMore;
                        this.afterComment = after;
                        this.trigger("fetchNext:done");
                    })
                    .catch(() => {
                        wattpad.utils.showToast(
                            wattpad.utils.trans("Something went wrong. Please try again"), {
                                type: "dismissable"
                            }
                        );
                    });
            },

            hasMore: function() {
                return this.hasMoreComments;
            },

            _prepareModel: function(attrs, options) {
                if (!attrs.storyAuthor && this.storyAuthor) {
                    attrs.storyAuthor = this.storyAuthor;
                }
                if (attrs.attributes) {
                    attrs.attributes.paragraphId = this.paragraphId;
                } else {
                    attrs.paragraphId = this.paragraphId;
                }
                return app.collections.IncrementalFetch.prototype._prepareModel.apply(
                    this,
                    arguments
                );
            }
        })
    );
})(window, _, wattpad, window.app);