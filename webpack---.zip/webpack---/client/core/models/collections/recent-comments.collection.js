(function(window, _, wattpad, app) {
    "use strict";

    /*
     * "Recent Comments" in StoryLanding show comments following the certain rules:
     * - Not by the author
     * - Between 60 and 300 characters
     * - Caches the data for the day
     * - Not offensive (i.e. no swearing)
     *
     * It also fetches only 30 comments from the story before filtering, so if none of the 30 comments
     * fetched matches the critera, no comments are shown.
     * See the web repo - models/story_group.php and controllers/api/v4/stories.php for more details.
     */

    app.add(
        "RecentComments",
        app.collections.IncrementalFetch.extend({
            model: app.models.CommentModel,

            arrayKey: "comments",

            fields: [{
                    comments: [
                        "id",
                        "body",
                        "createDate",
                        "isOffensive",
                        "parent_id",
                        {
                            author: ["name", "avatar"]
                        }
                    ]
                },
                "total",
                "nextUrl"
            ],

            storyId: null,

            url: function() {
                return "/v4/stories/" + this.storyId + "/recent_comments";
            },

            resource: function() {
                return "story." + this.storyId + ".recent-comments";
            },

            initialize: function(collection, options) {
                app.collections.IncrementalFetch.prototype.initialize.apply(
                    this,
                    arguments
                );

                options = options || {};
                if (
                    typeof options.storyId === "undefined" ||
                    options.storyId.toString().trim() === ""
                ) {
                    throw new Error(
                        "A RecentComments collection requires a storyId to be passed to the options hash on init"
                    );
                }
                this.storyId = options.storyId;
            }
        })
    );
})(window, _, wattpad, window.app);