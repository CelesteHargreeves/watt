import {
    fetchComments,
    CommentsNamespaces
} from "@wattpad/client-platform-comments";
(function(window, _, wattpad, app) {
    "use strict";

    /*
     * A collection of inline comments for a specific paragraph ID.
     */
    app.add(
        "InlineComments",
        app.collections.IncrementalFetchNextUrl.extend({
            model: app.models.CommentModel,

            arrayKey: "comments",

            fields: [{
                    comments: [
                        "body",
                        "createDate",
                        "startPosition",
                        "endPosition",
                        "id",
                        "isOffensive",
                        "isReply",
                        "numReplies",
                        "paragraphId",
                        "parentId",
                        "partId",
                        "deeplink",
                        {
                            author: ["avatar", "name"]
                        }
                    ]
                },
                "total"
            ],

            cacheLocal: false,

            cacheExpire: 5,

            defaultUrl: function() {
                return (
                    "/v4/parts/" +
                    this.partId +
                    "/paragraphs/" +
                    this.paragraphId +
                    "/comments"
                );
            },

            initialize: function(collection, options) {
                app.collections.IncrementalFetchNextUrl.prototype.initialize.apply(
                    this,
                    arguments
                );
                options = options || {};

                // Extracts the paragraph text for the specific paragraphId from the StoryText model
                this.pageText = _.find(options.storyPart.loadedPages, function(obj) {
                    return obj.getParagraphById(options.paragraphId);
                });
                if (!this.pageText) {
                    throw new Error(
                        "The selected paragraph ID for this story does not exist."
                    );
                }
                this.partId = options.storyPart.get("id");
                this.commentId = options.commentId;
                this.paragraphId = options.paragraphId;
                this.paragraphText = this.pageText.getParagraphById(
                    options.paragraphId
                );
                this.storyAuthor = options.storyPart.get("group").user.username;
                this.commentLocation = "paragraph";
                this.storyId = options.storyId;
                this.afterComment = null;
                this.hasMoreComments = false;

                /*
                 * For now, each inline comment is set to the entire paragraph text length.
                 * Later on, we may give (Web) users the option to highlight specific substrings within the paragraph when creating inline comments.
                 */
                this.startPosition = 0;
                this.endPosition = this.paragraphText.length;

                /*
                 * Adding or deleting a reply to an inline comment should trigger
                 * app:story:inlinecomment, which should re-render the comment marker for that
                 * specific paragraph. See fetchCommentCounts in core/views/story-reading.js.
                 */
                if (options.paragraphId) {
                    this.on(
                        "sync",
                        function() {
                            app.trigger("app:story:inlinecomment", options.paragraphId);
                        },
                        this
                    );
                }
            },

            fetchNextSet: function(options) {
                const resource = {
                    namespace: CommentsNamespaces.PARAGRAPHS,
                    partId: this.partId.toString(),
                    paragraphId: this.paragraphId
                };
                return fetchComments(resource, this.afterComment)
                    .then(data => {
                        const {
                            hasMore,
                            comments,
                            after
                        } = data;
                        this.add(comments);
                        this.hasMoreComments = hasMore;
                        this.afterComment = after;
                        this.trigger("fetchNext:done");
                    })
                    .catch(() => {
                        wattpad.utils.showToast(
                            wattpad.utils.trans("Something went wrong. Please try again"), {
                                type: "dismissable"
                            }
                        );
                    });
            },

            hasMore: function() {
                /*
                 * We don't want to show the "Show More" option if it is a deeplinked comment.
                 * Instead, the user should click the "Return to all comments".
                 */
                if (this.models.length === 1 && this.models[0].isDeepLink) {
                    return false;
                } else {
                    return this.hasMoreComments;
                }
            },

            _prepareModel: function(attrs, options) {
                if (!attrs.storyAuthor && this.storyAuthor) {
                    attrs.storyAuthor = this.storyAuthor;
                }
                return app.collections.IncrementalFetch.prototype._prepareModel.apply(
                    this,
                    arguments
                );
            }
        })
    );
})(window, _, wattpad, window.app);