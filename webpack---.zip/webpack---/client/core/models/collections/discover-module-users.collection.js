(function(window, _, wattpad, app) {
    "use strict";

    app.add(
        "DiscoverModuleUsers",
        app.collections.BaseCollection.extend({
            model: app.models.DiscoverModuleUserItem
        })
    );
})(window, _, wattpad, window.app);