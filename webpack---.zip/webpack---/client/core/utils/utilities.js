import getHardcodedAdString from "../../../helpers/handlebars/get-hardcoded-ad-string";
import getPlacementConfiguration from "../../../helpers/ads/get-placement-configuration";
import getAdzerkTargeting from "../../../helpers/handlebars/get-adzerk-targeting";
import getAdSize from "../../../helpers/handlebars/get-ad-size";

import getSearchTitle from "../../../helpers/client.get-search-title";
import tagsHelper from "../../../helpers/tags-helper";
import {
    isForcedSignupSession
} from "../../../helpers/forced-signup";
import {
    isForcedSignupExemptView
} from "../../../helpers/client.forced-signup";
import {
    isUnsafe
} from "../../../helpers/is-unsafe";

(function(window, _, wattpad) {
    "use strict";

    wattpad = wattpad || (window.wattpad = {});
    var utils = wattpad.utils || (wattpad.utils = {});

    utils.bootstrapReactRoot = function() {
        var rootComponent = window.app.components["ReactRoot"];
        var wrappedComponent = window.app.components.withRedux(
            rootComponent,
            window.store
        );
        ReactDOM.render(
            React.createElement(wrappedComponent),
            document.getElementById("react-client-root")
        );
    };

    utils.getWrapParams = function(args) {
        return Array.prototype.slice.call(args, 1);
    };

    utils.isToday = function(date) {
        var today = moment();
        return (
            today.isSame(date, "day") &&
            today.isSame(date, "month") &&
            today.isSame(date, "year")
        );
    };

    // Intercepts the paste event and returns only plaintext
    utils.pastePlainText = function(e) {
        var content;
        e.preventDefault();
        if ((e.originalEvent || e).clipboardData) {
            content = (e.originalEvent || e).clipboardData.getData("text/plain");
            document.execCommand("insertText", false, content);
        } else if (window.clipboardData) {
            //  Solution for IE
            content = window.clipboardData.getData("Text");
            // Solution for < IE 11 and Edge
            var selection = document.selection || document.getSelection();
            selection.createRange().pasteHTML(content);
        }
        return content;
    };

    utils.pixelRatio = function(decimal) {
        var dpr = window.devicePixelRatio;

        if (!decimal) {
            return (
                dpr ||
                (this.pixelRatio(3) ?
                    3 :
                    this.pixelRatio(2) ?
                    2 :
                    this.pixelRatio(1.5) ?
                    1.5 :
                    this.pixelRatio(1) ?
                    1 :
                    0)
            );
        }

        if (dpr && dpr > 0) {
            return dpr >= decimal;
        }

        var matchMedia = window.matchMedia || window.msMatchMedia;

        if (!matchMedia) {
            return false;
        }

        decimal = "only all and (min--moz-device-pixel-ratio:" + decimal + ")";
        if (matchMedia(decimal).matches) {
            return true;
        }
        return !!matchMedia(decimal.replace("-moz-", "")).matches;
    };

    utils.getUserAgent = function(maxLength) {
        if (maxLength > 0) {
            return window.navigator.userAgent.substr(0, maxLength);
        }
        return window.navigator.userAgent;
    };

    utils.getCookie = function(key) {
        var result = new RegExp(
            "(?:^|; )" + encodeURIComponent(key) + "=([^;]*)"
        ).exec(window.document.cookie);
        if (result && result.length > 0) {
            return window.decodeURIComponent(result[1]);
        }
        return null;
    };

    //sending a 0 in the days column will create a cookie
    //that expires at the end of your session
    utils.setCookie = function(key, value, days, baseDomain) {
        var expires = "",
            date;

        if (days !== 0) {
            days = days && _.isNumber(days) ? days : 365;
            date = new Date();
            date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
            expires += "; expires=" + date.toGMTString();
        }

        value = window.encodeURIComponent(value);
        var cookieString =
            key + "=" + value + expires + "; path=/; SameSite=Lax; Secure;";
        if (baseDomain) {
            var domain = window.document.domain.split(".");
            domain =
                "." + domain[domain.length - 2] + "." + domain[domain.length - 1];
            cookieString += " domain=" + domain + ";";
        }
        window.document.cookie = cookieString;
        return cookieString;
    };

    utils.destroyCookie = function(cookie) {
        window.document.cookie =
            cookie + "=; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
    };

    utils.supportPushState = function() {
        return !!(window.history && window.history.pushState);
    };

    utils.serializeObject = function(array) {
        var o = {};
        $.each(array, function() {
            if (o[this.name] !== undefined) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || "");
            } else {
                o[this.name] = this.value || "";
            }
        });
        return o;
    };

    utils.modernizr = function(test) {
        var modernizrTest, i;
        if (!window.Modernizr) {
            return false;
        }

        //-- BEGIN False Positives --//
        if (utils.isOperaMini) {
            if (test === "input.placeholder") {
                return false;
            }
        }

        if (utils.isLTIE10Mobile) {
            if (test === "fontface") {
                return false;
            }
        }
        //-- END False Positives --//

        modernizrTest = window.Modernizr;
        test = test.split(".");

        for (i = 0; i < test.length; i++) {
            modernizrTest = modernizrTest[test[i]];
        }

        return modernizrTest;
    };

    utils.supportsTransition = function() {
        var thisBody = window.document.body || window.document.documentElement,
            thisStyle = thisBody.style;

        return (
            thisStyle.transition !== undefined ||
            thisStyle.WebkitTransition !== undefined ||
            thisStyle.MozTransition !== undefined ||
            thisStyle.MsTransition !== undefined ||
            thisStyle.OTransition !== undefined
        );
    };
    utils.transitionEndStrings =
        "webkitTransitionEnd oTransitionEnd MSTransitionEnd transitionend";

    utils.scrollIntoView = function(element) {
        var $element;
        if (element) {
            $element = $(element);
            element = $element[0];

            if ($element.length) {
                //Opera Mini & Android < 3
                if (
                    utils.isOperaMini ||
                    utils.isAndroidStockBrowser(2, true) ||
                    !element.scrollIntoView
                ) {
                    window.scrollTo(0, $element.offset().top + 10);
                } else {
                    element.scrollIntoView(true);
                }
            }
        }
    };

    utils.isOperaMini = (function() {
        return Boolean(window.navigator.userAgent.match(/(Opera Mini)/));
    })();

    utils.isLTIE10Mobile = (function() {
        return (
            Boolean(window.navigator.userAgent.match(/(MSIE 9.+ IEMobile)/)) ||
            Boolean(window.navigator.userAgent.match(/(MSIE 8.+ IEMobile)/)) ||
            Boolean(window.navigator.userAgent.match(/(MSIE 7.+ IEMobile)/))
        );
    })();

    utils.chromeAndroidVer = function() {
        var chromeRegex = /Chrome\/([0-9.]+)\ Mobile/;
        var chromeVer = chromeRegex.exec(window.navigator.userAgent);
        return chromeVer ? parseInt(chromeVer[1]) : 0;
    };

    /*
     * Checks if the current browser is android and what the version is
     * @version = android maj. version to check
     * @eq = true(exact match), false(less than or equal to)
     */
    utils.isAndroid = function(version, eq) {
        var major = 0;

        if (!version || typeof version != "number") {
            return Boolean(window.navigator.userAgent.match(/(Android)/));
        } else if (Boolean(window.navigator.userAgent.match(/(Android)/))) {
            major = window.navigator.userAgent.match(/Android (.)/);

            //Fix for the case when the major version is missing (firefox)
            if (major) {
                major = parseInt(major[1], 10);
            } else {
                return false;
            }

            if (!eq) {
                return major >= version;
            }

            return major === version;
        }

        return false;
    };

    /**
     * format a number
     *
     * @param integer value: number to be formatted
     * @param integer decimals: length of decimal, default is 0
     * @param integer sections: length of sections, default is 3
     */
    utils.format = function(value, decimals, sections) {
        var re =
            "\\d(?=(\\d{" +
            (sections || 3) +
            "})+" +
            (decimals > 0 ? "\\." : "$") +
            ")";
        return value
            .toFixed(Math.max(0, ~~decimals))
            .replace(new RegExp(re, "g"), "$&,");
    };
    Handlebars.registerHelper("format", utils.format);

    /*
     * Checks to ensure that the client browser is the stock android browser
     */
    utils.isAndroidStockBrowser = function(version, eq) {
        if (utils.isAndroid(version, eq)) {
            return (
                parseFloat(
                    window.navigator.userAgent.match(/AppleWebKit\/([\d.]+)/)[1]
                ) < 535
            );
        }

        return false;
    };

    utils.openOnDesktop = function(win) {
        win = win && win.location ? win : window;
        var sanitizedUrl = utils.getDesktopUrl(win);

        win.document.cookie = "mw-no=true; path=/";

        if (win.location.href === sanitizedUrl) {
            win.location.reload();
        } else {
            win.location.href = sanitizedUrl;
        }
    };

    utils.getDesktopUrl = function(win) {
        win = win && win.location ? win : window;
        //sanitize url
        return win.location.href.replace(/\/paragraph\/[\w]+/, "");
    };

    utils.hideAddressBar = function() {
        //remove address bar once loaded (WEB-910)
        //Opera Mini can't use setTimeout
        if (wattpad.utils.isOperaMini) {
            utils.scrollToTop();
        }

        window.setTimeout(function() {
            if (window.scrollY < 5) {
                utils.scrollToTop();
            }
        }, 0);
    };

    utils.scrollToTop = function() {
        var scrollTop =
            window.document.body.scrollTop ||
            window.document.documentElement.scrollTop,
            scrollTo = window.scrollTo;

        if (scrollTo) {
            scrollTo(0, 0);
        } else {
            scrollTop = 0;
        }
    };

    utils.currentUser = function() {
        var result = app.get("currentUser");

        if (!result) {
            result = new app.models.User(wattpad.user);
            app.set("currentUser", result, false);
        }

        return result;
    };

    // Emulates the PHP urlEncode() function
    utils.urlEncode = function(str) {
        str = (str + "").toString();

        var urlEncodedString = "";

        try {
            urlEncodedString = encodeURIComponent(str).replace(/!/g, "%21");
        } catch (error) {
            // If the string we're encoded appears to have been shortened, account for the ellipsis when cutting off the end
            if (str.substr(-3) == "...") {
                str = str.substr(0, str.length - 4) + "...";
            } else {
                str = str.substr(0, str.length - 1);
            }
            urlEncodedString = encodeURIComponent(str).replace(/!/g, "%21");
        }

        return urlEncodedString
            .replace(/'/g, "%27")
            .replace(/\(/g, "%28")
            .replace(/\)/g, "%29")
            .replace(/\*/g, "%2A")
            .replace(/%20/g, "+");
    };

    utils.urlEncodeWithSpace = function(str) {
        str = (str + "").toString();

        return encodeURIComponent(str)
            .replace(/!/g, "%21")
            .replace(/'/g, "%27")
            .replace(/\(/g, "%28")
            .replace(/\)/g, "%29")
            .replace(/\*/g, "%2A");
    };

    utils.urlDecode = function(str) {
        str = (str + "").toString();

        return decodeURIComponent(
            str
            .replace(/%21/g, "!")
            .replace(/%27/g, "'")
            .replace(/%28/g, "(")
            .replace(/%29/g, ")")
            .replace(/%2A/g, "*")
            .replace(/\+/g, " ")
        );
    };

    // Returns an array of mention(s) or null
    utils.getMentions = function(text) {
        var regex = /((?![\/\.\#])(?:^|\W))@([\S\-]+)/gi; // same regex from linkify()
        return text.match(regex);
    };

    utils.linkify = function(text, options) {
        var patterns = {
                mention: /((?![\/\.\#])(?:^|\W))@([\w\d\-]+)/gi,
                url: /(http(s)?:\/\/[^\s]+)/gi,
                tag: /(?:^|\W)#([^\s\?\/]+)/gi
            },
            replacements = {
                mention: '$1<a class="on-user-mention" href="/user/$2">@$2</a>',
                url: '<a href="$1" rel="nofollow" target="_blank">$1</a>',
                tag: ' <a href="/tags/$1" class="on-navigate">#$1</a>'
            };

        options = options || {};

        if (options.hash) {
            if (options.hash.sanitization) {
                options.sanitization = options.hash.sanitization;
            }
        }
        options.sanitization = options.sanitization || "sanitize";
        options.doTags = options.doTags === false ? false : true;
        options.doUrl =
            options.doUrl === false || options.sanitization === "unsanitize" ?
            false :
            true;
        options.doMention = options.doMention === false ? false : true;

        switch (options.sanitization) {
            case "sanitize":
                text = wattpad.utils.sanitizeHTML(text);
                break;
            case "unsanitize":
                text = wattpad.utils.unsanitizeHTML(text);
                break;
            case "none":
                break;
        }
        if (options.doMention) {
            text = text.replace(patterns.mention, replacements.mention);
        }
        if (options.doUrl) {
            text = text.replace(patterns.url, replacements.url);
        }
        if (options.doTags) {
            text = text.replace(patterns.tag, replacements.tag);
        }

        return text;
    };

    /*
     find and return media links in a text, optionally replacing the found
     media link with a placeholder

     options          object
     text          string    required - where the search for media links will be performed
     placeholder   string    optional - media links found in the text will be replaced with this if provided
     firstOnly     boolean   optional - flag indicating if only the first media link should be processed (default: false)
     */
    utils.findMediaInText = function(options) {
        var patterns = {
                image: /(?:https?:)?\/\/(?:[\w\-]+\.)+[a-z]{2,6}(?:\/[^\/#?]+)+\.(?:jpg|gif|png)/
            },
            found = [],
            flags = "i",
            re,
            items;

        if (options.text) {
            options.placeholder =
                options.placeholder !== void 0 ? "" + options.placeholder : false;
            options.firstOnly = !!options.firstOnly;
            if (!options.firstOnly) {
                flags += "g";
            }

            _.each(patterns, function(pattern) {
                re = new RegExp(pattern.source, flags);
                items = options.text.match(re);
                if (items) {
                    if (options.placeholder) {
                        options.text = options.text.replace(re, options.placeholder);
                    }
                    found = found.concat(items);
                }
            });
        }

        return {
            text: options.text,
            media: found
        };
    };

    utils.stopEvent = function(evt) {
        var srcEvent =
            evt && evt.hasOwnProperty("gesture") ? evt.gesture.srcEvent : evt,
            cmdOrCtrlKeyPressed = srcEvent ?
            srcEvent.metaKey || srcEvent.ctrlKey :
            false;

        if (evt && !cmdOrCtrlKeyPressed) {
            evt.preventDefault();
            evt.stopPropagation();
            // tap event -> stop touchstart & touchend events
            if (evt.hasOwnProperty("gesture")) {
                evt.gesture.preventDefault();
                evt.gesture.stopPropagation();
                evt.gesture.stopDetect();
            }
        }
    };

    utils.supportLocalstorage = function() {
        var app = window.app,
            test = "wattpad.com.test";

        try {
            window.localStorage.setItem(test, test);
            window.localStorage.removeItem(test);
            return true;
        } catch (e) {
            if (
                DOMException &&
                e &&
                (DOMException.QUOTA_EXCEEDED_ERR &&
                    e.code &&
                    e.code === DOMException.QUOTA_EXCEEDED_ERR)
            ) {
                if (typeof app !== "undefined" && app.local !== "undefined") {
                    app.local.clear();
                }
                return true;
            } else {
                window.wpLog.exception(e, "localstorage-not-supported");
            }
        }
        return false;
    };

    utils.redirectToCSR = function(pathname, options) {
        options = options || {};
        app.router.navigate(pathname, options);
    };

    utils.redirectToServer = function(url) {
        if ($("body").hasClass("js-app-off")) {
            return;
        } else if (url) {
            utils._redirectToServer(url);
        } else {
            utils._reloadFromServer();
        }
    };

    utils._redirectToServer = function(url) {
        window.location.href = url;
    };

    utils._reloadFromServer = function() {
        window.location.reload();
    };

    utils.goBackInHistory = function() {
        window.history.go(-1);
    };

    utils.getWindowSearch = function() {
        return window.location.search;
    };

    utils.reloadWithQuery = function(query) {
        window.location =
            "//" +
            window.location.hostname +
            window.location.pathname +
            query +
            window.location.hash;
    };

    utils.cacheBust = function(resources, options, id, isModel) {
        var result = [];
        resources = Array.isArray(resources) ? resources : [resources];
        options = Array.isArray(options) ? options : [options];

        _.forEach(resources, function(item, i) {
            var resource, prom;
            if (isModel) {
                resource = new app.models[item](options[i]);
            } else {
                resource = new app.collections[item]([], options[i]);
            }

            if (resource instanceof app.collections.IncrementalFetch) {
                prom = Promise.resolve(resource.fetchNextSet({
                    localOnly: true
                }));
            } else {
                prom = Promise.resolve(resource.fetch({
                    localOnly: true
                }));
            }

            prom.then(function() {
                if (!id || resource.get(id)) {
                    app.local._clearItem(_.result(resource, "resource"));
                }
            });

            result.push(prom);
        });

        return Promise.all(result);
    };

    utils.showBuyCoinsModal = function(page, storyId, partId, appLink) {
        function trackCoinsModal(element, action) {
            var wallet = window.store.getState().wallet;

            window.te.push("event", "coins", "packages", element, action, {
                page: page,
                storyid: storyId,
                partid: partId,
                starting_balance: wallet.amount
            });
        }

        window.app.components.showBuyCoinsModal({
            isDesktop: app.get("device").isDesktop(),
            appLink: appLink,
            trackCoinsEvents: trackCoinsModal
        });
    };

    utils.shouldSeePaidOnboarding = function(storyIsPaywalled = false) {
        // Use a cookie to track if the user has seen the paid
        // onboarding, so they only see it once.
        const hasSeenPaidOnboarding =
            parseInt(wattpad.utils.getCookie("seen-paid-onboard")) || false;

        return !hasSeenPaidOnboarding && storyIsPaywalled;
    };

    utils.showPaidOnboardingAfterDelay = function() {
        const MODAL_SHOW_DELAY = 1500;

        // The user might interact with the page before the modal is
        // shown. The paid onboarding is a very important, one-time
        // interaction, so block other interactions until the modal opens.
        $("body").addClass("js-app-off");

        const startRoute = window.location.pathname;
        setTimeout(() => {
            // TODO: evaluate if we can use inert for this:
            // https://css-tricks.com/focus-management-and-inert/

            // NOTE: THIS LINE MUST RUN, or the app will be unusable.
            // Don't add any code that could cause this to not run in any case.
            $("body").removeClass("js-app-off");

            // The user may have navigated to a place where the onboarding
            // modal shouldn't be shown, so skip showing the modal this
            // time.
            const currentRoute = window.location.pathname;
            const userHasNavigated = currentRoute !== startRoute;
            if (userHasNavigated) {
                return;
            }

            window.app.components.showPaidOnboardingModal({
                premium: wattpad.utils.currentUser().get("isPremium")
            });
        }, MODAL_SHOW_DELAY);
    };

    utils.getAppUrl = function(medium) {
        medium = medium || "mobileweb";

        var device = app.get("device");
        if (device && device.is.ios) {
            return "https://my.w.tt/kwXixwM3J5";
        }
        if (device && device.is.huawei) {
            return "https://appgallery5.huawei.com/#/app/C100252597";
        }
        if (device && device.is.android) {
            return "https://my.w.tt/ngdWYy82J5";
        }
        if (device && device.is.kindle) {
            return "https://www.amazon.com/Unlimited-Stories-Wattpad-Free-Reader/dp/B004K56MNU";
        }
        if (device && device.is.windows) {
            return "https://www.microsoft.com/store/apps/9nblggh6gm17";
        }
        return "/getmobile";
    };

    utils.getAllAppUrls = function(medium) {
        medium = medium || "mobileweb";

        return {
            ios: "https://my.w.tt/kwXixwM3J5",
            android: "https://my.w.tt/ngdWYy82J5",
            kindle: "https://www.amazon.com/Unlimited-Stories-Wattpad-Free-Reader/dp/B004K56MNU",
            windows: "https://www.microsoft.com/store/apps/9nblggh6gm17",
            huawei: "https://appgallery5.huawei.com/#/app/C100252597",
            fallback: "/getmobile"
        };
    };

    utils.openPopup = function(url, title, width, height) {
        var dualScreenLeft =
            window.screenLeft !== undefined ? window.screenLeft : screen.left,
            dualScreenTop =
            window.screenTop !== undefined ? window.screenTop : screen.top,
            windowWidth = window.innerWidth ?
            window.innerWidth :
            document.documentElement.clientWidth ?
            document.documentElement.clientWidth :
            screen.width,
            windowHeight = window.innerHeight ?
            window.innerHeight :
            document.documentElement.clientHeight ?
            document.documentElement.clientHeight :
            screen.height,
            left = windowWidth / 2 - width / 2 + dualScreenLeft,
            top = windowHeight / 2 - height / 2 + dualScreenTop,
            newWindow = window.open(
                url,
                title,
                "scrollbars=yes, width=" +
                width +
                ", height=" +
                height +
                ", top=" +
                top +
                ", left=" +
                left
            );

        if (window.focus) {
            newWindow.focus();
        }

        return newWindow;
    };

    /* This function returns a reordered list to make column display easier
     * The input list needs to be pre-sorted ( ie. this is the order the list
     * should be in if numColumns = 1 )

    ie. input = ( [a, b, c, d, e, f ], 2 )
     returns = [ a, d, b, e, c, f ]

    input = ( [ a, b, c, d, e, f, g, h ], 3 )
    returns = [ a, d, g, b, e, h, c, f ]

    */
    utils.sortByColumns = function(list, numColumns) {
        var newList = [],
            count = 0,
            adjustCount = 0,
            colNum = 0,
            rowNum = 0,
            numInLastRow = list.length % numColumns;

        while (newList.length < list.length) {
            while (count < list.length) {
                //Incrementally walk the list to pick out the right values
                newList.push(list[count]);
                count += Math.ceil(list.length / numColumns) - adjustCount;
                //Next column
                colNum++;

                // Last row will not be full; adjust `count` accordingly
                if (numInLastRow && colNum >= numInLastRow) {
                    adjustCount = 1;
                }

                if (newList.length >= list.length) {
                    break;
                }
            }

            colNum = 0;
            adjustCount = 0;
            //Next row
            count = ++rowNum;
        }

        return newList;
    };

    /**
     * printf will take the text, parse for %s, and replace each subsequent one
     * with the value that matches index in args (string array)
     *
     */

    utils.sprintf = function(text, args) {
        var s = "";
        if (args.length === 0) {
            return text;
        }

        var pieces = text.split("%s");
        for (var i = 0; i < pieces.length; i++) {
            s +=
                pieces[i] +
                (args[i] !== null && args[i] !== undefined ? args[i].toString() : "");
        }

        return s;
    };

    // Returns the URI part of a request URL
    //
    // eg. For URL: https://www.wattpad.com/foo/bar?baz=1 it returns /foo/bar?baz=1.
    //
    utils.extractUriFromUrl = function(url) {
        let schemeHostPortMatcher = /^((https?:)?\/\/)?[a-z-.]*[a-z-](:\d+)?(?=\/)/i;
        return url.replace(schemeHostPortMatcher, "");
    };

    utils.formatStoryUrl = function(storyUrl) {
        return utils.extractUriFromUrl(storyUrl);
    };

    utils.getCopyright = function(copyright) {
        var label = "";
        switch (copyright) {
            case 0:
                label = utils.trans("Not Specified");
                break;
            case 1:
                label = utils.trans("All Rights Reserved");
                break;
            case 2:
                label = utils.trans("Public Domain");
                break;
            case 3:
                label = utils.trans("Creative Commons (CC) Attribution");
                break;
            case 4:
                label = utils.trans("(CC) Attrib. NonCommercial");
                break;
            case 5:
                label = utils.trans("(CC) Attrib. NonComm. NoDerivs");
                break;
            case 6:
                label = utils.trans("(CC) Attrib. NonComm. ShareAlike");
                break;
            case 7:
                label = utils.trans("(CC) Attribution-ShareAlike");
                break;
            case 8:
                label = utils.trans("(CC) Attribution-NoDerivs");
                break;
            default:
                break;
        }
        return label;
    };

    utils.getCopyrightIcon = function(copyrightValue) {
        var label = null;

        switch (copyrightValue) {
            case 0:
                break;
            case 1:
                label = "fa-copyright";
                break;
            case 2:
                label = "fa-public-domain";
                break;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                label = "fa-creative-commons";
                break;
            default:
                break;
        }

        return label;
    };

    /** Taken straight from url/url_utils.php
     * Adds the source query parameter to the URL for GA tracking
     * 	Moves hash fragments to the end of the URL so that it will go to the intended section of the web page
     *
     * @param url The URL to go to, before any tracking is added
     * @param source The source which the user is clicking the link from (web, iOS, Android)
     * @param medium (optional) The medium which the user is clicking the link from (email, facebook, twitter, etc.)
     * @param content(optional) The utm_content
     * @param page (optional) the wp_page
     * @return The final URL including tracking parameters
     */

    utils.addSource = function(url, source, medium, content, page) {
        var source_append =
            (url.indexOf("?") > 0 ? "&" : "?") + "utm_source=" + source;

        var return_url = url + source_append;

        if (medium) {
            return_url += "&utm_medium=" + medium;
        }

        if (content) {
            return_url += "&utm_content=" + content;
        }

        if (page) {
            return_url += "&wp_page=" + page;
        }

        var hash_fragments = url.indexOf("#");
        if (hash_fragments > 0) {
            return_url =
                url.substr(0, url.indexOf("#") + 1) +
                source_append +
                "#" +
                hash_fragments;
        }
        return return_url;
    };

    utils.setTitle = function(newTitleContent, appendWattpad) {
        if (typeof appendWattpad === "undefined") {
            appendWattpad = true;
        }
        var inboxCount = 0;
        var suffix = appendWattpad ? " - Wattpad" : "";
        var newTitle = newTitleContent ? newTitleContent + suffix : "Wattpad";

        if (wattpad.utils.currentUser().get("inbox")) {
            inboxCount = wattpad.utils.currentUser().get("inbox").unread;
        }

        if (app.get("device").is.desktop && inboxCount > 0) {
            newTitle = "(" + inboxCount + ") " + newTitle;
        }

        if (window.document.title !== newTitle) {
            window.document.title = wattpad.utils.unsanitizeHTML(newTitle);
        }
    };

    utils.getNextUrl = function(preferredUrl, defaultUrl) {
        var nextUrl,
            isValidNextUrl = function(testUrl) {
                return (
                    typeof testUrl === "string" &&
                    !/(\/|%2F)(getmobile|login|signup)\/?[^\/\s]*/i.test(testUrl)
                );
            };

        // clear the urls passed in
        preferredUrl = isValidNextUrl(preferredUrl) ? preferredUrl : "";
        defaultUrl = (isValidNextUrl(defaultUrl) ? defaultUrl : "") || "/home";

        // the many places of nexturl
        nextUrl =
            preferredUrl || utils.getParam("nextUrl") || utils.getParam("nexturl");

        return nextUrl && typeof nextUrl === "string" && isValidNextUrl(nextUrl) ?
            encodeURIComponent(nextUrl) :
            encodeURIComponent(defaultUrl);
    };

    utils.getParam = function(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(window.location.search);
        return results === null ?
            "" :
            decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    utils.npgettext = function(context, singular, plural, count) {
        function derpNgettext(singular, plural, count) {
            if (count === 1) {
                return singular;
            } else {
                return plural;
            }
        }

        var trans = app.get("translatedLanguage");

        count = parseInt(count, 10);

        if (!trans || !trans.jed) {
            // XXX very bad: we'll just return english if the translation hasn't been loaded!
            return derpNgettext(singular, plural, count);
        } else {
            return trans.jed.npgettext(context, singular, plural, count);
        }
    };

    utils.ngettext = function(singular, plural, count) {
        return utils.npgettext(undefined, singular, plural, count);
    };

    utils.toPascalCase = function(str) {
        var camelCase = str
            .toLowerCase()
            .replace(/[\W_]+(\w)/g, function(match, firstChar) {
                return firstChar.toUpperCase();
            });
        return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
    };

    utils.experimentSelected = function(experiment) {
        if (experiment && experiment.current) {
            window.te.push("event", "experiment", "variation", null, "select", {
                experiment: experiment.options.experimentKey,
                variation: experiment.variationLoki ?
                    experiment.variationLoki :
                    "unknown"
            });
        }
    };

    utils.isHttp = function() {
        return window.location.protocol === "http:";
    };

    utils.pushEvent = function(newEvent, gaEventName) {
        if (!newEvent || typeof newEvent !== "object" || !window.dataLayer) {
            return;
        }
        newEvent.event = gaEventName || "ga-event";
        window.dataLayer.push(newEvent);
    };

    // TODO: remove iOS/Android check once iOS reach parity with Android in deeplink
    utils.getAppLink = function(route, model) {
        var device = app.get("device");

        var routeRequiresModel = !_.includes(["library", "homepage"], route);
        if (
            typeof route === "undefined" ||
            (routeRequiresModel && typeof model === "undefined") ||
            (!device.is.ios && !device.is.android && !device.is.windows)
        ) {
            return null;
        }

        switch (route) {
            case "homepage":
                return "wattpad://discover";

            case "story-landing":
                if (model instanceof app.models.StoryModel) {
                    return "wattpad://story/" + model.get("id");
                }
                return null;

            case "story-reading":
                if (model instanceof app.models.StoryPartModel) {
                    return device.is.ios ?
                        "wattpad:///read?groupid=" +
                        model.get("group").id +
                        "&partid=" +
                        model.get("id") :
                        "wattpad://story/" +
                        model.get("group").id +
                        "/part/" +
                        model.get("id");
                }
                return null;

            case "user-profile":
                if (model instanceof app.models.User) {
                    return device.is.ios ?
                        "wattpad:///profile?username=" + model.get("username") :
                        "wattpad://user/" + model.get("username");
                }
                return null;

            case "library":
                if (device.is.android) {
                    return "wattpad://library";
                }
                return null;
        }
        return device.is.ios ?
            "iOS" :
            device.is.android ?
            "android" :
            device.is.windows ?
            "windows" :
            null;
    };

    utils.appOn = function() {
        return !$("body").hasClass("js-app-off");
    };

    utils.categorySubtitle = function(category) {
        switch (category.id) {
            case 1: //Teen Fiction
                return utils.trans(
                    "Ride the emotional rollercoaster of young adulthood with these free coming-of-age stories on love, friendship, high school drama, popularity and awkward teen moments."
                );
            case 2: //Poetry
                return utils.trans(
                    "Immerse yourself with the best poems online about love, life, and the human experience."
                );
            case 3: //Fantasy
                return utils.trans(
                    "Enter the realm of magic, dragons, princesses, elves, and faraway kingdoms, where a series of most unexpected events come to life."
                );
            case 4: //Romance
                return utils.trans(
                    "Discover free love stories for any passion or persuasion. Book a date with your favorite author and read everything from sweet young romance to steamy new adult."
                );
            case 5: //Science Fiction
                return utils.trans(
                    "Travel to the interstellar worlds of science fiction. Discover free books about space odysseys, time travel, dystopian futures, alien planets, and post-apocalyptic universes."
                );
            case 6: //Fanfiction
                return utils.trans(
                    "From Supernatural to Harry Potter, One Direction to Percy Jackson, read the best fanfiction from whatever fandom you are in."
                );
            case 7: //Humor
                return utils.trans(
                    "From tongue-in-cheek satire to literary comedy, enjoy these funny stories for adults and teens."
                );
            case 8: //Mystery / Thriller
                return utils.trans(
                    "Welcome to the world of mystery, crime, and intrigue. Investigate psychological thrillers, blood boiling murders, and detective stories."
                );
            case 9: //Horror
                return utils.trans(
                    "Feeling brave? Prepare for a scare with these creepy tales of eerie encounters, urban legends, and the unknown."
                );
            case 10: //Classics
                return utils.trans(
                    "Immerse yourself in must read classic novels and literature that have stood the test of time."
                );
            case 11: //Adventure
                return utils.trans(
                    "Go on an epic journey with these free adventure books. Travel to the realm of heroes, villains, pirates, and other fairy folk."
                );
            case 12: //Paranormal
                return utils.trans(
                    "Beware: ghosts, zombies, demons, clairvoyants, and ghouls. Read these free paranormal stories at your own risk."
                );
            case 13: //Spiritual
                return utils.trans(
                    "Embark on a spiritual journey with stories that nourish the soul. Find your answers through self-reflection, healing, and spirituality."
                );
            case 14: //Action
                return utils.trans(
                    "Looking for danger, risk, and excitement? Find your hero in the best action books for teens and adults from your favorite authors."
                );
            case 16: //Non-fiction
                return utils.trans(
                    "Read fascinating biographies, intimate memoirs, real stories of personal growth, and other non-fiction books."
                );
            case 17: //Short Stories
                return utils.trans(
                    "On the go? Read these slice-of-life short stories that span across genres."
                );
            case 18: //Vampire
                return utils.trans(
                    "Sink your teeth into these vampire books about century-old love, coven drama, and paranormal transformation."
                );
            case 19: //Random
                return utils.trans(
                    "Read stories that defy definition. Whether you are looking for things to do when you are bored, top 10 lists, guides, rants, diary entries, or contests, find your fix here."
                );
            case 21: //General Fiction
                return utils.trans(
                    "Get your fix of contemporary fiction. Experience a new perspective with the best free fiction from your next favorite author."
                );
            case 22: //Werewolf
                return utils.trans(
                    "From alpha to omega, find your one true mate with these free werewolf books that will make you howl."
                );
            case 23: //Historical Fiction
                return utils.trans(
                    "Fall back in time with fictional period pieces, war stories, and tales of vikings, kings and queens that capture the essence of history."
                );
            case 24: //Chick Lit
                return utils.trans(
                    "Discover your next favorite chicklit author with these tales of dating, drama, and disasters. Book your next experience in classic trials of modern womanhood."
                );
        }
    };

    utils.isYouTubeUrl = function(url) {
        return (
            url.indexOf("http://youtu.be/") === 0 ||
            url.indexOf("https://youtu.be/") === 0 ||
            url.indexOf("http://www.youtube.com/watch?v=") === 0 ||
            url.indexOf("https://www.youtube.com/watch?v=") === 0
        );
    };

    utils.extractYouTubeId = function(url) {
        var regExp = /.*(?:youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=)([^#\&\?]*).*/;
        var match = url.match(regExp);
        if (match && match[1].length == 11) {
            // YouTube video IDs are 11 characters long
            return match[1];
        } else {
            return "";
        }
    };

    utils.connectAsset = function(assetUrl) {
        if (wattpad.assetServer) {
            assetUrl = wattpad.assetServer + assetUrl;
        }
        return assetUrl;
    };

    utils.resizeImages = function(imageParagraphs, pageWidth) {
        var device = app.get("device"),
            pageWidth = pageWidth || (device.isDesktop() && 650) || 210;

        imageParagraphs.each(function(i, paragraph) {
            var $image = $(paragraph).children("img");
            // image width is very close to the column width
            if ($image.data("original-width") > pageWidth) {
                var aspectRatio =
                    ($image.data("original-height") / $image.data("original-width")) *
                    100;
                $(paragraph)
                    .addClass("fixed-ratio")
                    .css({
                        "padding-bottom": aspectRatio + "%"
                    });
            } else {
                $image.attr("width", $image.data("original-width"));
                $image.attr("height", $image.data("original-height"));
                $(paragraph)
                    .removeClass("fixed-ratio")
                    .css({
                        "padding-bottom": ""
                    });
            }
        });
    };

    // Returns true when at least a specified percentage (default 100%)
    // of the element becomes in view
    utils.isOnScreen = function($element, percentageVisible) {
        percentageVisible = percentageVisible || 1;

        if (!$element.length) {
            return false;
        }

        // Check if they are visible, i.e. if they consume space in the document (width, height > 0)
        if (!$element.is(":visible")) {
            return false;
        }

        var screenTop = $(window).scrollTop();
        var screenBottom = screenTop + $(window).height();

        var elementTop = $element.offset().top;
        var elementBottom = elementTop + $element.height();
        var elementVisibleHeight = $element.height() * percentageVisible;

        return (
            (elementBottom <= screenBottom && elementTop >= screenTop) ||
            (elementTop <= screenTop &&
                elementBottom > screenTop &&
                elementBottom - screenTop >= elementVisibleHeight) ||
            (elementBottom >= screenBottom &&
                elementTop < screenBottom &&
                screenBottom - elementTop >= elementVisibleHeight)
        );
    };

    utils.generateBranchLink = function(link, deepLink, options) {
        var params = {
            source: options.source,
            fields: "url",
            uuid: utils.getCookie("wp_id"),
            url: link,
            shorten: 1,
            post: 0,
            shouldFallback: false
        };

        // If desktopRedirect is set to true and passed in the api call,
        // the branch link will have $desktop_url set to the link passed in.
        if (options.desktopRedirect) {
            params.desktopRedirect = true;
        }

        if (deepLink) {
            params.deeplink = deepLink;
            params.medium = options.medium;
            params.content = options.content;
            params.page = options.page;
            if (options.campaign) {
                params.campaign = options.campaign;
            }
            //If the link came from a friend then there will be an origin param that we collected for utm stuff
            // layout.handlebars is where this happens
            if (window._utms["originator"]) {
                params.ref_ori = window._utms["originator"];
            }
        }

        return $.get("/v4/link", params);
    };

    utils.qsReplace = function(queryString, parameter, replacement) {
        if (
            typeof queryString !== "string" ||
            typeof parameter !== "string" ||
            queryString.indexOf(parameter + "=") < 0
        ) {
            return queryString;
        }
        var rx = new RegExp(parameter + "=[^&]*");
        return queryString.replace(
            rx,
            parameter +
            "=" +
            (replacement === undefined || replacement === null ? "" : replacement)
        );
    };

    utils.eligibleForDirectSoldAds = function() {
        return _.includes(
            JSON.parse(wattpad.directAdCountries),
            wattpad.userCountryCode
        );
    };

    utils.isMatureStory = function(storyGroup) {
        if (!storyGroup) {
            return true;
        }
        return storyGroup.rating >= 4;
    };

    utils.getGenderTargeting = function(user) {
        var gender;

        if (!user || !user.gender) {
            return "Ke28";
        }

        switch (user.gender) {
            case "Male":
            case "He":
                gender = "IU10";
                break;
            case "Female":
            case "She":
                gender = "Bu44";
                break;
            default:
                gender = "Ke28";
                break;
        }

        return gender;
    };

    utils.cacheBustPaidMetadata = function(storyId, partIds) {
        return window.store.dispatch(
            window.app.components.actions.cacheBustPaidContentMetadata(
                storyId,
                partIds
            )
        );
    };

    // Dev-only endpoint
    utils.revertPaidContentAccess = function(storyId, partId) {
        var username = utils.getCurrentUserAttr("username");

        if (!username) {
            throw new Error("User must be logged in to revert access");
        }

        var partParam = "";
        if (partId) {
            // partId argument is optional
            partParam = "/part/" + partId;
        }

        return Promise.resolve(
            $.ajax({
                type: "DELETE",
                url: "/v5/users/" + username + "/story/" + storyId + partParam + "/access"
            })
        ).then(function() {
            utils.cacheBustPaidMetadata(storyId, [partId]);
        });
    };

    utils.buyPaidContent = function(currency, storyId, partId) {
        var username = utils.getCurrentUserAttr("username");

        if (!username) {
            throw new Error("User must be logged in to buy a part");
        }

        var partParam = "";
        if (partId) {
            // partId argument is optional
            partParam = "/part/" + partId;
        }

        return Promise.resolve(
                $.post(
                    "/v5/users/" +
                    username +
                    "/story/" +
                    storyId +
                    partParam +
                    "/access?currency=" +
                    currency
                )
            )
            .then(function(response) {
                // Errors are returned as 200 for Android compatibility, so normalize first
                var isError = !!response.code;
                if (isError) {
                    throw response;
                } else {
                    return response;
                }
            })
            .catch(function convertErrorToDisplayableMessage(err) {
                var message;
                try {
                    var code = err.code;
                    if (code === 3005) {
                        message = wattpad.utils.trans("Sorry, there weren't enough funds in your wallet to make this purchase."); // prettier-ignore
                    } else {
                        throw "Unknown error code";
                    }
                } catch (parseError) {
                    message = wattpad.utils.trans(
                        "Something went wrong, please try again. Don't worry, you won't be charged twice!"
                    );
                }

                throw message;
            });
    };

    utils.fetchPaidContentStoryMetadata = function(storyId, partIds) {
        var commaSeparatedParts = partIds.join(",");
        return Promise.resolve(
            $.ajax({
                type: "GET",
                url: "/v5/story/" + storyId + "/paid-content/metadata",
                data: {
                    parts: commaSeparatedParts
                }
            })
        ).catch(function(err) {
            console.error("Couldn't fetch story metadata", err);
            return {};
        });
    };

    utils.markBlockedParts = function(metadata, parts) {
        return parts.map(function(part) {
            var partMetadata = metadata.parts[part.id];
            if (!partMetadata) return part;

            return {
                ...part,
                isBlocked: partMetadata.paywalled && !partMetadata.has_access,
                paywalled: partMetadata.paywalled
            };
        });
    };

    utils.isPaidPreview = function(parts) {
        var atLeastOnePartIsPurchased = _.any(parts, function(part) {
            return part.paywalled && !part.isBlocked;
        });
        var isPaywalled = _.any(parts, function(part) {
            return part.paywalled;
        });

        // We consider paid stories a "preview", so users are
        // aware they will have to pay. Once the user has paid
        // at least once, they know the story isn't free, so
        // it's no longer a preview
        return isPaywalled && !atLeastOnePartIsPurchased;
    };

    utils.numPartsBetweenCurrentAndPaywall = function(parts, currentPart) {
        // The number of parts between the current part and the next
        // paywalled part, exclusive. For invalid cases (current part is
        // paywalled, there is no future paywalled part, etc), return a
        // negative int.
        if (currentPart.isBlocked) {
            return -1;
        }

        var currentIndex = _.findIndex(parts, {
            id: currentPart.id
        });
        var partsAfterCurrent = parts.slice(currentIndex + 1);

        var firstPaywallIndexAfterCurrentPart = _.findIndex(
            partsAfterCurrent,
            function(part) {
                return part.isBlocked;
            }
        );

        return firstPaywallIndexAfterCurrentPart;
    };

    utils.getIndexForPartId = function(partId, story) {
        const parts = story.parts;

        return _.findIndex(parts, part => part.id === partId);
    };

    utils.getAgeTargeting = function(user) {
        var age;

        if (!user || !user.age) {
            age = "UNKn";
        } else if (user.age < 15) {
            age = "13HW";
        } else if (user.age >= 15 && user.age <= 17) {
            age = "59ss";
        } else if (user.age >= 18 && user.age <= 24) {
            age = "09Pv";
        } else if (user.age >= 25 && user.age <= 34) {
            age = "68OK";
        } else if (user.age >= 35 && user.age <= 40) {
            age = "71aa";
        } else if (user.age >= 41 && user.age <= 45) {
            age = "76PT";
        } else if (user.age >= 46 && user.age <= 49) {
            age = "74xS";
        } else if (user.age >= 50 && user.age <= 54) {
            age = "68zo";
        } else if (user.age >= 55 && user.age <= 59) {
            age = "33es";
        } else if (user.age >= 60 && user.age <= 64) {
            age = "84Vv";
        } else if (user.age >= 65) {
            age = "29kM";
        } else {
            age = "UNKn";
        }

        return age;
    };

    utils.getRankingTargeting = function(rankingStatus) {
        var rank;
        if (rankingStatus > 0 && rankingStatus <= 100) {
            rank = "0to100";
        } else {
            rank = "100plus";
        }
        return rank;
    };

    utils.getPlacementConfiguration = getPlacementConfiguration;

    utils.getAdzerkTargeting = getAdzerkTargeting;

    utils.getHeaderBiddingInlineStyle = function(sizes) {
        var keys = Object.keys(sizes);
        if (keys.length > 1) {
            var maxVal = 0;
            _.forIn(sizes, function(val, key) {
                if (val[0] > maxVal) {
                    maxVal = val[0];
                }
            });
            return 'style="width:' + maxVal + 'px;height:auto;"';
        } else {
            return (
                'style="width:' +
                sizes[keys[0]][0] +
                "px;height:" +
                sizes[keys[0]][1] +
                'px;"'
            );
        }
    };

    utils.showToast = function(message, options) {
        var toast = new app.views.ErrorToast({
                message: message
            },
            options
        );
        toast.render();
    };

    /**
     * MON-1054: Spike Header Bidding Datadog Metrics
     * For Testing Only - not to be used for
     * large volume events
     */
    utils.sendDataDogMetric = function(metric, cb) {
        var data = metric || {};
        var callback = cb || null;
        $.post("/v4/metrics", data, callback);
    };

    // ADS-324: Pass prefilled tags to myworks/new
    utils.validatePrefilledTagText = function(tag) {
        var cleanedTag = wattpad.utils.sanitizeHTMLExceptQuotes(tag.split(" ")[0]);
        cleanedTag = cleanedTag
            .replace(/<(br|p|div)(\s*)>/gi, "\n")
            .replace(/(<([^>]+)>)/gi, "")
            .substring(0, 128);

        if (cleanedTag.length < 2) {
            return null;
        }
        return cleanedTag;
    };
    utils.validateImageURLs = function(imageURL) {
        var cleanedImageUrls = wattpad.utils.sanitizeHTMLExceptQuotes(
            imageURL.split(" ")[0]
        );

        var regexp = new RegExp(
            /https?:\/\/(www\.)?(em|a|d|img).wattpad.(dev-prod|com)\/+\w+/
        );
        var match = cleanedImageUrls.match(regexp);

        return !!match;
    };

    // returns sizes that a particular placement can support
    utils.getPlacementSizes = function(adzerkUnit) {
        let sizes = [];
        for (const [_, value] of Object.entries(
                getPlacementConfiguration(adzerkUnit).sizes
            )) {
            sizes.push(value);
        }
        return sizes;
    };

    // creates a safe frame with an id based on the placement you pass in with a
    // starting width and height that you pass in. does not add it to the DOM
    utils.makeSafeFrame = function(placement, width, height) {
        var frame = document.createElement("iframe");
        frame.setAttribute("id", placement + "-frame");
        frame.setAttribute("FRAMEBORDER", 0);
        frame.setAttribute("SCROLLING", "no");
        frame.setAttribute("MARGINHEIGHT", 0);
        frame.setAttribute("MARGINWIDTH", 0);
        frame.setAttribute("TOPMARGIN", 0);
        frame.setAttribute("LEFTMARGIN", 0);
        frame.setAttribute("ALLOWTRANSPARENCY", "true");
        frame.setAttribute("width", width);
        frame.setAttribute("height", height);
        return frame;
    };

    utils.getPrebidTimeout = function() {
        return 1000;
    };

    // load a header bidding add using prebid
    utils.loadHbAdPrebid = function(adPlacement) {
        window.ads = window.ads || {};
        window.pbjs = window.pbjs || {};
        __adConfig = window.__adConfig || {};
        let placementOpts = adPlacement && adPlacement.placements;

        if (!placementOpts) {
            console.error(
                `loadHbAdPrebid called with no placements v:${wattpad.revision}`
            );
            return false;
        }

        if (!__adConfig) {
            console.error(
                `__adConfig undefined p:${Object.keys(placementOpts).join(" ")} v:${
          wattpad.revision
        }`
            );
            return false;
        }

        var pbjs = window.pbjs || {};
        pbjs.que = pbjs.que || [];

        __adConfig.configurePrebid(pbjs);

        Object.keys(placementOpts).forEach(placement => {
            let innerPlacement = placementOpts[placement];
            const PREBID_TIMEOUT = utils.getPrebidTimeout();
            var adUnits = __adConfig.getPrebidAdUnits([placement]);

            pbjs.que.push(function() {
                pbjs.removeAdUnit(); // clear adunits, they stick around
                pbjs.addAdUnits(adUnits);
                if (typeof __atha !== "undefined") {
                    var id = __atha.sendRequest(placement, "prebid", innerPlacement);
                    window.ads[placement] = {
                        ...window.ads[placement],
                        ...{
                            pbRequestId: id
                        }
                    };
                }
                pbjs.requestBids({
                    timeout: PREBID_TIMEOUT,
                    bidsBackHandler: function(bids, timedOut, auctionId) {
                        var normalizedBids = utils.normalizeBids(
                            bids && placement in bids ? bids[placement].bids : [],
                            utils.getBidFormat("prebid")
                        );
                        var best_bid = utils.getBestBid(normalizedBids, placement, false);
                        utils.sendAuctionResult(
                            best_bid,
                            normalizedBids,
                            placement,
                            utils.getBidFormat("prebid")
                        );

                        if (wattpad.testGroups.USE_KEVEL) {
                            var advertiserId = 2014727; // Prebid's advertiser acc't in Adzerk
                            var overrides = best_bid ?
                                utils.getAdzerkOverrides(best_bid, advertiserId) :
                                {}; // Processed HB Overrides

                            var displayTargeting = innerPlacement.targeting ? innerPlacement.targeting : {}; // prettier-ignore
                            var headerBiddingKeywords = displayTargeting.category ? (wattpad.categoryList[displayTargeting.category] ? wattpad.categoryList[displayTargeting.category] : "") : ""; //prettier-ignore

                            var partnerFields = best_bid ?
                                utils.getAdzerkPartnerFields(best_bid) :
                                {}; // HB Targeting Params
                            var mergedTargeting = _.merge(displayTargeting, partnerFields);

                            var properties = {
                                hb_bidder: !_.isEmpty(best_bid) ?
                                    best_bid.adserverTargeting ?
                                    best_bid.adserverTargeting.hb_bidder :
                                    best_bid.source_bid.adserverTargeting.hb_bidder :
                                    "",
                                ad_id: !_.isEmpty(best_bid) ?
                                    best_bid.adId ?
                                    best_bid.adId :
                                    best_bid ? .source_bid.adId :
                                    "",
                                ...mergedTargeting
                            };

                            if (typeof __atha !== "undefined") {
                                var id = __atha.sendRequest(placement, "kevel", {
                                    zoneId: innerPlacement.zoneId,
                                    ...innerPlacement
                                });
                                window.ads[placement] = {
                                    ...window.ads[placement],
                                    ...{
                                        requestId: id
                                    }
                                };
                            }

                            window.ados = window.ados || {};
                            window.ados.run = window.ados.run || [];
                            window.ados.run.push(function() {
                                pbjs.que.push(function() {
                                    if (window.ados_add_placement) {
                                        ados_add_placement(
                                                innerPlacement.networkId,
                                                innerPlacement.siteId,
                                                placement,
                                                innerPlacement.adTypes
                                            )
                                            .setZone(innerPlacement.zoneId)
                                            .setProperties(properties)
                                            .setOverrides(overrides);
                                        ados_setConsent({
                                            gdpr: true
                                        });
                                        ados_setKeywords(headerBiddingKeywords);
                                        ados_load();
                                    }
                                });
                            });
                        } else {
                            if (!bids ||
                                !(placement in bids) || // this could have bids on many placements, potentially
                                bids[placement].bids.length === 0
                            ) {
                                return utils.generateAndRenderHardcodedCreative(placement);
                            }

                            var container = document.getElementById(placement);
                            var iframeDoc;
                            var adServerTargeting = pbjs.getAdserverTargetingForAdUnitCode(
                                placement
                            );

                            // If any bidders return any creatives
                            if (best_bid && best_bid.source_bid.adId) {
                                var frame = utils.makeSafeFrame(placement, 300, 600);
                                container.appendChild(frame);
                                iframeDoc = frame.contentWindow.document;
                                pbjs.renderAd(iframeDoc, best_bid.source_bid.adId);
                                var c = document.createComment(
                                    __adConfig.getAdCommentFromPrebidBid(best_bid.source_bid)
                                );
                                container.insertBefore(c, frame);

                                // fire impression
                                if (typeof __atha !== "undefined") {
                                    __atha.sendImpression(
                                        placement,
                                        "n/a",
                                        adServerTargeting["hb_bidder"],
                                        best_bid.cpi || 0
                                    );
                                }
                            } else {
                                return utils.generateAndRenderHardcodedCreative(placement);
                            }
                        }
                    }
                });
            });
        });
    };

    // header bid again to get a new ad to show in adUnitId
    // in: the html id for the ad we want to refresh
    // out: the new html id on that div.
    utils.refreshAd = function(adId) {
        var element = document.getElementById(adId);

        if (!element) {
            return;
        }

        var htSlotName = adId.split("-")[0];
        var placementConfig = getPlacementConfiguration(htSlotName);
        var rawModel = app.currentView.model.attributes;
        var storyGroup = rawModel.group ? rawModel.group : rawModel;
        var storyPart = rawModel.group ? rawModel : undefined;
        var targeting = getAdzerkTargeting(
            storyGroup,
            storyPart,
            wattpad.utils.currentUser().toJSON()
        );

        var adPlacement = htSlotName + "-" + Date.now();
        element.id = adPlacement;

        // Need to convert types here as vanilla JS datasets are all stored as strings
        var placementsObj = {
            placements: {}
        };
        placementsObj.placements[adPlacement] = {
            siteId: 1025452,
            networkId: 9660,
            zoneId: placementConfig.zone,
            adTypes: _.map(Object.keys(placementConfig.sizes), _.parseInt),
            htSlotName: htSlotName,
            targeting: targeting
        };

        element.innerHTML = "";
        window.wattpad.utils.loadHbAdPrebid(placementsObj);
        return adPlacement;
    };

    /**
     * Fast UUID generator, RFC4122 version 4 compliant.
     * @author Jeff Ward (jcward.com).
     * @license MIT license
     * @link http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript/21963136#21963136
     **/
    utils.generateUUID = function() {
        var lut = [];
        for (var i = 0; i < 256; i++) {
            lut[i] = (i < 16 ? "0" : "") + i.toString(16);
        }
        var d0 = (Math.random() * 0xffffffff) | 0;
        var d1 = (Math.random() * 0xffffffff) | 0;
        var d2 = (Math.random() * 0xffffffff) | 0;
        var d3 = (Math.random() * 0xffffffff) | 0;
        return (
            lut[d0 & 0xff] +
            lut[(d0 >> 8) & 0xff] +
            lut[(d0 >> 16) & 0xff] +
            lut[(d0 >> 24) & 0xff] +
            "-" +
            lut[d1 & 0xff] +
            lut[(d1 >> 8) & 0xff] +
            "-" +
            lut[((d1 >> 16) & 0x0f) | 0x40] +
            lut[(d1 >> 24) & 0xff] +
            "-" +
            lut[(d2 & 0x3f) | 0x80] +
            lut[(d2 >> 8) & 0xff] +
            "-" +
            lut[(d2 >> 16) & 0xff] +
            lut[(d2 >> 24) & 0xff] +
            lut[d3 & 0xff] +
            lut[(d3 >> 8) & 0xff] +
            lut[(d3 >> 16) & 0xff] +
            lut[(d3 >> 24) & 0xff]
        );
    };

    // getBidFormat returns a structure that give other functions context on where to
    // find the data they need based on which type of bid has been passed in.
    utils.getBidFormat = function(provider) {
        if (provider === "index") {
            return {
                adPartner: provider,
                priceField: "price",
                priceIncrement: "bic",
                requestIdField: "ixRequestId",
                responseIdField: "ixResponseId",
                bidderField: "partnerId"
            };
        } else if (provider === "prebid") {
            return {
                adPartner: provider,
                priceField: "cpm",
                priceIncrement: "cpm",
                requestIdField: "pbRequestId",
                responseIdField: "pbResponseId",
                bidderField: "bidderCode"
            };
        }
    };

    utils.getBestBid = function(bids, adUnitId, sendEvents) {
        var bestBid = {};
        var adUnitId = adUnitId || "unknown";
        for (var i = 0; i < bids.length; i++) {
            var bid = bids[i];
            if (typeof __atha !== "undefined" && sendEvents) {
                var id = __atha.sendBid(
                    adUnitId,
                    _.get(bid, "partner", "unknown"),
                    _.get(bid, "bic", undefined), // bid price in cents (CPM*100)
                    bid.dimensions
                );
                bid.id = bid.source_bid.id = id;
            }
            if (!bestBid.hasOwnProperty("bic") || bid.bic > bestBid.bic) {
                bestBid = bid;
            }
        }
        return bestBid;
    };

    // send auction result atha event. works with both index and prebid bid
    // formats, you just need to tell it which format you're passing in.
    utils.sendAuctionResult = function(best_bid, bids, divId, bidFormat) {
        if (typeof __atha !== "undefined") {
            var id = __atha.sendAuctionResult(divId, best_bid, bids);
            window.ads[divId][bidFormat.responseIdField] = id;
        }
    };

    /**
     * This generates a special overrides object
     * used by Adzerk to pass header bidding ads
     * through the programmatic waterfall
     */
    utils.getAdzerkOverrides = function(bid, advertiserId) {
        var overrides = {
            advertisers: {}
        };
        // A normalized bid contains a cpm field, otherwise we're being given
        // a source bid
        var ecpm = bid.cpm ? bid.cpm : bid.price ? bid.price / 100.0 : 0;
        overrides.advertisers[advertiserId] = {
            ecpm: ecpm
        };
        return overrides;
    };

    utils.getAdzerkPartnerFields = function(bid) {
        // This will flatten the partnerId and size
        // alongisde any partner-specific targeting,
        // which are otherwise transparently passed to Adzerk
        var targeting = {};
        var sourceTargeting = _.get(bid, "source_bid.targeting", {});
        targeting.partnerId = bid.partner ? bid.partner : null;
        targeting.ixWidth = bid.dimensions ? bid.dimensions.split("x")[0] : "1";
        targeting.ixHeight = bid.dimensions ? bid.dimensions.split("x")[1] : "1";
        /** ADS-23: Custom Targeting for Rubicon Header Bidding Ads
         * Rubicon passes an ad size field as part of a combo field
         * passed as `rpfl_7941` in their bid response.
         * This will parse it and return the ad size Id from Rubicon's
         * own map
         */
        if (targeting.partnerId === "RubiconHtb" && sourceTargeting.rpfl_7941) {
            targeting.rubiconSizeId = sourceTargeting.rpfl_7941[0].slice(
                0,
                sourceTargeting.rpfl_7941[0].indexOf("_")
            );
        }
        return _.merge(targeting, sourceTargeting);
    };

    utils.adosAddPlacement = function(divId, placementOpt, bids) {
        var normalizedBids = bids ?
            utils.normalizeBids(bids, utils.getBidFormat("index")) :
            null;
        var best_bid = bids ? utils.getBestBid(normalizedBids, divId, true) : null; // Filtered Bid
        utils.sendAuctionResult(
            best_bid,
            normalizedBids,
            divId,
            utils.getBidFormat("index")
        );

        var networkId = placementOpt.networkId; // Adzerk Network ID
        var siteId = placementOpt.siteId; // Adzerk Site ID
        var zoneId = placementOpt.zoneId; // Adzerk Zone ID
        var displayTargeting = placementOpt.targeting ? placementOpt.targeting : {}; // prettier-ignore
        var adTypes = placementOpt.adTypes ? placementOpt.adTypes : []; // Adzerk Ad-Size ID's
        var advertiserId = 370943; // Index's advertiser acc't in Adzerk
        var overrides = best_bid ?
            utils.getAdzerkOverrides(best_bid, advertiserId) :
            {}; // Processed HB Overrides
        var partnerFields = best_bid ? utils.getAdzerkPartnerFields(best_bid) : {}; // HB Targeting Params
        var mergedTargeting = _.merge(displayTargeting, partnerFields);
        var headerBiddingKeywords = displayTargeting.category ? (wattpad.categoryList[displayTargeting.category] ? wattpad.categoryList[displayTargeting.category] : "") : ""; //prettier-ignore

        /**
         * MON-1054: Spike Header Bidding Datadog Metrics
         */
        if (wattpad.testGroups.ADS_DATADOG_METRICS) {
            utils.sendDataDogMetric({
                isAdRequest: true,
                adRequested: true
            });
        }
        /**
         * ADS-886: Ads Events in Prometheus
         */
        if (typeof __atha !== "undefined") {
            var id = __atha.sendRequest(divId, "adzerk", placementOpt);
            window.ads[divId] = {
                ...window.ads[divId],
                ...{
                    requestId: id
                }
            };
        }

        window.ados = window.ados || {};
        window.ados.run = window.ados.run || [];
        window.ados.run.push(function() {
            if (window.ados_add_placement) {
                ados_add_placement(networkId, siteId, divId, adTypes)
                    .setZone(zoneId)
                    .setProperties(mergedTargeting)
                    .setOverrides(overrides);
                ados_setConsent({
                    gdpr: true
                });
                ados_setKeywords(headerBiddingKeywords);
                ados_load();
            }
        });
    };

    utils.getAdzerkImpressionCPI = function(shim) {
        // These shims are unreliable, so may break without notice
        let rawCPM = shim.dp ? shim.dp : shim.pc ? shim.pc : shim.ec ? shim.ec : 0;
        return utils.getBidPrices(rawCPM, "cpm").cpi;
    };

    utils.generateAndRenderHardcodedCreative = function(divId) {
        let placementName = divId.split("-")[0];
        let width, height, inlineStyle;
        let adzerkUnitMeta = getPlacementConfiguration(placementName);
        let element = document.getElementById(divId);

        if (!adzerkUnitMeta || !element) {
            return;
        }

        inlineStyle = utils.getHeaderBiddingInlineStyle(
            _.get(adzerkUnitMeta, "sizes", {})
        );

        [width, height] = getAdSize(adzerkUnitMeta.sizes);

        let creative = getHardcodedAdString(placementName, {
            width: width,
            height: height,
            inlineStyle: inlineStyle
        });
        element.innerHTML = creative;
    };

    /**
     * normalizeBids
     * Takes in a set of bids from Prebid or IX and converts them to a standard format
     *
     * @param {array} bids List of bids
     * @param {object} bidformat Call to utils.getBidFormat (supported "prebid" or "index")
     * @return array of normalized bids
     * each normalized bid will have the following props:
     * id: atha bid id, if present in the source bid
     * source_bid: The original bid with all fields
     * dimensions: string dimensions of bid creative, ex "728x90"
     * partner: string of partnerId
     * bic: bid in cents (cpm expressed in cents, 1)
     * cpi: cost per impression (0.00001)
     * cpm: cost per 1000 impressions (0.01)
     */
    utils.normalizeBids = function(bids, bidFormat) {
        let normalizedBids = [];
        bids.forEach(bid => {
            normalizedBids.push({
                id: bid.id,
                source_bid: bid,
                dimensions: Array.isArray(bid.size) ? bid.size.join("x") : bid.size,
                partner: bid[bidFormat.bidderField],
                ...utils.getBidPrices(
                    bid[bidFormat.priceField],
                    bidFormat.priceIncrement
                )
            });
        });
        return normalizedBids;
    };

    /**
     * getBidPrices
     * Takes in a value and an increment
     * Returns a standardized value object
     * @param {decimal} price
     * @param {string} format
     * @return object containing the following values:
     * bic: bid in cents (cpm expressed in cents, 1)
     * cpi: cost per impression (0.00001)
     * cpm: cost per 1000 impressions (0.01)
     */
    utils.getBidPrices = function(price, format) {
        const CPMToCPIIncrement = 1000;
        const CPMToBICIncrement = 100;
        let cpm, cpi, bic;
        switch (format) {
            case "cpm":
                cpm = price;
                bic = cpm * CPMToBICIncrement;
                cpi = cpm / CPMToCPIIncrement;
                break;
            case "cpi":
                cpi = price;
                cpm = price * CPMToCPIIncrement;
                bic = cpm * CPMToBICIncrement;
                break;
            case "bic":
                bic = price;
                cpm = bic / CPMToBICIncrement;
                cpi = cpm / CPMToCPIIncrement;
                break;
            default:
                cpm = cpi = bic = 0;
                break;
        }
        // this is kind of dirty, but this will round our numbers to the expected maximum number
        // of significant decimal digits, which will remove floating point arithmatic errors.
        // we only do one operation here, so the entropy introduced doesn't seem to be enough
        // to make this fail. If we need to support big increments smaller than a one cent CPM
        // though, this may become problematic.
        return {
            cpm: Number(cpm.toFixed(2)),
            cpi: Number(cpi.toFixed(6)),
            bic: Number(bic.toFixed(0))
        };
    };

    /**
     * getIxPrebidSizes
     * Takes a placement config object
     * Returns prebid bidder configs for each size the IX unit supports
     * @param {object} placementDetails Application config
     * @return {array} ixBidders list containing objects with the following nested params:
     * siteId: ixSiteId from application config
     * size: array conforming  to [w, h] format, indicating what size creative
     * the unit supports. IX requires each size to be configured as a different bidder
     * for the same unit
     */
    utils.getIxPrebidSizes = function(placementDetails) {
        let ixBidders = [];

        Object.entries(placementDetails.sizes).forEach(([sizeId, dimensions]) => {
            ixBidders.push({
                bidder: "ix",
                params: {
                    siteId: placementDetails.ixSiteId,
                    size: dimensions
                }
            });
        });

        return ixBidders;
    };

    utils.showPleaseVerifyModal = function() {
        var view = new app.views.PleaseVerifyModal();
        $("#generic-modal .modal-body").html(view.render().$el);
        $("#generic-modal .modal-content").addClass("please-verify-modal-wrapper");
        $("#generic-modal").modal({});
        return;
    };

    utils.showSentEmailModal = function(modalOptions) {
        var view = new app.views.VerifyEmailModal(modalOptions);
        $("#generic-modal .modal-body").html(view.render().$el);
        $("#generic-modal .modal-content").addClass("sent-email-modal-wrapper");
        $("#generic-modal").modal({});
        return;
    };

    utils.showChangeEmailModal = function(modalOptions) {
        var view = new app.views.VerifyEmailModal(modalOptions);
        $("#generic-modal .modal-body").html(view.render().$el);
        $("#generic-modal .modal-content").addClass("change-email-modal-wrapper");
        $("#generic-modal").modal({});
        return;
    };

    /**
     * Return a roles structure consistent with server side code so that we are using the same names in our role checks.
     * @param {Object} currentUser - object passed representing the User structure.
     * @param {Boolean} currentUser.isSysAdmin - currently indicates that the user is staff on the company VPN connection or office IP
     * @param {Boolean} currentUser.ambassador - indicates that the user is a wattpad ambassador
     *
     * @returns {Object} contains all related role flags for the current user
     */
    utils.getCurrentUserRoles = function({
        isSysAdmin = false,
        ambassador = false
    } = {}) {
        return {
            isSysAdmin,
            isAmbassador: ambassador
        };
    };

    utils.clearCommentLocalStorage = function() {
        const partCommentsregex = /mobile-web#part.\w*.comments/;
        const commentReplyregex = /mobile-web#comments.\w*.replies/;

        let keys = Object.keys(window.localStorage);
        keys.forEach(key => {
            if (partCommentsregex.test(key) || commentReplyregex.test(key)) {
                window.localStorage.removeItem(key);
            }
        });
    };

    /* The following function is used to clear the cached story data once a user block/unblocks another user. 
    This will improve the user exprience and ensures users see the expected page on CSR.
    If user A has blocked user B, they should see story 404 when navigating to user B's stories
    If user A has unblocked user B, they should see user B's story 
    */

    utils.clearStoriesLocalStorage = function() {
        const storyReadingRegex = /mobile-web#story.read.\w*.metadata/;
        const storyPartRegex = /mobile-web#part.\w*.metadata/;
        const storiesRegex = /mobile-web#stories.\w*/;
        const readingListRegex = /mobile-web#reading-list.\w*.stories/;

        let keys = Object.keys(window.localStorage);
        keys.forEach(key => {
            if (
                storyReadingRegex.test(key) ||
                storyPartRegex.test(key) ||
                storiesRegex.test(key) ||
                readingListRegex.test(key)
            ) {
                // Remove from memory
                let baseKey = key.split("#")[1];
                app.local._clearItem(baseKey);

                // Remove from local storage
                window.localStorage.removeItem(key);
            }
        });
    };

    utils.getSearchTitle = getSearchTitle;
    utils.tagsHelper = tagsHelper;
    utils.isUnsafe = isUnsafe;
    utils.forcedSignupHelper = {
        isForcedSignupSession,
        isForcedSignupExemptView
    };
})(window, window._, window.wattpad);