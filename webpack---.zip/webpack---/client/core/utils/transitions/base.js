/*
 * Base Transition
 * for utility functions that can be used by all transitions
 */
(function(window, Monaco, wattpad, app) {
    "use strict";

    app.add(
        "BaseTransition",
        Monaco.Transition.extend({
            _canonicalURL: function(options) {
                var curUrl = Monaco.history.fragment || "";
                var newUrl = curUrl.toLowerCase();

                // profile name keep cases
                if (
                    typeof options.username !== "undefined" &&
                    options.username !== ""
                ) {
                    newUrl = newUrl.replace(
                        options.username.toLowerCase(),
                        options.username
                    );
                }

                if (curUrl !== newUrl) {
                    app.router.navigate(newUrl, {
                        trigger: false,
                        replace: true
                    });
                }
            },

            _hideAddressBar: function() {
                wattpad.utils.hideAddressBar();
            },

            _pageView: function() {
                wattpad.utils.pushEvent({}, "virtualPageview");
                // WEB-7802 Make sure client side navigation triggers
                // refresh for video ads
                if (typeof window._FskRefresh !== "undefined") {
                    window._FskRefresh();
                }
            },

            injectDOM: function(fromView, toView, containerSelector, emptyContainer) {
                var $container = $(containerSelector);

                // bind with the current view if first page load
                if (!fromView && $container.children().length > 0) {
                    // todo: this might need to change based on the logic
                    //       that the web team wants to follow - right now it
                    //       binds the first element of the container to the view
                    toView.setElement($container.children(0)[0]);
                    $("body").removeClass("js-app-off");

                    // Tell Boomerang that we're ready.
                    if (window.BOOMR) {
                        // Boomerang is already loaded.
                        window.BOOMR.page_ready();
                        window.BOOMR.addVar("tag", "CSR");
                    } else if (document.addEventListener) {
                        // Boomerang has not yet loaded, but might still load.
                        document.addEventListener("onBoomerangLoaded", function(e) {
                            e.detail.BOOMR.page_ready();
                            e.detail.BOOMR.addVar("tag", "CSR");
                        });
                    }

                    // Setup for CSR transition timing
                    app.router.on("route", function(event) {
                        if (window.BOOMR) {
                            app.set("transition_timer", window.BOOMR.requestStart());
                        }
                    });

                    app.trigger("app:client-bound", {
                        app: app,
                        view: toView
                    });
                }

                // replace the container content for all other transitions
                else {
                    // empty the container by default unless told otherwise
                    if (emptyContainer) {
                        $container.empty();
                    }
                    $container.append(toView.$el);
                }

                // Setup ads trigger
                if (!!$(".advertisement:not(.hasIO):not(.hasRun)").length) {
                    window.dispatchEvent(
                        new CustomEvent("ad-available", {
                            bubbles: true
                        })
                    );
                }
            }
        })
    );
})(window, Monaco, wattpad, window.app);